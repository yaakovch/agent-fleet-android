#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_COMMON_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_COMMON_SH=1

wtmux_resolve_path() {
  local path="$1"
  local dir
  local target

  while [[ -L "$path" ]]; do
    dir="$(cd -P "$(dirname "$path")" >/dev/null 2>&1 && pwd)"
    target="$(readlink "$path")"
    if [[ "$target" != /* ]]; then
      path="${dir}/${target}"
    else
      path="$target"
    fi
  done

  dir="$(cd -P "$(dirname "$path")" >/dev/null 2>&1 && pwd)"
  printf '%s/%s\n' "$dir" "$(basename "$path")"
}

if [[ -z "${WTMUX_REPO_ROOT:-}" ]]; then
  WTMUX_REPO_ROOT="$(cd -P "$(dirname "$(wtmux_resolve_path "${BASH_SOURCE[0]}")")/.." >/dev/null 2>&1 && pwd)"
fi

WTMUX_CONFIG_PATH_DEFAULT="${WTMUX_CONFIG_PATH:-${HOME}/.config/wtmux/wtmux.conf}"
WTMUX_STATE_DIR_DEFAULT="${WTMUX_STATE_DIR:-${HOME}/.local/state/wtmux}"
WTMUX_CACHE_DIR_DEFAULT="${WTMUX_CACHE_DIR:-${HOME}/.cache/wtmux}"

wtmux_log() {
  local level="$1"
  shift
  printf '[wtmux][%s] %s\n' "$level" "$*" >&2
}

wtmux_info() {
  wtmux_log info "$@"
}

wtmux_warn() {
  wtmux_log warn "$@"
}

wtmux_debug() {
  if [[ -n "${WTMUX_DEBUG:-}" ]]; then
    wtmux_log debug "$@"
  fi
}

wtmux_die() {
  if [[ -n "${WTMUX_STABLE_ERROR_CODE:-}" ]]; then
    printf '[wtmux][error] %s\n' "$WTMUX_STABLE_ERROR_CODE" >&2
  else
    wtmux_log error "$@"
  fi
  exit 1
}

wtmux_is_interactive() {
  [[ -t 0 && -t 1 && "${WTMUX_NONINTERACTIVE:-0}" != "1" ]]
}

wtmux_require_cmd() {
  local cmd="$1"
  command -v "$cmd" >/dev/null 2>&1 || wtmux_die "missing required command: $cmd"
}

wtmux_slugify() {
  local value="$1"
  value="${value,,}"
  value="${value// /-}"
  value="$(printf '%s' "$value" | sed -E 's/[^a-z0-9._-]+/-/g; s/^-+//; s/-+$//; s/-+/-/g')"
  printf '%s\n' "${value:-machine}"
}

# tmux parses `.` in a -t target as the window/pane separator, so a session
# named after a dotted project (DataDaily_14.09.2026) cannot be reached by
# has-session, list-panes, or kill-session. Machine ids keep wtmux_slugify.
wtmux_session_slug() {
  local value
  value="$(wtmux_slugify "$1")"
  printf '%s\n' "${value//./_}"
}

wtmux_shell_quote_join() {
  local item
  local result=()
  for item in "$@"; do
    result+=("$(printf '%q' "$item")")
  done
  printf '%s\n' "${result[*]}"
}

wtmux_array_contains() {
  local needle="$1"
  shift
  local item
  for item in "$@"; do
    if [[ "$item" == "$needle" ]]; then
      return 0
    fi
  done
  return 1
}

wtmux_repo_path() {
  printf '%s/%s\n' "$WTMUX_REPO_ROOT" "$1"
}

wtmux_runtime_bin_dir() {
  if [[ -n "${WTMUX_RUNTIME_BIN_DIR:-}" ]]; then
    printf '%s\n' "$WTMUX_RUNTIME_BIN_DIR"
    return 0
  fi

  if [[ -n "${PREFIX:-}" && -d "${PREFIX}/bin" ]]; then
    printf '%s\n' "${PREFIX}/bin"
  else
    printf '%s\n' "${HOME}/.local/bin"
  fi
}

wtmux_prepend_runtime_bin_dir() {
  local bin_dir
  bin_dir="$(wtmux_runtime_bin_dir)"
  [[ -d "$bin_dir" ]] || return 0
  case ":${PATH}:" in
    *":${bin_dir}:"*) ;;
    *) export PATH="${bin_dir}:${PATH}" ;;
  esac
}

# WSL launches from GUI clients use a minimal non-login PATH. Resolve stable,
# per-user runtime commands before system recovery binaries in that environment.
wtmux_prepend_runtime_bin_dir

wtmux_config_path() {
  printf '%s\n' "${WTMUX_CONFIG_PATH:-$WTMUX_CONFIG_PATH_DEFAULT}"
}

wtmux_state_dir() {
  printf '%s\n' "${WTMUX_STATE_DIR:-$WTMUX_STATE_DIR_DEFAULT}"
}

wtmux_cache_dir() {
  printf '%s\n' "${WTMUX_CACHE_DIR:-$WTMUX_CACHE_DIR_DEFAULT}"
}

wtmux_ensure_parent_dir() {
  local path="$1"
  mkdir -p "$(dirname "$path")"
}

wtmux_print_header() {
  printf '%s\n' "$1"
}

wtmux_git_checkout_status() {
  local repo_root="${1:-$WTMUX_REPO_ROOT}"
  local upstream
  local counts

  if ! git -C "$repo_root" rev-parse --is-inside-work-tree >/dev/null 2>&1; then
    return 1
  fi

  if ! upstream="$(git -C "$repo_root" rev-parse --abbrev-ref --symbolic-full-name '@{upstream}' 2>/dev/null)"; then
    return 1
  fi

  counts="$(git -C "$repo_root" rev-list --left-right --count "HEAD...${upstream}" 2>/dev/null)" || return 1
  printf '%s\n' "$counts"
}

wtmux_warn_if_behind_upstream() {
  local counts
  local ahead
  local behind

  counts="$(wtmux_git_checkout_status "$WTMUX_REPO_ROOT")" || return 0
  read -r ahead behind <<<"$counts"

  if [[ "${behind:-0}" != "0" ]]; then
    wtmux_warn "checkout is behind upstream by ${behind} commit(s); run 'git pull --ff-only' explicitly if you want to update"
  fi
}
