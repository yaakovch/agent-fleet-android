"""Private readiness probe; also sent read-only to hosts over existing SSH."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys

sys.dont_write_bytecode = True


def tmux(*args: str) -> str:
    binary = os.environ.get("WTMUX_TMUX_BIN") or str(Path.home() / ".local/bin/tmux")
    if not Path(binary).is_file():
        binary = shutil.which("tmux") or "tmux"
    command = [binary]
    if os.environ.get("WTMUX_SCHEDULER_TMUX_SOCKET"):
        command += ["-L", os.environ["WTMUX_SCHEDULER_TMUX_SOCKET"]]
    result = subprocess.run([*command, *args], capture_output=True, timeout=2, check=True)
    if len(result.stdout) > 65536:
        raise ValueError("attachment metadata exceeds limit")
    return result.stdout.decode("utf-8").strip()


def started(pid: int) -> str:
    value = (Path("/proc") / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()[19]
    if not value.isdigit() or int(value) <= 0:
        raise ValueError("process identity unavailable")
    return value


def incarnation(session: str) -> str:
    values = tmux("display-message", "-p", "-t", "=" + session + ":",
                  "#{session_name}|#{session_id}|#{session_created}|#{pid}").split("|")
    if (len(values) != 4 or values[0] != session or not re.fullmatch(r"\$\d+", values[1])
            or not values[2].isdigit() or not values[3].isdigit()):
        raise ValueError("exact session identity unavailable")
    boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
    return hashlib.sha256(json.dumps([boot, *values, started(int(values[3]))]).encode()).hexdigest()


def probe(action: str, session: str, token: str, expected: str = "", pid: int = 0) -> dict:
    if (not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", session)
            or not re.fullmatch(r"[a-f0-9]{32}", token)
            or expected and not re.fullmatch(r"[a-f0-9]{64}", expected)):
        raise ValueError("invalid attachment identity")
    identity = incarnation(session)
    if expected and identity != expected:
        raise ValueError("session was replaced during reconnection")
    key = "@wtmux_vscode_attach_" + token
    target = "=" + session + ":"
    if action == "prepare":
        return {"status": "prepared", "token": token, "incarnation": identity}
    if not expected:
        raise ValueError("attachment requires a verified session incarnation")
    if action == "register":
        if pid <= 0 or os.environ.get("WTMUX_VSCODE_TITLE_SCHEMA") != "2":
            raise ValueError("attachment requires the current Companion")
        # Remove only our dead-client registrations. Existing clients keep their
        # own capability and readiness records across an extension upgrade.
        options = tmux("show-options", "-t", target).splitlines()
        count = 0
        for option in options:
            name, _, raw = option.partition(" ")
            if not re.fullmatch(r"@wtmux_vscode_attach_[a-f0-9]{32}", name):
                continue
            count += 1
            try:
                value = raw.strip('"')
                if not re.fullmatch(r"[1-9][0-9]*:[0-9]+:[a-f0-9]{64}", value):
                    raise ValueError("invalid registration")
                old_pid, old_start, _ = value.split(":")
                valid = started(int(old_pid)) == old_start
            except (OSError, ValueError, TypeError, IndexError):
                valid = False
            if not valid:
                tmux("set-option", "-u", "-t", target, name)
                count -= 1
        if count >= 128:
            raise ValueError("attachment registration limit")
        value = f"{pid}:{started(pid)}:{identity}"
        tmux("set-option", "-t", target, key, value)
        return {"status": "registered", "token": token, "incarnation": identity}
    if action != "ready":
        raise ValueError("invalid attachment action")
    raw = tmux("show-option", "-qv", "-t", target, key)
    ready = False
    try:
        client, birth, registered = raw.split(":")
        if registered == identity and started(int(client)) == birth:
            capability = tmux("show-option", "-qv", "-t", target, "@wtmux_title_v2_clients")
            clients = tmux("list-clients", "-F", "#{client_pid}|#{session_name}").splitlines()
            ready = "|" + client + "|" in capability and client + "|" + session in clients
    except (OSError, ValueError, TypeError, IndexError):
        pass
    if incarnation(session) != identity:
        raise ValueError("session changed during attachment verification")
    return {"status": "ready" if ready else "pending", "token": token, "incarnation": identity}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "register", "ready"))
    parser.add_argument("--session", required=True)
    parser.add_argument("--token", required=True)
    parser.add_argument("--incarnation", default="")
    parser.add_argument("--client-pid", type=int, default=0)
    args = parser.parse_args()
    try:
        print(json.dumps(probe(args.action, args.session, args.token, args.incarnation, args.client_pid)))
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        print("[wtmux][error] attachment verification failed: " + str(error), file=sys.stderr)
        raise SystemExit(2) from error


if __name__ == "__main__":
    main()
