"""Live provider identity for shell-first sessions. No terminal text or titles."""

from __future__ import annotations

import base64
from dataclasses import dataclass
import os
from pathlib import Path
import re
import shlex
import subprocess
import time
import json
from typing import Any

PROVIDERS = {"codex", "claude", "copilot"}
NONCE = re.compile(r"^[a-f0-9]{32}$")


@dataclass(frozen=True)
class Provider:
    tool: str = "shell"
    pid: int = 0
    identity: str = ""


def command_tool(command: str) -> str:
    try:
        words = shlex.split(command.replace("\\", "/"))
    except ValueError:
        return "shell"
    if not words:
        return "shell"
    first = words[0].rsplit("/", 1)[-1].lower().removesuffix(".exe")
    candidates = words[:1]
    if first in {"node", "nodejs", "bun", "env", "exec"}:
        candidates = words[:6]
    for word in candidates:
        name = word.rsplit("/", 1)[-1].lower().removesuffix(".exe")
        if name in PROVIDERS or name in {"codex.js", "claude.js", "copilot.js"}:
            tool = name.removesuffix(".js")
            return "shell" if tool == "codex" and "app-server" in words else tool
        if first in {"node", "nodejs", "bun"}:
            path = word.lower()
            if "/@github/copilot/" in path:
                return "copilot"
            if "/@anthropic-ai/claude-code/" in path:
                return "claude"
            if "/@openai/codex/" in path and "app-server" not in words:
                return "codex"
    return "shell"


def descendants(root: int, parents: dict[int, int]) -> list[int]:
    if root <= 0:
        return []
    children: dict[int, list[int]] = {}
    for pid, parent in parents.items():
        children.setdefault(parent, []).append(pid)
    result: list[int] = []
    queue = [root]
    while queue and len(result) < 256:
        pid = queue.pop(0)
        if pid in result:
            continue
        result.append(pid)
        queue.extend(children.get(pid, ()))
    return result


def unique_provider(root: int, table: dict[int, tuple[int, str]]) -> Provider:
    parents = {pid: row[0] for pid, row in table.items()}
    candidates = {
        pid: command_tool(table[pid][1])
        for pid in descendants(root, parents)
        if pid in table
    }
    candidates = {pid: tool for pid, tool in candidates.items() if tool != "shell"}
    # Node/native wrappers in one chain are one frontend; sibling agents are ambiguous.
    frontends = {
        pid: tool
        for pid, tool in candidates.items()
        if not any(
            other != pid and pid in descendants(other, parents) for other in candidates
        )
    }
    if len(frontends) != 1:
        return Provider(pid=root)
    pid, tool = next(iter(frontends.items()))
    return Provider(tool, pid)


def linux_provider(
    root: int, table: dict[int, tuple[int, str]], fallback: str = ""
) -> Provider:
    if root <= 0:
        return Provider(command_tool(fallback), root)
    parents = {pid: row[0] for pid, row in table.items()}
    table = {pid: table[pid] for pid in descendants(root, parents) if pid in table}
    # A background agent must not authorize commands directed at the shell prompt.
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    try:
        foreground = int(
            (proc / str(root) / "stat").read_text().rsplit(")", 1)[1].split()[5]
        )
        if foreground > 0:
            allowed = {}
            for pid, row in table.items():
                try:
                    group = int(
                        (proc / str(pid) / "stat")
                        .read_text()
                        .rsplit(")", 1)[1]
                        .split()[2]
                    )
                    if group == foreground or command_tool(row[1]) == "shell":
                        allowed[pid] = row
                except (OSError, ValueError, IndexError):
                    continue
            table = allowed
    except (OSError, ValueError, IndexError):
        pass
    found = unique_provider(root, table)
    return found if found.tool != "shell" else Provider(command_tool(fallback), root)


WINDOWS_QUERY = r"""
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
$all=@(Get-CimInstance Win32_Process)
$keep=[Collections.Generic.HashSet[uint32]]::new()
$states=@{}
$roots=@{}
$logicalParents=@{}
$native=@{}
foreach($p in $all){$native[[int]$p.ProcessId]=$p}
foreach($p in $all) {
 if($p.Name -ne 'bash.exe' -or $p.CommandLine -notmatch '--rcfile\s+(?:"([^"]+)"|(\S+))'){continue}
 $rc=if($Matches[1]){$Matches[1]}else{$Matches[2]}
 if($rc -notmatch 'wtmux-shell-([a-f0-9]{32})-[A-Za-z0-9]+$'){continue}
 $nonce=$Matches[1]
 $state=''
 try {if((Get-Item -LiteralPath ($rc+'.state')).Length -le 2048){$state=[IO.File]::ReadAllText($rc+'.state').Trim()}}catch{}
 $lines=@($state.Replace("`r",'').Split("`n"))
 $state=''
 if($lines.Count -ge 2 -and $lines[-1] -eq 'complete' -and $lines[0] -match '^(running|prompt):([1-9][0-9]*)$'){
  $head=$Matches[1]+':'+$Matches[2]+':'
  $jobs=@($lines|Select-Object -Skip 1|Select-Object -SkipLast 1)
  if(@($jobs|Where-Object {$_ -notmatch '^[1-9][0-9]*$'}).Count -eq 0){$state=$head+($jobs -join ',')}
 }
 $states[[uint32]$p.ProcessId]=@{nonce=$nonce;raw=$state;state='';foreground=@();background=@();scopeVerified=$false}
 $roots[[uint32]$p.ProcessId]=$p
 [void]$keep.Add([uint32]$p.ProcessId)
}
$running=@($roots.Values|Where-Object {$states[[uint32]$_.ProcessId].raw -match '^running:[1-9][0-9]*:[0-9,]*$'})
if($running.Count -gt 0) {
 $ids=@($running|ForEach-Object {$states[[uint32]$_.ProcessId].raw.Split(':')[1]})
 $script='/usr/bin/ps -W; for p in '+($ids -join ' ')+'; do echo WTMUX_STAT $p $(/usr/bin/cat /proc/$p/stat); done'
 $output=@(& $running[0].ExecutablePath --noprofile --norc -c $script)
 if($LASTEXITCODE -ne 0){throw 'MSYS process query failed'}
 if(($output -join "`n").Length -gt 2097152){throw 'MSYS process bound exceeded'}
 $msys=@{}; $groups=@{}
 foreach($line in $output) {
  if($line -match '^\s*(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+') {
   $msys[$Matches[1]]=@{winpid=[int]$Matches[4];group=[int]$Matches[3];parent=$Matches[2]}
  } elseif($line -match '^WTMUX_STAT (\d+) .*\) (.*)$') {
   $groups[$Matches[1]]=[int]$Matches[2].Split(' ',[StringSplitOptions]::RemoveEmptyEntries)[5]
  }
 }
 foreach($p in $running) {
  $state=$states[[uint32]$p.ProcessId]; $parts=$state.raw.Split(':'); $pidText=$parts[1]
  if(-not $msys.ContainsKey($pidText) -or $msys[$pidText].winpid -ne [int]$p.ProcessId){continue}
  $state.state='running'; $state.scopeVerified=$true
  # MSYS exec can replace its native process while retaining the logical
  # shell/job tree. Bind those WINPIDs through the verified MSYS root instead
  # of depending on an exited intermediate Win32 parent.
  $owned=@{}; $owned[$pidText]=[int]$p.ProcessId
  for($i=0;$i -lt 32;$i++){
   foreach($id in @($msys.Keys)){
    $m=$msys[$id]
    if($owned.ContainsKey($id) -or -not $owned.ContainsKey($m.parent)){continue}
    $ancestor=$owned[$m.parent]; $n=$native[$m.winpid]
    if($n -and $n.CreationDate -ge $p.CreationDate){
     $logicalParents[[int]$m.winpid]=$ancestor
     $owned[$id]=[int]$m.winpid
     [void]$keep.Add([uint32]$m.winpid)
    }else{$owned[$id]=$ancestor}
   }
  }
  $state.background=@($parts[2].Split(',')|Where-Object {$_ -and $msys.ContainsKey($_)}|ForEach-Object {$msys[$_].winpid})
  if($groups.ContainsKey($pidText) -and $groups[$pidText] -gt 0){
   $state.foreground=@($msys.Values|Where-Object {$_.group -eq $groups[$pidText]}|ForEach-Object {$_.winpid})
  }
 }
}
for($i=0;$i -lt 32;$i++) {
 $before=$keep.Count
 foreach($p in $all){if($keep.Contains([uint32]$p.ParentProcessId)){[void]$keep.Add([uint32]$p.ProcessId)}}
 if($keep.Count -gt 128){throw 'Provider process bound exceeded'}
 if($before -eq $keep.Count){break}
}
$rows=@(foreach($p in $all){if($keep.Contains([uint32]$p.ProcessId)){
 $state=$states[[uint32]$p.ProcessId]
 [pscustomobject]@{pid=[int]$p.ProcessId;parent=if($logicalParents.ContainsKey([int]$p.ProcessId)){$logicalParents[[int]$p.ProcessId]}else{[int]$p.ParentProcessId};birth=$p.CreationDate.ToFileTimeUtc().ToString();
 command=([string]$p.CommandLine).Substring(0,[Math]::Min(2048,([string]$p.CommandLine).Length));
 nonce=if($state){$state.nonce}else{''};state=if($state){$state.state}else{''};
 foreground=@(if($state){$state.foreground});background=@(if($state){$state.background});scopeVerified=[bool]($state -and $state.scopeVerified)}
}})
ConvertTo-Json -InputObject @($rows) -Compress -Depth 4
"""
_windows_cache: tuple[float, list[dict[str, Any]]] = (0.0, [])


def windows_processes(refresh: bool = False) -> list[dict[str, Any]]:
    global _windows_cache
    now = time.monotonic()
    if not refresh and now - _windows_cache[0] < 1:
        return _windows_cache[1]
    executable = os.environ.get(
        "WTMUX_WINDOWS_POWERSHELL",
        "/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe",
    )
    command = [
        executable,
        "-NoProfile",
        "-NonInteractive",
        "-EncodedCommand",
        base64.b64encode(WINDOWS_QUERY.encode("utf-16le")).decode(),
    ]
    if (
        not Path("/proc/sys/fs/binfmt_misc/WSLInterop").exists()
        and Path("/run/WSL").is_dir()
    ):
        command.insert(0, "/init")
    try:
        result = subprocess.run(
            command,
            stdin=subprocess.DEVNULL,
            capture_output=True,
            timeout=10,
            check=True,
            cwd=Path(executable).parent,
        )
        if len(result.stdout) > 512 * 1024:
            raise ValueError("Provider process response exceeded bound")
        rows = json.loads(result.stdout.decode("utf-8-sig"))
        if not isinstance(rows, list) or len(rows) > 128:
            raise ValueError("Invalid provider process response")
        for row in rows:
            if (
                not isinstance(row, dict)
                or set(row)
                != {
                    "pid",
                    "parent",
                    "birth",
                    "command",
                    "nonce",
                    "state",
                    "foreground",
                    "background",
                    "scopeVerified",
                }
                or type(row["pid"]) is not int
                or row["pid"] <= 0
                or type(row["parent"]) is not int
                or not all(
                    isinstance(row[k], str)
                    for k in ("birth", "command", "nonce", "state")
                )
                or not row["birth"].isdigit()
                or len(row["command"]) > 2048
                or type(row["scopeVerified"]) is not bool
                or any(
                    not isinstance(row[k], list)
                    or len(row[k]) > 128
                    or any(type(pid) is not int or pid <= 0 for pid in row[k])
                    for k in ("foreground", "background")
                )
            ):
                raise ValueError("Invalid provider process identity")
        _windows_cache = (time.monotonic(), rows)
    except (OSError, ValueError, subprocess.SubprocessError):
        _windows_cache = (time.monotonic(), [])
    return _windows_cache[1]


def windows_provider(nonce: str, rows: list[dict[str, Any]]) -> Provider:
    if not NONCE.fullmatch(nonce):
        return Provider()
    roots = [row for row in rows if row["nonce"] == nonce and row["scopeVerified"]]
    if (
        len(roots) != 1
        or roots[0]["state"] != "running"
        or not roots[0]["scopeVerified"]
    ):
        return Provider()
    root = roots[0]
    table = {row["pid"]: row for row in rows}
    scoped = {root["pid"]: (0, root["command"])}
    for pid in descendants(
        root["pid"], {pid: row["parent"] for pid, row in table.items()}
    ):
        row = table.get(pid)
        parent = table.get(row["parent"]) if row else None
        if (
            row
            and parent
            and row["parent"] in scoped
            and int(row["birth"]) >= int(parent["birth"])
        ):
            scoped[pid] = (row["parent"], row["command"])
    parents = {pid: row[0] for pid, row in scoped.items()}
    background = {
        pid for job in root["background"] for pid in descendants(job, parents)
    }
    foreground = {
        pid for job in root["foreground"] for pid in descendants(job, parents)
    }
    # A nested interactive shell without a foreground-group proof is ambiguous.
    nested_shell = any(
        pid != root["pid"]
        and row[1] != root["command"]
        and re.search(r"(?:^|[/\\ ])bash(?:\.exe)?(?: |$)", row[1], re.I)
        and re.search(r"(?:^| )-i(?: |$)", row[1])
        for pid, row in scoped.items()
    )
    if not foreground and nested_shell:
        return Provider()
    scoped = {
        pid: (
            row[0],
            row[1]
            if pid not in background and (not foreground or pid in foreground)
            else "",
        )
        for pid, row in scoped.items()
    }
    found = unique_provider(root["pid"], scoped)
    if found.tool == "shell":
        return Provider()
    return Provider(
        found.tool,
        found.pid,
        f"windows:{root['pid']}:{root['birth']}:{found.pid}:{table[found.pid]['birth']}",
    )


def provider(
    root: int,
    table: dict[int, tuple[int, str]],
    fallback: str = "",
    declared: str = "",
    backend: str = "linux",
    nonce: str = "",
    refresh: bool = False,
) -> Provider:
    if backend == "windows" and nonce:
        return windows_provider(nonce, windows_processes(refresh))
    found = linux_provider(root, table, fallback)
    if found.tool == "shell" and backend == "windows" and declared in PROVIDERS:
        return Provider(declared, root)  # Existing provider-launched sessions only.
    return found
