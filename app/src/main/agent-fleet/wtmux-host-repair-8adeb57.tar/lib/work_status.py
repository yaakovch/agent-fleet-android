"""Shared, conservative agent work observations. No conversation content is stored."""

from __future__ import annotations

import datetime as dt
import json
from pathlib import Path
from typing import Any

STATES = {"working", "waiting", "attention", "stopped", "unknown"}
SYMBOLS = {
    "working": "↻",
    "waiting": "○",
    "attention": "!",
    "stopped": "■",
    "unknown": "?",
}
MAX_AGE = 10
READ_BUDGET = 256 * 1024


def instant(epoch: float) -> str:
    return (
        dt.datetime.fromtimestamp(epoch, dt.timezone.utc)
        .isoformat(timespec="milliseconds")
        .replace("+00:00", "Z")
    )


def fresh(value: Any, now: float) -> dict | None:
    if (
        not isinstance(value, dict)
        or set(value) != {"state", "observedAt"}
        or value.get("state") not in STATES
    ):
        return None
    try:
        stamp = dt.datetime.fromisoformat(value["observedAt"].replace("Z", "+00:00"))
        if stamp.tzinfo is None or not -2 <= now - stamp.timestamp() < MAX_AGE:
            return None
    except (ValueError, TypeError, AttributeError):
        return None
    return value


class ProviderObservation:
    """Incremental provider lifecycle; a source must be proved live by the caller.

    Re-reading a cached snapshot never advances observedAt. A collector can renew
    an open lifecycle only after revalidating the SAME live provider/source owner.
    No implicit waiting from silence, no inference from output recency.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.identity = None
        self.offset = 0
        self.state = "unknown"
        self.pending: set[str] = set()
        self.partial = b""

    def consume(self, adapter: str, record: dict, normalized: list[dict]) -> None:
        payload = record.get("payload") or {}
        kind = payload.get("type") if isinstance(payload, dict) else ""
        event = record.get("type")
        # An async question is explicitly non-blocking, even when normalized as
        # a running question. It must never replace an active turn with Waiting.
        async_question = adapter == "codex" and (
            payload.get("name") == "request_user_input_async"
            or isinstance(payload.get("item"), dict)
            and payload["item"].get("delivery") == "async"
        )
        if adapter == "claude" and event == "user" and not record.get("isMeta"):
            self.state = "working"
        if adapter == "claude" and event == "assistant":
            reason = (record.get("message") or {}).get("stop_reason")
            if reason == "end_turn":
                self.state, self.pending = "waiting", set()
        if adapter == "copilot" and event == "session.idle":
            self.state, self.pending = "waiting", set()
        if (
            adapter == "codex"
            and kind == "task_started"
            or adapter == "copilot"
            and event == "assistant.turn_start"
        ):
            self.state, self.pending = "working", set()
        for value in normalized:
            category, state, title = (
                value.get("kind"),
                value.get("state"),
                value.get("title"),
            )
            if category == "status" and title == "Working" and state == "running":
                self.state = "working"
            elif (
                category == "status"
                and title in {"Done", "Turn Duration"}
                and state == "complete"
            ):
                self.state, self.pending = "waiting", set()
            elif category == "error":
                self.state, self.pending = (
                    ("stopped" if title == "Stopped" else "attention"),
                    set(),
                )
            elif category in {"question", "approval"} and not async_question:
                if state in {"running", "pending"}:
                    self.pending.add(str(value.get("id")))
                    self.state = "attention"
                elif state == "complete":
                    self.pending.discard(str(value.get("id")))
                    if not self.pending:
                        self.state = "working"
            elif (
                category == "tool"
                and state in {"complete", "error"}
                and str(value.get("id")) in self.pending
            ):
                self.pending.discard(str(value.get("id")))
                if not self.pending:
                    self.state = "working"
            elif category == "tool" and state == "running" and not self.pending:
                self.state = "working"
        # Explicit lifecycle terminal events win over any normalized content.
        if adapter == "codex" and kind in {"task_complete", "turn_aborted"}:
            self.state, self.pending = (
                ("waiting" if kind == "task_complete" else "stopped"),
                set(),
            )
        if adapter == "copilot" and event in {"assistant.turn_end", "abort"}:
            self.state, self.pending = (
                ("waiting" if event == "assistant.turn_end" else "stopped"),
                set(),
            )

    def read(
        self,
        path: Path,
        owner: tuple,
        adapter: str,
        normalizer,
        now: float,
        since: float | None = None,
    ) -> dict:
        metadata = path.stat()
        identity = (*owner, metadata.st_dev, metadata.st_ino, adapter)
        if identity != self.identity or metadata.st_size < self.offset:
            self.reset()
            self.identity = identity
            self.offset = max(0, metadata.st_size - READ_BUDGET)
            skip = self.offset > 0
        else:
            skip = False
        if metadata.st_size - self.offset > READ_BUDGET:
            # Losing an incremental interval loses lifecycle certainty.
            self.state, self.pending, self.partial = "unknown", set(), b""
            self.offset = metadata.st_size - READ_BUDGET
            skip = True
        with path.open("rb") as stream:
            stream.seek(self.offset)
            data = stream.read(READ_BUDGET)
        self.offset += len(data)
        data = self.partial + data
        if skip:
            data = data.partition(b"\n")[2]
        lines = data.split(b"\n")
        self.partial = lines.pop()[:READ_BUDGET]
        for raw in lines:
            try:
                record = json.loads(raw)
                if isinstance(record, dict):
                    if since is not None:
                        try:
                            stamp = dt.datetime.fromisoformat(
                                record.get("timestamp", "").replace("Z", "+00:00")
                            )
                            if stamp.tzinfo is None or stamp.timestamp() < since:
                                continue
                        except (ValueError, TypeError, AttributeError):
                            continue
                    self.consume(adapter, record, normalizer(record, 0))
            except (ValueError, TypeError, AttributeError):
                continue
        return {"state": self.state, "observedAt": instant(now)}
