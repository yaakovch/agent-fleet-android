const assert = require('node:assert/strict');
const { registerHostFiles } = require('../src/host-files');

async function run() {
  const terminal = {}; const errors = []; const subscriptions = [];
  let binding = {hostId:'host', session:'session', project:'project'};
  let revision = 'a'.repeat(64); let calls = 0; let slow = false; let release; let malformed = false;
  const service = registerHostFiles({window:{registerTerminalLinkProvider:()=>({dispose(){}}),showErrorMessage:error=>errors.push(error)},
    commands:{registerCommand:()=>({dispose(){}})}}, {extensionPath:__dirname,subscriptions}, {
    isManaged:()=>true, binding:()=>JSON.stringify(binding), resolve:async()=>({...binding}), invocation:args=>({args}),
    runInvocation:async(invocation, signal)=> {
      assert.equal(invocation.args[0], 'pane', 'No file inspection or fetch during detection or stale activation.'); calls++;
      if (slow) await new Promise((resolve,reject)=>{release=resolve;signal.addEventListener('abort',()=>reject(new Error('cancelled')),{once:true});});
      const line=invocation.args.at(-1);
      return {stdout:JSON.stringify({protocolVersion:1,type:'pane.links',hostId:invocation.args[3],session:invocation.args[5],projectRoot:'/tmp/project',line,revision,
        links:[{start:0,end:line.length,target:malformed?'https://untrusted.invalid/file':'/tmp/full-file.md'}]})};
    }
  });
  const request={terminal,line:'segment.md'};
  const links=await service.provider.provideTerminalLinks(request);
  assert.equal(links.length,1); assert.equal(calls,1);
  assert.equal((await service.provider.provideTerminalLinks(request))[0],links[0]); assert.equal(calls,1);
  revision='b'.repeat(64); await service.provider.handleTerminalLink(links[0]);
  assert.match(errors.pop(),/changed/); assert.equal(calls,2);
  binding={...binding,session:'other'}; await service.provider.handleTerminalLink(links[0]); assert.match(errors.pop(),/changed/);
  slow=true;
  const old=service.provider.provideTerminalLinks({terminal,line:'old.md'});
  await new Promise(resolve=>setImmediate(resolve));
  const current=service.provider.provideTerminalLinks({terminal,line:'current.md'});
  await new Promise(resolve=>setImmediate(resolve)); release();
  assert.deepEqual(await old,[]); assert.equal((await current).length,1);
  const replaced=service.provider.provideTerminalLinks({terminal,line:'replaced.md'});
  await new Promise(resolve=>setImmediate(resolve)); binding={...binding,project:'replacement'}; release();
  assert.deepEqual(await replaced,[]);
  slow=false; malformed=true;
  assert.deepEqual(await service.provider.provideTerminalLinks({terminal,line:'invalid.md'}),[]);
  assert.deepEqual(await service.provider.provideTerminalLinks(request,{isCancellationRequested:true}),[]);
  subscriptions.forEach(item=>item.dispose());
  console.log('ok pane lookup cache, cancellation, stale response, binding and target revalidation');
}
run().catch(error=>{console.error(error);process.exitCode=1});
