const vscode = require('vscode');
const fs = require('node:fs/promises');
const path = require('node:path');
const crypto = require('node:crypto');
const assert = require('node:assert/strict');
const { registerHostFiles, previewHtml } = require('../src/host-files');
const root = path.resolve(__dirname, '..');
exports.run = async () => {
  const subscriptions = []; const calls = []; const states = []; const probes = []; const requests = [];
  const directory = process.env.WTMUX_FILE_PREVIEW_REVIEW;
  if (!directory) throw new Error('Isolated review output directory is required');
  const origin = vscode.window.createTerminal({ name: 'wtmux preview origin', shellPath: 'cmd.exe', shellArgs: ['/d', '/k'] });
  const other = vscode.window.createTerminal({ name: 'unrelated terminal', shellPath: 'cmd.exe', shellArgs: ['/d', '/k'] });
  let body = Buffer.from('Current host bytes'); let kind = 'text'; let name = 'outside.txt';
  const digest = () => crypto.createHash('sha256').update(body).digest('hex');
  const probeScript = `let last='';window.addEventListener('error',event=>vscode.postMessage({reviewProbe:true,error:event.message||event.target?.src}),true);window.addEventListener('unhandledrejection',event=>vscode.postMessage({reviewProbe:true,error:String(event.reason)}));setInterval(()=>{const content=document.querySelector('#content');if(!content)return;const text=content.textContent;const status=document.querySelector('#status')?.textContent;const signature=text+'|'+status;if(signature!==last){last=signature;vscode.postMessage({reviewProbe:true,text,status,title:document.querySelector('#title').textContent})}},100);
    window.addEventListener('message',event=>{if(event.data?.type==='iframe-review')vscode.postMessage({reviewProbe:true,html:event.data});else if(event.data?.id||event.data?.type==='updated')vscode.postMessage({reviewProbe:true,incoming:event.data.id||event.data.type,origin:event.origin,selfOrigin:window.origin,href:window.location.href,sourceParent:event.source===window.parent,sourceSelf:event.source===window,sourceNull:!event.source})});`;
  const files = registerHostFiles(vscode, { subscriptions, extensionPath: root }, {
    isManaged: terminal => terminal === origin,
    resolve: async terminal => { assert.equal(terminal, origin); return { hostId: 'origin-host', session: 'managed-origin' }; },
    invocation: args => ({ command: 'fixture', args, options: {} }),
    localPath: async value => value,
    downloadsDirectory: () => path.join(directory, 'Downloads'),
    onState: (state, folder) => states.push({ ...state, folder }),
    previewHtml: (webview, api, assets) => previewHtml(webview, api, assets).replace('const vscode=acquireVsCodeApi();', 'const vscode=acquireVsCodeApi();' + probeScript),
    runInvocation: async invocation => {
      const args = invocation.args;
      if (args[0] === 'pane') return {stdout:JSON.stringify({protocolVersion:1,type:'pane.links',hostId:'origin-host',session:'managed-origin',projectRoot:'/verified-project',line:args.at(-1),revision:'a'.repeat(64),links:require('../src/host-file-reference').hostFileReferences(args.at(-1))})};
      calls.push(invocation.args);
      assert.equal(args[args.indexOf('--host') + 1], 'origin-host'); assert.equal(args[args.indexOf('--session') + 1], 'managed-origin');
      if (args[1] === 'inspect') return { stdout: JSON.stringify({ protocolVersion: 1, name, size: body.length, modifiedAt: '2026-10-06T10:00:00Z', revision: digest(), mediaKind: kind }) };
      assert.equal(args[args.indexOf('--expected-revision') + 1], digest());
      const output = args[args.indexOf('--output-dir') + 1]; await fs.writeFile(path.join(output, name), body);
      return { stdout: JSON.stringify({ status: 'downloaded', name, size: body.length, sha256: digest() }) };
    }
  });
  const wait = async (predicate, message) => {
    for (let attempt = 0; attempt < 300; attempt++) { if (await predicate()) return; await new Promise(resolve => setTimeout(resolve, 100)); }
    throw new Error(message);
  };
  try {
    const links = await files.provider.provideTerminalLinks({ terminal: origin, line: 'See /tmp/outside.txt' });
    assert.equal(links.length, 1); assert.equal(calls.length, 0);
    other.show();
    const panel = await files.provider.handleTerminalLink(links[0]); assert.ok(panel);
    panel.webview.onDidReceiveMessage(message => { if (message.reviewProbe) probes.push(message); else requests.push(message); });
    await wait(() => probes.some(probe => probe.text === 'Current host bytes'), 'Actual VS Code text webview did not render');
    assert.ok(probes.some(probe => probe.title?.includes('origin-host')));
    panel.dispose(); await wait(() => fs.stat(states.at(-1).folder).then(() => false, () => true), 'Closing VS Code preview retained temporary bytes');
    kind = 'html'; name = 'interactive.html';
    body = Buffer.from(`<button id="counter" onclick="this.textContent='Clicked'">Click me</button><script>
      const result={type:'iframe-review',bridge:'',network:'',file:'',interactive:''};
      try{result.bridge=typeof parent.hostFilePreview}catch{result.bridge='blocked'}
      Promise.all([fetch('https://example.invalid/file-preview').then(()=>result.network='allowed').catch(()=>result.network='blocked'),
      fetch('file:///C:/Windows/win.ini').then(()=>result.file='allowed').catch(()=>result.file='blocked')]).then(()=>{
      document.getElementById('counter').click();result.interactive=document.getElementById('counter').textContent;parent.postMessage(result,'*')})</script>`);
    const htmlPanel = await files.open(origin, '/tmp/interactive.html');
    htmlPanel.webview.onDidReceiveMessage(message => { if (message.reviewProbe) probes.push(message); });
    await wait(() => probes.some(probe => probe.html), 'VS Code HTML sandbox probe did not return');
    const html = probes.find(probe => probe.html).html;
    assert.deepEqual({ bridge: html.bridge, network: html.network, file: html.file, interactive: html.interactive }, { bridge: 'blocked', network: 'blocked', file: 'blocked', interactive: 'Clicked' });
    htmlPanel.dispose();
    await fs.mkdir(directory, { recursive: true });
    await fs.writeFile(path.join(directory, 'receipt.json'), JSON.stringify({ status: 'passed', probes, calls, limitations: ['Actual VS Code terminals and webviews; deterministic source replaces live host transport.'] }, null, 2));
  } catch (error) { await fs.writeFile(path.join(directory, 'failure.json'), JSON.stringify({ error: error.message, states, calls, probes, requests }, null, 2)); throw error; }
  finally { subscriptions.forEach(item => item.dispose()); origin.dispose(); other.dispose(); }
};
