const vscode=require('vscode');
const fs=require('node:fs/promises');
const path=require('node:path');
const crypto=require('node:crypto');
const assert=require('node:assert/strict');
const {registerHostFiles}=require('../src/host-files');
const {hostFileRowReferences}=require('../src/host-file-reference');
exports.run=async()=>{
  const directory=process.env.WTMUX_WRAPPED_REVIEW; if(!directory)throw new Error('Isolated report directory is required.');
  await fs.mkdir(directory,{recursive:true});
  const subscriptions=[]; const calls=[]; const emitter=new vscode.EventEmitter();
  const cases=[{name:'absolute',rows:['  Open (/home/user/projects/very-long-project/','  reports/wrapped-report.md)'],target:'/home/user/projects/very-long-project/reports/wrapped-report.md'},
    {name:'relative',rows:['  Open (reports/very-long-','  report.md)'],target:'reports/very-long-report.md'}];
  for(const item of cases){item.body='Verified origin-host / verified-project contents for '+item.target;item.file=path.join(directory,item.name+'.txt');await fs.writeFile(item.file,item.body)}
  let selected=cases[0]; let panel; let state; let stopped=false;
  const terminal=vscode.window.createTerminal({name:'wtmux wrapped origin',pty:{onDidWrite:emitter.event,open:()=>emitter.fire(selected.rows.join('\r\n')+'\r\n'),close(){}}});
  terminal.show();
  const files=registerHostFiles(vscode,{subscriptions,extensionPath:path.resolve(__dirname,'..')},{
    isManaged:t=>t===terminal,binding:()=>selected.name,resolve:async()=>({hostId:'origin-host',session:'managed-origin',project:'verified-project'}),
    invocation:args=>({command:'fixture',args}),localPath:async value=>value,downloadsDirectory:()=>path.join(directory,'Downloads'),
    onState:(value,folder)=>{state=value;void fs.writeFile(path.join(directory,'state.json'),JSON.stringify({state:value,calls,case:selected.name,folder}));},
    runInvocation:async(invocation,signal)=>{
      const args=invocation.args;assert.equal(args[args.indexOf('--host')+1],'origin-host');assert.equal(args[args.indexOf('--session')+1],'managed-origin');
      calls.push(args);
      if(args[0]==='pane'){
        const line=args.at(-1);const row=selected.rows.indexOf(line.trimEnd());
        const links=hostFileRowReferences(selected.rows.map(text=>({text}))).filter(ref=>ref.row===row).map(({row,...ref})=>ref);
        return{stdout:JSON.stringify({protocolVersion:1,type:'pane.links',hostId:'origin-host',session:'managed-origin',projectRoot:'/verified-project',line,revision:crypto.createHash('sha256').update(selected.rows.join('\n')).digest('hex'),links})};
      }
      assert.equal(args[args.indexOf('--path')+1],selected.target,'A visible fragment must never be fetched');
      const body=await fs.readFile(selected.file);const digest=crypto.createHash('sha256').update(body).digest('hex');
      if(args[1]==='inspect')return{stdout:JSON.stringify({protocolVersion:1,name:path.basename(selected.target),size:body.length,modifiedAt:'2026-10-07T00:00:00Z',revision:digest,mediaKind:'text'})};
      if(signal?.aborted)throw new Error('cancelled');
      const folder=args[args.indexOf('--output-dir')+1];const file=path.join(folder,path.basename(selected.target));await fs.writeFile(file,body);
      return{stdout:JSON.stringify({status:'downloaded',name:path.basename(selected.target),size:body.length,sha256:digest,path:file})};
    }
  });
  // The controller drives actual mouse hover and Ctrl-click through DevTools.
  // This module never calls the provider or its activation method directly.
  const interval=setInterval(async()=>{
    try{
      const command=JSON.parse(await fs.readFile(path.join(directory,'command.json'),'utf8'));
      await fs.unlink(path.join(directory,'command.json'));
      if(command.action==='close'){await vscode.commands.executeCommand('workbench.action.closeActiveEditor');terminal.show();}
      if(command.action==='case'){
        selected=cases.find(item=>item.name===command.name);assert.ok(selected);
        emitter.fire('\x1b[2J\x1b[3J\x1b[H'+selected.rows.join('\r\n')+'\r\n');terminal.show();
      }
      if(command.action==='done')stopped=true;
      if(command.action==='zoom')await vscode.commands.executeCommand('workbench.action.zoomIn');
      await fs.writeFile(path.join(directory,'command-done.json'),JSON.stringify(command));
    }catch(error){if(error.code!=='ENOENT'){await fs.writeFile(path.join(directory,'failure.json'),JSON.stringify({error:error.message}));stopped=true}}
  },100);
  await fs.writeFile(path.join(directory,'ready.json'),JSON.stringify({cases}));
  const deadline=Date.now()+600000;
  try{
    while(!stopped&&Date.now()<deadline)await new Promise(resolve=>setTimeout(resolve,100));
    assert.ok(stopped,'UI controller did not finish');
    assert.ok(calls.filter(args=>args[0]==='file'&&args[1]==='fetch').length>=4,'Expected actual Ctrl-click fetches on both path segments');
    await fs.writeFile(path.join(directory,'extension-receipt.json'),JSON.stringify({status:'passed',calls,limitations:['Real VS Code PTY, production asynchronous provider and preview; deterministic pane lookup and host transport.']},null,2));
  }finally{clearInterval(interval);subscriptions.forEach(item=>item.dispose());terminal.dispose();emitter.dispose();panel?.dispose()}
};
