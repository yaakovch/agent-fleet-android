const fs = require('fs');
const fsp = require('fs/promises');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const cp = require('child_process');
const { StringDecoder } = require('string_decoder');
const { hostFileTarget, hostFileReferences } = require('./host-file-reference');

function metadata(value) {
  if (!value || Object.keys(value).sort().join(',') !== 'mediaKind,modifiedAt,name,protocolVersion,revision,size'
    || value.protocolVersion !== 1 || typeof value.name !== 'string' || !value.name || ['.', '..'].includes(value.name) || value.name.length > 255 || /[/\\\x00-\x1f\x7f-\x9f]/.test(value.name)
    || !Number.isSafeInteger(value.size) || value.size < 0 || value.size > 2 ** 31
    || typeof value.modifiedAt !== 'string' || !Number.isFinite(Date.parse(value.modifiedAt)) || typeof value.revision !== 'string' || !/^[a-f0-9]{64}$/.test(value.revision)
    || !['image', 'pdf', 'html', 'markdown', 'text', 'other'].includes(value.mediaKind)) throw new Error('Host returned invalid file metadata.');
  return value;
}

async function verify(file, size, sha256) {
  const before = await fsp.lstat(file);
  if (!before.isFile() || before.size !== size || !/^[a-f0-9]{64}$/.test(sha256)) throw new Error('Preview failed integrity verification.');
  const digest = crypto.createHash('sha256');
  const handle = await fsp.open(file, fs.constants.O_RDONLY | (fs.constants.O_NOFOLLOW || 0));
  try {
    const descriptor = await handle.stat();
    if (descriptor.ino !== before.ino || descriptor.dev !== before.dev || descriptor.size !== size) throw new Error('Preview changed during verification.');
    for await (const chunk of handle.createReadStream({ autoClose: false })) digest.update(chunk);
    const after = await handle.stat();
    if (after.size !== descriptor.size || after.mtimeMs !== descriptor.mtimeMs || after.ctimeMs !== descriptor.ctimeMs || digest.digest('hex') !== sha256) throw new Error('Preview failed integrity verification.');
  } finally { await handle.close(); }
}

async function publish(source, directory, name, size, sha256) {
  if (!name || path.basename(name) !== name || name === '.' || name === '..') throw new Error('Invalid save name.');
  await verify(source, size, sha256);
  await fsp.mkdir(directory, { recursive: true });
  const parts = path.parse(name);
  const temporary = path.join(directory, `.wtmux-save-${crypto.randomUUID()}.part`);
  try {
  await fsp.copyFile(source, temporary, fs.constants.COPYFILE_EXCL);
  await verify(temporary, size, sha256);
  const handle = await fsp.open(temporary, 'r+');
  try { await handle.sync(); } finally { await handle.close(); }
  for (let index = 0; index < 10000; index++) {
    const target = path.join(directory, index ? `${parts.name} (${index})${parts.ext}` : name);
    try { await fsp.link(temporary, target); }
    catch (error) { if (error.code === 'EEXIST') continue; throw error; }
    try { await verify(target, size, sha256); return target; }
    catch (error) { await fsp.rm(target, { force: true }); throw error; }
  }
  throw new Error('No unused Downloads file name is available.');
  } finally { await fsp.rm(temporary, { force: true }); }
}

/** Own the local process group, including the receiver and its SSH child. */
function runInvocation(invocation, signal, onProgress = () => {}) {
  return new Promise((resolve, reject) => {
    if (signal?.aborted) { reject(new Error('Transfer cancelled. Refresh to retry.')); return; }
    let output = ''; let errors = ''; let lineBuffer = ''; let processGroup = 0; let aborted = false; let failure;
    let outputBytes = 0; let lastReceived = -1; let lastTotal = -1; let settled = false; let escalation; let wrapperStop;
    const outputDecoder = new StringDecoder('utf8'); const errorDecoder = new StringDecoder('utf8');
    const nonce = crypto.randomBytes(16).toString('hex');
    let args = invocation.args;
    const windowsWsl = process.platform === 'win32' && path.basename(invocation.command).toLowerCase() === 'wsl.exe';
    if (windowsWsl) {
      const separator = args.indexOf('--');
      if (separator < 0) { reject(new Error('Managed WSL invocation is invalid.')); return; }
      // Execute argv directly: WSL's default shell expands the wrapper's $@
      // before bash receives it. Wait for setsid's child so WSL keeps its pipes.
      args = [...args.slice(0, separator), '--exec', 'setsid', '--wait', 'bash', '--noprofile', '--norc', '-c',
        'export WTMUX_PREVIEW_PROCESS="$1"; printf "WTMUX_PREVIEW_PROCESS %s %s\\n" "$1" "$BASHPID" >&2; shift; exec "$@"', 'host-file-preview', nonce, ...args.slice(separator + 1)];
    }
    const child = cp.spawn(invocation.command, args, { ...invocation.options, windowsHide: true, shell: false,
      detached: !windowsWsl, stdio: ['ignore', 'pipe', 'pipe'] });
    const terminate = (force = false) => {
      if (windowsWsl && processGroup > 1) {
        const separator = invocation.args.indexOf('--');
        const killScript = 'import os,signal,sys; p=int(sys.argv[1]); token=("WTMUX_PREVIEW_PROCESS="+sys.argv[2]).encode(); env=open("/proc/"+str(p)+"/environ","rb").read().split(b"\\0"); os.killpg(p,signal.SIGKILL if sys.argv[3]=="force" else signal.SIGTERM) if token in env else None';
        const killer = cp.spawn(invocation.command, [...invocation.args.slice(0, separator), '--exec', 'python3', '-c', killScript, String(processGroup), nonce, force ? 'force' : 'graceful'], { windowsHide: true, shell: false, stdio: 'ignore' });
        killer.on('error', () => {});
        killer.unref();
      } else if (!windowsWsl && process.platform === 'win32') child.kill(force ? 'SIGKILL' : 'SIGTERM');
      else if (!windowsWsl && child.pid) { try { process.kill(-child.pid, force ? 'SIGKILL' : 'SIGTERM'); } catch {} }
      else if (force) child.kill();
      if (!force && !escalation) {
        escalation = setTimeout(() => terminate(true), 2000);
        wrapperStop = setTimeout(() => child.kill('SIGKILL'), 5000);
      }
    };
    const abort = () => { aborted = true; terminate(); };
    signal?.addEventListener('abort', abort, { once: true });
    const started = Date.now(); let lastProgress = started;
    const timer = setInterval(() => { if (Date.now() - started > (invocation.timeoutMs || 6 * 60 * 60 * 1000) || Date.now() - lastProgress > 120000) { failure = new Error('Host file transfer timed out. Refresh to retry.'); terminate(); } }, 1000);
    child.stdout.on('data', (chunk) => {
      if (failure) return;
      outputBytes += chunk.length;
      if (outputBytes > 65536) { failure = new Error('Host file response exceeded its limit.'); terminate(); return; }
      output += outputDecoder.write(chunk);
    });
    child.stderr.on('data', (chunk) => {
      if (failure) return;
      lineBuffer += errorDecoder.write(chunk);
      if (lineBuffer.length > 65536) { failure = new Error('Host file progress exceeded its limit.'); terminate(); return; }
      let end;
      while ((end = lineBuffer.indexOf('\n')) >= 0) {
        const line = lineBuffer.slice(0, end); lineBuffer = lineBuffer.slice(end + 1);
        const marker = new RegExp(`^WTMUX_PREVIEW_PROCESS ${nonce} ([0-9]+)$`).exec(line);
        if (marker) { processGroup = Number(marker[1]); if (aborted) terminate(); continue; }
        let progress;
        try { progress = JSON.parse(line); } catch {}
        if (progress?.type === 'progress') {
          if (!Number.isSafeInteger(progress.received) || !Number.isSafeInteger(progress.total) || progress.received < 0 || progress.received > progress.total || progress.total > 2 ** 31 || progress.received < lastReceived || (lastTotal >= 0 && progress.total !== lastTotal)) {
            failure = new Error('Host returned invalid file progress.'); terminate(); return;
          }
          lastProgress = Date.now(); lastReceived = progress.received; lastTotal = progress.total; onProgress(progress);
        } else errors = (errors + line).slice(-4096);
      }
    });
    const finish = (error, result) => { if (settled) return; settled = true; clearInterval(timer); clearTimeout(escalation); clearTimeout(wrapperStop); signal?.removeEventListener('abort', abort); error ? reject(error) : resolve(result); };
    child.once('error', (error) => finish(error));
    child.once('close', (code) => finish(aborted ? new Error('Transfer cancelled. Refresh to retry.') : failure || (code !== 0 ? new Error('Host file is unavailable, changed, or disconnected. Refresh to retry.') : null), { stdout: output + outputDecoder.end(), stderr: errors }));
    if (signal?.aborted) abort();
  });
}

function registerHostFiles(vscode, context, dependencies) {
  const viewers = new Set();
  const lookups = new WeakMap();
  const pendingLookups = new Set();
  const expire = async () => {
    for (const name of await fsp.readdir(os.tmpdir())) {
      if (!/^wtmux-host-file-(?:external-)?[A-Za-z0-9_-]+$/.test(name)) continue;
      const file = path.join(os.tmpdir(), name);
      const stat = await fsp.lstat(file).catch(() => null);
      if (stat?.isDirectory() && Date.now() - stat.mtimeMs > 24 * 60 * 60 * 1000) await fsp.rm(file, { recursive: true, force: true }).catch(() => {});
    }
  };
  const assets = path.join(context.extensionPath, 'media', 'host-file-preview');
  const downloadsDirectory = dependencies.downloadsDirectory || (() => path.join(os.homedir(), 'Downloads'));
  const execute = dependencies.runInvocation || runInvocation;
  const bindingKey = target => JSON.stringify([target.hostId, target.session, target.project]);
  async function lookup(terminal, line, signal) {
    const target = await dependencies.resolve(terminal, signal);
    if (signal?.aborted || !dependencies.isManaged(terminal)) throw new Error('Terminal lookup cancelled.');
    const raw = JSON.parse((await execute(dependencies.invocation(['pane', 'links', '--host', target.hostId, '--session', target.session, '--line', line]), signal)).stdout);
    if (!raw || Object.keys(raw).sort().join(',') !== 'hostId,line,links,projectRoot,protocolVersion,revision,session,type'
      || raw.protocolVersion !== 1 || raw.type !== 'pane.links' || raw.hostId !== target.hostId || raw.session !== target.session || raw.line !== line
      || typeof raw.projectRoot !== 'string' || !raw.projectRoot || raw.projectRoot.length > 4096 || /[\u0000-\u001f\u007f-\u009f]/u.test(raw.projectRoot)
      || !/^[a-f\d]{64}$/u.test(raw.revision) || !Array.isArray(raw.links) || raw.links.length > 256) throw new Error('Invalid pane link response.');
    let end = 0;
    for (const ref of raw.links) {
      if (!ref || Object.keys(ref).sort().join(',') !== 'end,start,target' || !Number.isInteger(ref.start) || !Number.isInteger(ref.end)
        || ref.start < end || ref.end <= ref.start || ref.end > line.length || typeof ref.target !== 'string' || !hostFileTarget(ref.target)) throw new Error('Invalid pane link range.');
      end = ref.end;
    }
    return { target, raw };
  }
  const provider = {
    async provideTerminalLinks(request, token) {
      if (!dependencies.isManaged(request.terminal)) return [];
      if (!request.line.trim() || request.line.length > 8192 || token?.isCancellationRequested) return [];
      let state = lookups.get(request.terminal);
      if (state?.line === request.line && state.result && Date.now() - state.time < 1000 && state.fingerprint === dependencies.binding?.(request.terminal)) return state.result;
      state?.controller.abort();
      const controller = new AbortController();
      const fingerprint = dependencies.binding?.(request.terminal);
      state = { controller, line: request.line, time: 0, fingerprint }; lookups.set(request.terminal, state); pendingLookups.add(controller);
      const cancellation = token?.onCancellationRequested(() => controller.abort());
      try {
        const { target, raw } = await lookup(request.terminal, request.line, controller.signal);
        if (controller.signal.aborted || lookups.get(request.terminal) !== state || !dependencies.isManaged(request.terminal) || dependencies.binding?.(request.terminal) !== fingerprint) return [];
        state.result = raw.links.map(ref => ({ startIndex: ref.start, length: ref.end - ref.start,
          tooltip: 'Preview file from this managed session’s host', terminal: request.terminal, reference: ref.target,
          line: request.line, binding: bindingKey(target), revision: raw.revision, projectRoot: raw.projectRoot }));
        state.time = Date.now();
        return state.result;
      } catch { return []; }
      finally { cancellation?.dispose(); pendingLookups.delete(controller); }
    },
    async handleTerminalLink(link) {
      lookups.get(link.terminal)?.controller.abort();
      const controller = new AbortController();
      lookups.set(link.terminal, {controller, line: link.line, time: 0}); pendingLookups.add(controller);
      try {
        if (!dependencies.isManaged(link.terminal)) throw new Error('The managed terminal binding changed.');
        const { target, raw } = await lookup(link.terminal, link.line, controller.signal);
        if (bindingKey(target) !== link.binding || raw.revision !== link.revision || raw.projectRoot !== link.projectRoot
          || !raw.links.some(ref => ref.target === link.reference && ref.start === link.startIndex && ref.end - ref.start === link.length)) throw new Error('The terminal link changed. Hover over it again.');
        return open(link.terminal, link.reference, link.binding);
      } catch (error) { vscode.window.showErrorMessage(error.message); }
      finally { pendingLookups.delete(controller); }
    }
  };
  context.subscriptions.push(vscode.window.registerTerminalLinkProvider(provider));
  context.subscriptions.push(vscode.commands.registerCommand('wtmux.openHostFile', async () => {
    const terminal = vscode.window.activeTerminal;
    if (!terminal || !dependencies.isManaged(terminal)) { vscode.window.showErrorMessage('Select a managed wtmux terminal first.'); return; }
    const reference = await vscode.window.showInputBox({ prompt: 'Host file path or file URI', ignoreFocusOut: true,
      validateInput: (value) => hostFileTarget(value, true) ? undefined : 'Enter a clear path on this managed session’s host.' });
    if (reference) await open(terminal, reference);
  }));
  context.subscriptions.push({ dispose() { for (const controller of pendingLookups) controller.abort(); for (const viewer of viewers) viewer.dispose(); } });

  async function open(terminal, reference, expectedBinding) {
    let createdDirectory; let createdPanel;
    try {
      if (viewers.size >= 4) throw new Error('Close a file preview before opening another.');
      if (!hostFileTarget(reference, true) || !dependencies.isManaged(terminal)) throw new Error('This terminal has no verified managed host binding.');
      const target = await dependencies.resolve(terminal);
      if (expectedBinding && bindingKey(target) !== expectedBinding) throw new Error('The managed terminal binding changed. Hover over the link again.');
      await expire();
      const directory = createdDirectory = await fsp.mkdtemp(path.join(os.tmpdir(), 'wtmux-host-file-'));
      const panel = vscode.window.createWebviewPanel('wtmux.hostFilePreview', 'Host file preview', vscode.ViewColumn.Active,
        { enableScripts: true, retainContextWhenHidden: true, localResourceRoots: [vscode.Uri.file(assets), vscode.Uri.file(directory)] });
      createdPanel = panel;
      viewers.add(panel);
      const operations = new Set();
      const track = (operation) => { operations.add(operation); void operation.finally(() => operations.delete(operation)).catch(() => {}); return operation; };
      let closed = false; let generation = 0; let controller = new AbortController(); let work = Promise.resolve();
      let state = { message: 'Inspecting current host file…', ready: false, busy: false, url: '', host: target.hostId };
      let artifact;
      const update = () => { if (!closed) void panel.webview.postMessage({ type: 'updated' }); dependencies.onState?.(state, directory); };
      const readState = async () => {
        const result = { ...state };
        if (artifact && state.metadata && ['text', 'markdown', 'html'].includes(state.metadata.mediaKind)) {
          const maximum = state.metadata.mediaKind === 'html' ? 16 * 1024 * 1024 : 1024 * 1024;
          if (state.metadata.mediaKind !== 'html' || state.metadata.size <= maximum) {
            const handle = await fsp.open(artifact.path, 'r');
            try { const buffer = Buffer.alloc(Math.min(maximum, state.metadata.size)); const read = await handle.read(buffer, 0, buffer.length, 0); result.text = buffer.subarray(0, read.bytesRead).toString('utf8'); }
            finally { await handle.close(); }
          }
          result.excerpt = state.metadata.mediaKind !== 'html' && state.metadata.size > maximum;
        }
        return result;
      };
      const invoke = (args, signal, progress) => execute({ ...dependencies.invocation(['file', ...args, '--host', target.hostId, '--session', target.session]),
        timeoutMs: args[0] === 'inspect' ? 30000 : 6 * 60 * 60 * 1000 }, signal, progress);
      async function refresh() {
        if (state.busy || closed) return;
        const ticket = ++generation; controller.abort(); controller = new AbortController(); artifact = undefined;
        const owned = controller;
        state = { ...state, ready: false, busy: true, url: '', message: 'Inspecting current host file…' }; update();
        try {
          for (const file of await fsp.readdir(directory)) await fsp.rm(path.join(directory, file), { force: true });
          const info = metadata(JSON.parse((await invoke(['inspect', '--path', reference], owned.signal)).stdout));
          if (closed || ticket !== generation) return;
          state.metadata = info; panel.title = info.name;
          if (info.size > 50 * 1024 * 1024) {
            const answer = await vscode.window.showWarningMessage(`Fetch ${info.name} (${(info.size / 1048576).toFixed(1)} MiB) privately for preview?`, { modal: true }, 'Fetch file');
            if (answer !== 'Fetch file') { state.message = 'Transfer cancelled. Refresh to retry.'; return; }
          }
          if (closed || owned.signal.aborted || ticket !== generation) return;
          const outputDirectory = await dependencies.localPath(directory);
          const localName = process.platform === 'win32' ? portableName(info.name) : info.name;
          const response = await invoke(['fetch', '--path', reference, '--expected-revision', info.revision, '--output-dir', outputDirectory, '--output-name', localName, '--yes', '--json', '--json-progress'], owned.signal,
            (progress) => { if (progress.total !== info.size) { owned.abort(); return; } state.message = `Fetching · ${info.size ? Math.floor(progress.received * 100 / info.size) : 100}%`; update(); });
          const result = JSON.parse(response.stdout.trim().split(/\r?\n/).at(-1));
          if (result.status !== 'downloaded' || result.size !== info.size || path.basename(result.name) !== result.name) throw new Error('Host returned invalid file transfer metadata.');
          const file = path.join(directory, result.name); await verify(file, info.size, result.sha256);
          if (closed || ticket !== generation) return;
          artifact = { path: file, size: info.size, sha256: result.sha256, name: result.name };
          state.ready = true; state.message = 'Verified current host file';
          state.url = `${panel.webview.asWebviewUri(vscode.Uri.file(file))}?generation=${ticket}`;
        } catch (error) { if (!closed && ticket === generation) state.message = String(error.message || 'Host file is unavailable. Refresh to retry.').slice(0, 400); }
        finally { if (ticket === generation) state.busy = false; update(); }
      }
      async function action(value) {
        if (value === 'close') { panel.dispose(); return; }
        if (value === 'cancel') { ++generation; controller.abort(); await work.catch(() => {}); artifact = undefined;
          for (const file of await fsp.readdir(directory)) await fsp.rm(path.join(directory, file), { force: true });
          state = { ...state, ready: false, busy: false, url: '', message: 'Transfer cancelled. Refresh to retry.' }; update(); return; }
        if (state.busy) return;
        if (value === 'refresh') { work = refresh(); return; }
        if (!['save', 'open'].includes(value) || !artifact) return;
        state.busy = true; update();
        try {
          if (value === 'save') state.message = `Saved to ${await publish(artifact.path, downloadsDirectory(), artifact.name, artifact.size, artifact.sha256)}`;
          else {
            const lease = await fsp.mkdtemp(path.join(os.tmpdir(), 'wtmux-host-file-external-'));
            const file = await publish(artifact.path, lease, artifact.name, artifact.size, artifact.sha256);
            if (!await vscode.env.openExternal(vscode.Uri.file(file))) { await fsp.rm(lease, { recursive: true, force: true }); throw new Error('No application can open this file.'); }
            state.message = 'Opened in another application';
          }
        } catch (error) { state.message = String(error.message).slice(0, 400); }
        finally { state.busy = false; update(); }
      }
      panel.onDidDispose(() => { closed = true; ++generation; controller.abort(); viewers.delete(panel); void Promise.allSettled([work, ...operations]).then(() => fsp.rm(directory, { recursive: true, force: true })); });
      panel.webview.onDidReceiveMessage(async (request) => {
        if (closed || !request || !Number.isSafeInteger(request.id) || !['state', 'action'].includes(request.method)) return;
        try { const result = await track(request.method === 'state' ? readState() : action(request.action)); if (!closed) void panel.webview.postMessage({ id: request.id, result }); }
        catch (error) { if (!closed) void panel.webview.postMessage({ id: request.id, error: String(error.message).slice(0, 400) }); }
      });
      panel.webview.html = (dependencies.previewHtml || previewHtml)(panel.webview, vscode, assets);
      work = refresh();
      return panel;
    } catch (error) {
      if (createdPanel) createdPanel.dispose();
      else if (createdDirectory) await fsp.rm(createdDirectory, { recursive: true, force: true });
      vscode.window.showErrorMessage(String(error.message || 'Host file preview could not open.').slice(0, 400));
    }
  }
  return { provider, open };
}

function portableName(name) {
  const safe = name.replace(/[<>:"/\\|?*\x00-\x1f\x7f-\x9f]/g, '_').replace(/[. ]+$/, '');
  return /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:[.]|$)/i.test(safe) ? '_' + safe : safe || 'host-file';
}

function previewHtml(webview, vscode, assets) {
  const html = fs.readFileSync(path.join(assets, 'host-file-preview.html'), 'utf8');
  const adapter = `<script>(()=>{const hostOrigin=window.origin;const vscode=acquireVsCodeApi();let serial=0;const pending=new Map();const callbacks=[];const call=(method,action)=>new Promise((resolve,reject)=>{const id=++serial;pending.set(id,{resolve,reject});vscode.postMessage({id,method,action})});window.hostFilePreview={state:()=>call('state'),action:action=>call('action',action),updated:callback=>callbacks.push(callback)};window.addEventListener('message',event=>{if(hostOrigin==='null'||event.origin!==hostOrigin)return;const data=event.data;if(!data)return;if(data.type==='updated'){callbacks.forEach(callback=>callback());return}const wait=pending.get(data.id);if(wait){pending.delete(data.id);data.error?wait.reject(new Error(data.error)):wait.resolve(data.result)}})})();</script>`;
  return html.replace(/<meta http-equiv="Content-Security-Policy"[^>]+>/i,
    `<meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src ${webview.cspSource} 'unsafe-inline' 'unsafe-eval'; style-src ${webview.cspSource} 'unsafe-inline'; img-src ${webview.cspSource} data: blob:; connect-src ${webview.cspSource}; worker-src ${webview.cspSource} blob:; frame-src 'self' blob:; font-src data:">`)
    .replace(/(?:src|href)="\.\/([^"<>]+)"/g, (attribute, relative) => attribute.replace(`./${relative}`, webview.asWebviewUri(vscode.Uri.file(path.join(assets, relative))).toString()))
    .replace('<head>', `<head>${adapter}`);
}

module.exports = { registerHostFiles, hostFileReferences, hostFileTarget, metadata, verify, publish, runInvocation, previewHtml };
