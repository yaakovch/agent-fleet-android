"""Rebuildable transcript offset index. Conversation text stays in its source.

Every reused record is checked against its original bytes. The index accelerates
projection of hidden activity; requested content still passes the real normalizer.
Storage failure never changes the bounded uncached parser's behavior.
"""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import stat
import time
from typing import Any, Callable

PARSER_VERSION = 3
MAX_BYTES = 64 * 1024 * 1024
MAX_SCAN_BYTES = 16 * 1024 * 1024


def private_directory(path: Path) -> None:
    path.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = path.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        raise OSError("history index directory is not private")


def structural_record(record: dict[str, Any]) -> dict[str, Any]:
    """Only provider identities and boundary/lifecycle flags, never text."""
    result = {key: record[key] for key in ("type", "uuid", "id", "turn_id", "turnId", "isMeta", "timestamp")
              if isinstance(record.get(key), (str, bool))}
    if record.get("subtype") == "turn_duration":
        result["subtype"] = "turn_duration"
    payload = record.get("payload")
    if isinstance(payload, dict):
        result["payload"] = {key: payload[key] for key in ("type", "turn_id", "call_id", "id", "role") if isinstance(payload.get(key), str)}
        if payload.get("name") in {"request_user_input_async", "request_user_input", "update_plan"}:
            result["payload"]["name"] = payload["name"]
        mode = payload.get("collaboration_mode_kind")
        if isinstance(mode, str):
            result["payload"]["collaboration_mode_kind"] = "plan" if mode.lower() == "plan" else "default"
        for key in ("collaboration_mode", "thread_settings"):
            parent = payload.get(key)
            if isinstance(parent, dict):
                modes: dict[str, Any] = {}
                if isinstance(parent.get("mode"), str):
                    modes["mode"] = "plan" if parent["mode"].lower() == "plan" else "default"
                nested = parent.get("collaboration_mode")
                if isinstance(nested, dict) and isinstance(nested.get("mode"), str):
                    modes["collaboration_mode"] = {"mode": "plan" if nested["mode"].lower() == "plan" else "default"}
                result["payload"][key] = modes
        completed = payload.get("item")
        if isinstance(completed, dict):
            result["payload"]["item"] = {key: completed[key] for key in ("type", "phase", "id", "delivery") if isinstance(completed.get(key), str)}
        if isinstance(payload.get("phase"), str):
            result["payload"]["phase"] = payload["phase"]
    if record.get("type") == "user" and isinstance(record.get("message"), dict):
        content = record["message"].get("content")
        real_user = isinstance(content, str) or (isinstance(content, list) and any(
            isinstance(part, dict) and part.get("type") in {"text", "input_text"} for part in content))
        result["message"] = {"content": "" if real_user else [
            {"type": "tool_result", "tool_use_id": part["tool_use_id"]} for part in content or []
            if isinstance(part, dict) and part.get("type") == "tool_result" and isinstance(part.get("tool_use_id"), str)]}
    if isinstance(record.get("permissionMode"), str):
        result["permissionMode"] = "plan" if record["permissionMode"].lower() == "plan" else "default"
    if isinstance(record.get("data"), dict) and isinstance(record["data"].get("toolCallId"), str):
        result["data"] = {"toolCallId": record["data"]["toolCallId"]}
    return result


def structural_values(values: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [{**{key: value[key] for key in ("id", "kind", "role", "state", "timestamp") if key in value},
             "text": "", "attachments": [""] if value.get("attachments") else []} for value in values]


def hidden_activity(values: list[dict[str, Any]]) -> bool:
    return all(value.get("kind") in {"tool", "change", "status", "activity"}
               and value.get("state") != "error" and not value.get("attachments")
               and not value.get("answers") and not value.get("questions") for value in values)


def stateful_record(record: dict[str, Any] | None) -> bool:
    # Claude TaskCreate can emit no rows while still creating normalizer state.
    # Reconstruct that state from the source before processing its later result.
    if record is None:
        return False
    content = (record.get("message") or {}).get("content") if isinstance(record.get("message"), dict) else None
    return isinstance(content, list) and any(isinstance(part, dict) and part.get("type") == "tool_use"
        and part.get("name") in {"TaskCreate", "TaskUpdate", "TodoWrite"} for part in content)


def cache_root() -> Path:
    return Path(os.environ.get("WTMUX_HISTORY_INDEX_DIR", str(Path(os.environ.get(
        "XDG_CACHE_HOME", str(Path.home() / ".cache"))) / "wtmux/history-v1")))


def entry_size(root: Path) -> int:
    return sum(path.lstat().st_size for path in root.iterdir() if path.is_file() and not path.is_symlink())


def evict(root: Path, active: Path, reserve: int = 0) -> None:
    """Call under the directory lock. Never remove an entry held by a reader."""
    entries = sorted([*root.glob("*.sqlite3"), *root.glob("binding-*.json")], key=lambda path: path.stat().st_mtime_ns)
    for path in entries:
        if entry_size(root) + reserve <= MAX_BYTES:
            return
        if path == active or path.is_symlink():
            continue
        try:
            with path.with_suffix(".lock").open("a+b") as lock:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                for candidate in (path, Path(str(path) + "-journal"), Path(str(path) + "-wal"), Path(str(path) + "-shm")):
                    candidate.unlink(missing_ok=True)
        except (OSError, BlockingIOError):
            continue


def indexed_records(path: Path, adapter: str, incarnation: str, data: bytes, start: int,
                    decode: Callable, normalize: Callable, *, details: bool) -> list[tuple[int, int, dict, list[dict]]]:
    """Decode missing records incrementally within the caller's original scan budget."""
    def uncached():
        values = []
        position = start
        for raw in data.splitlines(keepends=True):
            record = decode(raw.rstrip(b"\r\n"))
            if record is not None:
                values.append((position, position + len(raw), record, normalize(record, position)))
            position += len(raw)
        return values
    if not incarnation or os.environ.get("WTMUX_HISTORY_INDEX", "1") == "0" or len(data) > MAX_SCAN_BYTES:
        return uncached()
    root = cache_root()
    info = path.stat()
    key = hashlib.sha256(json.dumps([incarnation, str(path.resolve()), info.st_dev, info.st_ino,
                                     adapter, PARSER_VERSION]).encode()).hexdigest()
    destination = root / f"{key}.sqlite3"
    try:
        private_directory(root)
        # Nonblocking admission: an active builder/reader must not delay content.
        with (root / "budget.lock").open("a+b") as budget_lock, destination.with_suffix(".lock").open("a+b") as source_lock:
            os.chmod(budget_lock.name, 0o600)
            os.chmod(source_lock.name, 0o600)
            fcntl.flock(budget_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            fcntl.flock(source_lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            reserve = 16 * 1024 if not destination.exists() else destination.stat().st_size
            evict(root, destination, reserve)
            if entry_size(root) + reserve > MAX_BYTES:
                return uncached()
            if destination.exists() and (destination.is_symlink() or destination.stat().st_uid != os.getuid()):
                return uncached()
            with contextlib.closing(sqlite3.connect(destination, timeout=.05)) as database:
                os.chmod(destination, 0o600)
                database.execute("PRAGMA journal_mode=DELETE")
                database.execute("PRAGMA max_page_count=8192")  # 32 MiB per entry; leaves room for its journal.
                database.execute("CREATE TABLE IF NOT EXISTS records (offset INTEGER PRIMARY KEY, length INTEGER, digest TEXT, recipe TEXT)")
                database.execute("CREATE TABLE IF NOT EXISTS source (size INTEGER, mtime INTEGER)")
                prior = database.execute("SELECT size, mtime FROM source").fetchone()
                if prior and (info.st_size < prior[0] or (info.st_size == prior[0] and info.st_mtime_ns != prior[1])):
                    database.execute("DELETE FROM records")
                known = {row[0]: row[1:] for row in database.execute(
                    "SELECT offset, length, digest, recipe FROM records WHERE offset >= ? AND offset < ?", (start, start + len(data)))}
                output = []
                pending = []
                position = start
                for raw in data.splitlines(keepends=True):
                    digest = hashlib.sha256(raw).hexdigest()
                    cached = known.get(position)
                    if cached and cached[:2] == (len(raw), digest):
                        recipe = json.loads(cached[2])
                        record, values = recipe["record"], recipe["values"]
                        if details or not recipe["hidden"]:
                            original = decode(raw.rstrip(b"\r\n"))
                            if original is not None:
                                record, values = original, normalize(original, position)
                    else:
                        record = decode(raw.rstrip(b"\r\n"))
                        values = normalize(record, position) if record is not None else []
                        recipe = {"record": structural_record(record) if record is not None else None,
                                  "values": structural_values(values), "hidden": hidden_activity(values) and not stateful_record(record)}
                        pending.append((position, len(raw), digest, json.dumps(recipe, separators=(",", ":"))))
                    if record is not None:
                        output.append((position, position + len(raw), record, values))
                    position += len(raw)
                # Bound aggregate disk space, including the rollback journal, before committing.
                growth = sum(len(value[3]) + 160 for value in pending) * 3
                evict(root, destination, growth)
                if entry_size(root) + growth <= MAX_BYTES:
                    database.executemany("INSERT OR REPLACE INTO records VALUES (?, ?, ?, ?)", pending)
                    database.execute("DELETE FROM source")
                    database.execute("INSERT INTO source VALUES (?, ?)", (info.st_size, info.st_mtime_ns))
                    database.commit()
                else:
                    database.rollback()
                os.utime(destination, (time.time(), time.time()))
                return output
    except (OSError, sqlite3.Error, ValueError, KeyError, TypeError):
        return uncached()
