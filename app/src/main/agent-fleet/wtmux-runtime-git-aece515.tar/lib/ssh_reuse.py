"""App-owned, identity-bound OpenSSH masters with independent channel lifetimes."""
from __future__ import annotations

import contextlib
import fcntl
import hashlib
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import time
from typing import Sequence

sys.dont_write_bytecode = True

# OpenSSH creates a temporary listener name by appending a random suffix.
# Reserve that space, including the terminating NUL, on Unix socket platforms.
MAX_CONTROL_PATH_BYTES = 86


def digest_file(path: str) -> str:
    try:
        value = Path(path).expanduser()
        if value.stat().st_size > 1024 * 1024:
            return "unavailable"
        return hashlib.sha256(value.read_bytes()).hexdigest()
    except OSError:
        return ""


def policy_revision(config: str = "") -> str:
    if os.environ.get("WTMUX_TRANSPORT_POLICY_REVISION"):
        return os.environ["WTMUX_TRANSPORT_POLICY_REVISION"]
    path = config or os.environ.get("WTMUX_CONFIG_PATH") or str(Path(os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))) / "wtmux/wtmux.conf")
    return digest_file(path)


def socket_identity(machine: str, endpoint: str, target: str, port: str, engine: str,
                    authentication: str, host_key: str, node: str, identity: str, policy: str) -> str:
    if not host_key and not node:
        raise ValueError("reuse needs verified endpoint evidence")
    # Authentication is bound to effective -G identities (including -i and the
    # agent) in prepare, so equivalent shell and bridge commands share a key.
    return hashlib.sha256(json.dumps([3, machine, endpoint, target, port, engine, authentication, host_key,
                                     node, policy],
                                    separators=(",", ":")).encode()).hexdigest()[:32]


def reuse_options(key: str) -> list[str]:
    enabled = os.environ.get("WTMUX_SSH_REUSE", "1")
    if enabled in {"", "0"}:
        return ["-o", "ControlMaster=no", "-o", "ControlPath=none"]
    if enabled != "1":
        raise ValueError("WTMUX_SSH_REUSE must be 0 or 1")
    persist = os.environ.get("WTMUX_SSH_CONTROL_PERSIST", "30")
    if not persist.isdigit() or int(persist) < 1:
        raise ValueError("WTMUX_SSH_CONTROL_PERSIST must be positive seconds")
    root = Path(os.environ.get("WTMUX_SSH_CONTROL_DIR") or str(Path(
        os.environ.get("XDG_RUNTIME_DIR") or os.environ.get("TMPDIR") or "/tmp") / f"wtmux-ssh-{os.getuid()}"))
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    info = root.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid() or info.st_mode & 0o077:
        return ["-o", "ControlMaster=no", "-o", "ControlPath=none"]
    return ["-o", "ControlMaster=auto", "-o", f"ControlPersist={persist}", "-o", f"ControlPath={root / key}"]


def prepare(command: Sequence[str]) -> list[str]:
    """Create/check a master without executing the channel's remote command.

    A local pooling failure falls back to the same pinned direct command. Never
    replay a remote action, stop a shared master, or weaken endpoint verification.
    """
    values = list(command)
    if not values or Path(values[0]).name != "ssh":
        return values
    if os.environ.get("WTMUX_SSH_REUSE", "1") in {"", "0"}:
        return direct(values)
    path = next((value.split("=", 1)[1] for value in values if value.startswith("ControlPath=")), "")
    if not path or path == "none":
        return values
    # Both builders append target and remote command last. Channel-specific TTY
    # options are irrelevant to a master and cannot split a shared connection.
    target, remote = values[-2:]
    base = [values[0]]
    index = 1
    while index < len(values) - 2:
        value = values[index]
        if value in {"-t", "-tt"}:
            index += 1
        elif value == "-o" and values[index + 1].startswith(("ControlMaster=", "ControlPath=", "ControlPersist=")):
            index += 2
        else:
            base.append(value)
            index += 1
    try:
        config = subprocess.run([*base, "-G", target], capture_output=True, timeout=2, check=False)
        if config.returncode or len(config.stdout) > 128 * 1024:
            return direct(values)
        settings = config.stdout.decode("utf-8", "replace").splitlines()
        identities = [line.split(" ", 1)[1] for line in settings if line.startswith("identityfile ")]
        relevant = [line for line in settings if not line.startswith(("control", "requesttty ", "connecttimeout "))]
        auth = [digest_file(value) for value in identities]
        if os.environ.get("SSH_AUTH_SOCK"):
            agent = subprocess.run(["ssh-add", "-L"], capture_output=True, timeout=.5, check=False)
            if agent.returncode not in (0, 1) or len(agent.stdout) > 128 * 1024:
                return direct(values)
            auth.append(hashlib.sha256(agent.stdout).hexdigest())
        evidence = hashlib.sha256(json.dumps([relevant, auth], separators=(",", ":")).encode()).hexdigest()[:16]
        # Remain within Unix socket length limits; endpoint and auth digests both
        # participate in the final key used by shell commands and the bridge.
        socket = Path(path).with_name(hashlib.sha256((Path(path).name + evidence).encode()).hexdigest()[:24])
        if len(os.fsencode(socket)) > MAX_CONTROL_PATH_BYTES:
            return direct(values)
        lock_path = socket.with_suffix(".lock")
        if lock_path.is_symlink():
            return direct(values)
        with lock_path.open("a+b") as lock:
            os.chmod(lock_path, 0o600)
            deadline = time.monotonic() + 1
            while True:
                try:
                    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    break
                except BlockingIOError:
                    if time.monotonic() >= deadline:
                        return direct(values)
                    time.sleep(.01)
            def healthy():
                try:
                    info = socket.lstat()
                    return stat.S_ISSOCK(info.st_mode) and info.st_uid == os.getuid() and subprocess.run(
                        [*base, "-S", str(socket), "-O", "check", target], stdout=subprocess.DEVNULL,
                        stderr=subprocess.DEVNULL, timeout=1, check=False).returncode == 0
                except (OSError, subprocess.SubprocessError):
                    return False
            if not healthy():
                if socket.exists():
                    info = socket.lstat()
                    if not stat.S_ISSOCK(info.st_mode) or info.st_uid != os.getuid():
                        return direct(values)
                    socket.unlink()
                persist = next((value for value in values if value.startswith("ControlPersist=")), "ControlPersist=30")
                subprocess.run([*base, "-M", "-N", "-f", "-o", persist, "-o", f"ControlPath={socket}", "-o", "ServerAliveInterval=5", "-o", "ServerAliveCountMax=1", target],
                               stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10, check=False)
                if not healthy():
                    return direct(values)
            result = without_reuse(values)
            return [*result[:-2], "-o", "ControlMaster=no", "-o", f"ControlPath={socket}", target, remote]
    except (OSError, subprocess.SubprocessError, ValueError):
        return direct(values)


def without_reuse(command: Sequence[str]) -> list[str]:
    result = []
    index = 0
    while index < len(command):
        if command[index] == "-o" and index + 1 < len(command) and command[index + 1].startswith(("ControlMaster=", "ControlPersist=", "ControlPath=")):
            index += 2
        else:
            result.append(command[index])
            index += 1
    return result


def direct(command: Sequence[str]) -> list[str]:
    result = without_reuse(command)
    # Override external SSH config's pooling too, while retaining every trust option.
    return [*result[:-2], "-o", "ControlMaster=no", "-o", "ControlPath=none", *result[-2:]]


def main() -> None:
    if sys.argv[1] == "identity":
        print(socket_identity(*sys.argv[2:]))
    elif sys.argv[1] == "options":
        for value in reuse_options(sys.argv[2]):
            sys.stdout.buffer.write(value.encode() + b"\0")
    elif sys.argv[1] == "prepare":
        arguments = sys.argv[2:]
        if arguments[:1] == ["--"]:
            arguments = arguments[1:]
        for value in prepare(arguments):
            sys.stdout.buffer.write(value.encode() + b"\0")
    else:
        raise SystemExit("invalid SSH reuse helper operation")


if __name__ == "__main__":
    with contextlib.suppress(BrokenPipeError):
        main()
