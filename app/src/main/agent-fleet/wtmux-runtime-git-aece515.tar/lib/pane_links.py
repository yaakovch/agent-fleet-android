"""Read-only, bounded terminal link lookup. Never reads a selected file."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
import urllib.parse
from typing import Any


def units(value: str) -> int:
    return len(value.encode("utf-16-le")) // 2


def target(value: str, explicit: bool = False) -> str | None:
    if not value or units(value) > 2048 or re.search(r"[\x00-\x1f\x7f-\x9f]", value) or value.startswith(("//", "\\\\")):
        return None
    if value.lower().startswith("file:"):
        try:
            uri = urllib.parse.urlsplit(value)
            decoded = urllib.parse.unquote(uri.path, errors="strict")
            if not value.lower().startswith("file://") or uri.netloc.lower() not in ("", "localhost") or uri.query or uri.fragment or re.search(r"%(?![\da-f]{2})", value, re.I) or re.search(r"[\x00-\x1f\x7f-\x9f]", decoded) or decoded.startswith("//"):
                return None
            return value
        except (ValueError, UnicodeError):
            return None
    drive = re.match(r"^[A-Za-z]:[/\\]", value)
    if re.match(r"^[A-Za-z][A-Za-z\d+.-]*:", value) and not drive:
        return None
    if value.startswith("/") or drive or re.match(r"^\.\.?[/\\]", value):
        return value
    if (explicit or "/" in value or "\\" in value) and re.fullmatch(r'[^<>"|?*]+\.[A-Za-z\d]{1,16}', value):
        return value
    return None


PATTERN = re.compile(r'''(?:"([^"\r\n]+)"|'([^'\r\n]+)'|`([^`\r\n]+)`)|(?:file://[^\s<>"'`]+|[A-Za-z]:[/\\][^\s<>"'`]+|(?:\.{1,2}/|/)[^\s<>"'`]+|[\w.-]+(?:[/\\][\w.-]+)+\.[A-Za-z\d]{1,16})''')
PATH_START = r"(?:file://|[A-Za-z]:[/\\]|\.{1,2}[/\\]|/|[\w.-]+[/\\])"


def row_references(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    text = ""
    locations: list[tuple[int, int] | None] = []
    for row, row_value in enumerate(rows):
        if row and not row_value.get("wrapped", False):
            text += "\n"
            locations.append(None)
        column = 0
        for char in row_value["text"]:
            text += char
            locations.append((row, column))
            column += units(char)
        if units(text) > 65536:
            return []
    blocked: set[int] = set()
    result: list[dict[str, Any]] = []

    def emit(indices: list[int], destination: str) -> None:
        segment: dict[str, Any] | None = None
        for index in indices:
            location = locations[index]
            if location is None:
                continue
            row, column = location
            if segment and segment["row"] == row and segment["end"] == column:
                segment["end"] += units(text[index])
            else:
                segment = {"row": row, "start": column, "end": column + units(text[index]), "target": destination}
                result.append(segment)

    for match in re.finditer(r'''[('"`](?=''' + PATH_START + ")", text):
        start = match.start()
        if start in blocked or (start and re.match(r"[\w:/\\~%$]", text[start - 1])):
            continue
        close = ")" if match[0] == "(" else match[0]
        end = text.find(close, start + 1)
        blocked.update(range(start, len(text) if end < 0 else end + 1))
        if end < 0 or units(text[start:end]) > 8192:
            continue
        first, final = locations[start], locations[end]
        if first is None or final is None or final[0] - first[0] >= 32:
            continue
        first_text = rows[first[0]]["text"]
        base = len(first_text) - len(first_text.lstrip(" "))
        list_match = re.match(r"^ *[-*•] ", first_text)
        list_indent = len(list_match[0]) if list_match else -1
        indices: list[int] = []
        candidate = ""
        valid = True
        i = start + 1
        while i < end:
            if text[i] != "\n":
                candidate += text[i]
                indices.append(i)
                i += 1
                continue
            if candidate and candidate[-1].isspace():
                valid = False
                break
            next_index = i + 1
            while next_index < end and text[next_index] == " ":
                next_index += 1
            indentation = next_index - i - 1
            if indentation and not (indentation >= 2 and indentation in (base, list_indent, first[1] + 1)):
                valid = False
                break
            if next_index == end or text[next_index] in "\n\t" or (re.search(r"\.[A-Za-z\d]{1,16}$", candidate) and re.match(PATH_START, text[next_index:])):
                valid = False
                break
            i = next_index
        if not valid or candidate != candidate.strip() or re.search(r'''[()'"`]''', candidate) or re.search(r"\s+(?:file://|[A-Za-z]:[/\\]|\.{1,2}[/\\]|/)", candidate) or re.search(r"\.[A-Za-z\d]{1,16}\s+[\w.-]+[/\\][^\s]+\.[A-Za-z\d]{1,16}", candidate):
            continue
        destination = target(candidate)
        if destination:
            emit(indices, destination)
    first_row = 0
    while first_row < len(rows):
        last_row = first_row
        while last_row + 1 < len(rows) and rows[last_row + 1].get("wrapped", False):
            last_row += 1
        if last_row - first_row < 32 and not rows[first_row].get("wrapped", False):
            indices = [i for i, location in enumerate(locations) if location and first_row <= location[0] <= last_row]
            value = "".join(text[i] for i in indices)
            for match in PATTERN.finditer(value if units(value) <= 8192 else ""):
                quoted = next((g for g in match.groups() if g is not None), None)
                candidate = quoted if quoted is not None else match[0].rstrip(".,;:!?)]}")
                destination = target(candidate)
                start = match.start() + (1 if quoted is not None else 0)
                if not destination or (start and re.match(r"[\w:/\\~%$]", value[start - 1])):
                    continue
                selected = indices[start:start + len(candidate)]
                if all(i not in blocked for i in selected):
                    emit(selected, destination)
        first_row = last_row + 1
    return sorted(result, key=lambda ref: (ref["row"], ref["start"]))


def complete_records(payload: bytes, maximum: int = 4 * 1024 * 1024) -> bytes:
    """Keep a suffix only after a complete record boundary, never mid-UTF-8/ANSI."""
    if len(payload) <= maximum:
        return payload
    boundary = payload.find(b"\n", len(payload) - maximum)
    return payload[boundary + 1:] if boundary >= 0 else b""


def tmux(*args: str) -> bytes:
    result = subprocess.run(["tmux", *args], capture_output=True, timeout=3, check=False)
    if result.returncode != 0 or len(result.stdout) > 8 * 1024 * 1024:
        raise ValueError("pane unavailable")
    return result.stdout


def capture_rows(physical: bytes, joined: bytes) -> tuple[list[dict[str, Any]], list[tuple[int, int]]] | None:
    """Correlate two tmux captures; infer wraps only when both snapshots agree."""
    lines = physical.decode("utf-8", "strict").splitlines()
    records = joined.decode("utf-8", "strict").splitlines()
    rows: list[dict[str, Any]] = []
    groups: list[tuple[int, int]] = []
    cursor = 0
    for record in records:
        first = cursor
        value = ""
        while cursor < len(lines):
            value += lines[cursor]
            cursor += 1
            if value.rstrip(" ") == record.rstrip(" "):
                break
            if not record.startswith(value):
                return None
        else:
            return None
        for row in range(first, cursor):
            rows.append({"text": lines[row] if row + 1 < cursor else lines[row].rstrip(" "), "wrapped": row > first})
        groups.append((first, cursor))
    return (rows, groups) if cursor == len(lines) else None


def snapshot_references(rows: list[dict[str, Any]], first: int, last: int) -> list[dict[str, Any]]:
    start = max(0, first - 31)
    refs = row_references(rows[start:last + 31])
    offsets = {first: 0}
    for row in range(first + 1, last):
        offsets[row] = offsets[row - 1] + units(rows[row - 1]["text"])
    selected: list[dict[str, Any]] = []
    for ref in refs:
        row = ref["row"] + start
        if first <= row < last:
            value = {"start": offsets[row] + ref["start"], "end": offsets[row] + ref["end"], "target": ref["target"]}
            if selected and selected[-1]["end"] == value["start"] and selected[-1]["target"] == value["target"]:
                selected[-1]["end"] = value["end"]
            else:
                selected.append(value)
    return selected


def lookup(host: str, session: str, line: str) -> dict[str, Any]:
    if not re.fullmatch(r"[A-Za-z0-9._:-]{1,128}", host) or not re.fullmatch(r"[A-Za-z0-9_.-]{1,128}", session) or not line.strip() or units(line) > 8192 or re.search(r"[\x00-\x1f\x7f-\x9f]", line):
        raise ValueError("invalid pane link request")
    binding = tmux("display-message", "-p", "-t", session, "-F", "#{session_name}\t#{session_id}\t#{pane_id}\t#{pane_mode}\t#{@wtmux_project_path}").decode().rstrip("\n")
    fields = binding.split("\t")
    if len(fields) != 5 or fields[0] != session or not fields[4] or units(fields[4]) > 4096 or re.search(r"[\x00-\x1f\x7f-\x9f]", fields[4]):
        raise ValueError("unverified pane binding")
    _, _, pane, mode, project = fields
    history = complete_records(tmux("capture-pane", "-p", "-J", "-S", "-2000", "-t", pane))
    physical = complete_records(tmux("capture-pane", "-p", "-N", "-S", "-2000", "-t", pane))
    view = tmux("capture-pane", "-p", "-N", "-M", "-t", pane) if mode == "copy-mode" else b""
    if binding != tmux("display-message", "-p", "-t", session, "-F", "#{session_name}\t#{session_id}\t#{pane_id}\t#{pane_mode}\t#{@wtmux_project_path}").decode().rstrip("\n"):
        raise ValueError("pane binding changed")
    correlated = capture_rows(physical, history)
    if correlated is None:
        raise ValueError("pane snapshots disagree")
    rows, groups = correlated
    selected: list[dict[str, Any]] | None = None
    ambiguous = False
    # A VS Code line may be a physical redraw row or one logical terminal line.
    sources = [(rows, [(i, i + 1) for i in range(len(rows))]), (rows, groups)]
    if view:
        view_rows: list[dict[str, Any]] = [{"text": value.rstrip(" ")} for value in view.decode("utf-8", "strict").splitlines()]
        for i, value in enumerate(view_rows):
            row_matches = [j for j, row in enumerate(rows) if row["text"].rstrip(" ") == value["text"]]
            if len(row_matches) == 1:
                j = row_matches[0]
                if (i == 0 or j > 0 and view_rows[i - 1]["text"] == rows[j - 1]["text"].rstrip(" ")) and (i + 1 == len(view_rows) or j + 1 < len(rows) and view_rows[i + 1]["text"] == rows[j + 1]["text"].rstrip(" ")):
                    value.update(rows[j])
                    value["historyRow"] = j
        sources.insert(0, (view_rows, [(i, i + 1) for i in range(len(view_rows))]))
    for source_rows, records in sources:
        matches = [(first, last) for first, last in records if "".join(row["text"] for row in source_rows[first:last]).rstrip(" ") == line.rstrip(" ")]
        if len(matches) > 1:
            ambiguous = True
            break
        if not matches:
            continue
        first, last = matches[0]
        history_row = source_rows[first].get("historyRow")
        refs = snapshot_references(rows, history_row, history_row + 1) if history_row is not None else snapshot_references(source_rows, first, last)
        if selected is None:
            selected = refs
        elif selected != refs:
            ambiguous = True
            break
    links = [] if ambiguous else selected or []
    # A line snapshot includes tmux's session/pane IDs. Unrelated output must
    # not invalidate a historical link while the session continues streaming.
    revision = hashlib.sha256(binding.encode() + b"\0" + json.dumps([line, links], ensure_ascii=False).encode()).hexdigest()
    response = {"protocolVersion": 1, "type": "pane.links", "hostId": host, "session": session, "projectRoot": project, "line": line, "revision": revision, "links": links}
    if len(json.dumps(response, ensure_ascii=False).encode()) > 65536:
        response["links"] = []
    return response


def main() -> int:
    try:
        print(json.dumps(lookup(*sys.argv[1:]), ensure_ascii=False, separators=(",", ":")))
        return 0
    except (ValueError, UnicodeError, subprocess.TimeoutExpired):
        print(json.dumps({"protocolVersion": 1, "type": "pane.links.error", "code": "unavailable"}))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
