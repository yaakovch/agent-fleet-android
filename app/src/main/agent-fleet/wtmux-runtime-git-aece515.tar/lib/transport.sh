#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_TRANSPORT_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_TRANSPORT_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/config.sh"
source "${WTMUX_REPO_ROOT}/lib/tailscale.sh"

WTMUX_LAST_PROBE_COMMAND=""
WTMUX_LAST_PROBE_OUTPUT=""
WTMUX_LAST_PROBE_STATUS=""
WTMUX_LAST_PROBE_ENGINE=""
declare -Ag WTMUX_OPENED_TAILSCALE_AUTH_URLS=()

wtmux_run_bounded_command() {
  local stdout_file="$1"
  local stderr_file="$2"
  local stdin_file="$3"
  shift 3
  local runner=(
    python3 "${WTMUX_REPO_ROOT}/scripts/wtmux-bounded-command"
    --timeout "${WTMUX_COMMAND_TIMEOUT_SECONDS:-120}"
    --stdout-limit "${WTMUX_COMMAND_STDOUT_LIMIT_BYTES:-262144}"
    --stderr-limit "${WTMUX_COMMAND_STDERR_LIMIT_BYTES:-8192}"
    --stdin-limit "${WTMUX_COMMAND_STDIN_LIMIT_BYTES:-33554432}"
  )

  if [[ -n "$stdin_file" ]]; then
    runner+=(--stdin-file "$stdin_file")
  fi
  runner+=(-- "$@")
  "${runner[@]}" >"$stdout_file" 2>"$stderr_file"
}

wtmux_extract_tailscale_auth_url() {
  local text="${1:-}"
  printf '%s\n' "$text" | grep -Eo 'https://login\.tailscale\.com/a/[^[:space:]]+' | head -n 1
}

wtmux_open_url() {
  local url="$1"

  if [[ -n "${WTMUX_OPEN_URL_COMMAND:-}" ]]; then
    "${WTMUX_OPEN_URL_COMMAND}" "$url" >/dev/null 2>&1
    return $?
  fi

  case "$(wtmux_detect_platform)" in
    wsl)
      if command -v cmd.exe >/dev/null 2>&1; then
        cmd.exe /C start "" "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
    termux)
      if command -v termux-open-url >/dev/null 2>&1; then
        termux-open-url "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
    *)
      if command -v xdg-open >/dev/null 2>&1; then
        xdg-open "$url" >/dev/null 2>&1
        return $?
      fi
      if command -v open >/dev/null 2>&1; then
        open "$url" >/dev/null 2>&1
        return $?
      fi
      ;;
  esac

  return 1
}

wtmux_handle_tailscale_auth_requirement() {
  local machine_id="$1"
  local output="$2"
  local auth_url=""

  auth_url="$(wtmux_extract_tailscale_auth_url "$output")"
  [[ -n "$auth_url" ]] || return 1

  wtmux_warn "tailscale ssh for ${machine_id} requires browser approval: ${auth_url}"
  if [[ -z "${WTMUX_OPENED_TAILSCALE_AUTH_URLS[$auth_url]:-}" ]]; then
    if wtmux_open_url "$auth_url"; then
      WTMUX_OPENED_TAILSCALE_AUTH_URLS["$auth_url"]=1
      wtmux_info "opened browser for tailscale ssh approval"
    else
      wtmux_warn "could not open browser automatically; visit the approval URL manually"
    fi
  fi

  return 0
}

wtmux_prepare_transport_context() {
  # Populate process-local facts before command substitutions fork. Otherwise
  # each routing step repeats discovery and loses the cache in its subshell.
  wtmux_local_facts
  wtmux_detect_local_machine_id >/dev/null 2>&1 || true
}

wtmux_transport_for_machine() {
  local machine_id="$1"
  local local_machine=""
  local transport_value=""

  local_machine="$(wtmux_detect_local_machine_id 2>/dev/null || true)"
  if [[ -n "$local_machine" && "$machine_id" == "$local_machine" ]]; then
    printf '%s\n' "local"
    return 0
  fi

  transport_value="${WTMUX_FORCE_TRANSPORT:-$(wtmux_machine_field "$machine_id" "transport")}"
  printf '%s\n' "${transport_value:-tailscale}"
}

wtmux_transport_error_code() {
  local status="${1:-1}"
  local output="${2:-}"
  local normalized="${output,,}"

  if [[ "$status" == "0" ]]; then
    printf '%s\n' "OK"
  elif [[ "$output" == *"https://login.tailscale.com/a/"* ]]; then
    printf '%s\n' "SSH_CHECK_REQUIRED"
  elif [[ "$normalized" == *"remote host identification has changed"* ]] \
    || [[ "$normalized" == *"host key verification failed"* ]] \
    || [[ "$normalized" == *"offending "*"-key"* ]]; then
    printf '%s\n' "HOST_KEY_CHANGED"
  elif [[ "$normalized" == *"could not resolve hostname"* ]] \
    || [[ "$normalized" == *"name or service not known"* ]] \
    || [[ "$normalized" == *"temporary failure in name resolution"* ]]; then
    printf '%s\n' "DNS_UNAVAILABLE"
  elif [[ "$normalized" == *"permission denied"* ]] \
    || [[ "$normalized" == *"failed to authenticate"* ]] \
    || [[ "$normalized" == *"no supported authentication methods available"* ]]; then
    printf '%s\n' "SSH_AUTH_REQUIRED"
  elif [[ "$normalized" == *"pseudo-terminal will not be allocated"* ]] \
    || [[ "$normalized" == *"failed to allocate pty"* ]] \
    || [[ "$normalized" == *"no pty"* ]]; then
    printf '%s\n' "TTY_UNAVAILABLE"
  elif [[ "$normalized" == *"wtmux-host:"*"not found"* ]] \
    || [[ "$normalized" == *"wtmux-agent:"*"not found"* ]] \
    || [[ "$normalized" == *"wtmux-host-runtime:"*"not found"* ]] \
    || [[ "$normalized" == *"wtmux-host:"*"no such file"* ]] \
    || [[ "$normalized" == *"wtmux-agent:"*"no such file"* ]] \
    || [[ "$normalized" == *"wtmux-host-runtime:"*"no such file"* ]]; then
    printf '%s\n' "HOST_RUNTIME_MISSING"
  elif [[ "$normalized" == *"protocol mismatch"* ]] \
    || [[ "$normalized" == *"unsupported protocol"* ]] \
    || [[ "$normalized" == *"incompatible protocol"* ]]; then
    printf '%s\n' "HOST_RUNTIME_INCOMPATIBLE"
  elif [[ "$normalized" == *"no server running"* ]] \
    || [[ "$normalized" == *"failed to connect to server"* ]] \
    || [[ "$normalized" == *"tmux server"* ]]; then
    printf '%s\n' "TMUX_UNAVAILABLE"
  elif [[ "$normalized" == *"connection refused"* ]] \
    || [[ "$normalized" == *"connection timed out"* ]] \
    || [[ "$normalized" == *"operation timed out"* ]] \
    || [[ "$normalized" == *"no route to host"* ]] \
    || [[ "$normalized" == *"network is unreachable"* ]] \
    || [[ "$normalized" == *"context deadline exceeded"* ]] \
    || [[ "$normalized" == *"failed to connect"* ]]; then
    printf '%s\n' "NETWORK_UNREACHABLE"
  elif [[ "$status" == "126" || "$status" == "127" ]]; then
    printf '%s\n' "LOCAL_RUNTIME_UNAVAILABLE"
  else
    printf '%s\n' "NETWORK_UNREACHABLE"
  fi
}

wtmux_ssh_engine_for_machine() {
  local machine_id="$1"
  local tty_mode="${2:-none}"
  local transport
  local preference="${WTMUX_SSH_ENGINE:-}"

  transport="$(wtmux_transport_for_machine "$machine_id")"
  if [[ "$transport" == "local" ]]; then
    printf '%s\n' "local"
    return 0
  fi
  if [[ "$transport" == "ssh" ]]; then
    printf '%s\n' "openssh"
    return 0
  fi
  [[ -n "$preference" ]] || preference="$(wtmux_machine_field "$machine_id" "endpoint_ssh_engine")"
  preference="${preference:-auto}"
  case "$preference" in
    auto)
      if command -v ssh >/dev/null 2>&1; then
        printf '%s\n' "openssh"
      else
        printf '%s\n' "tailscale-cli"
      fi
      ;;
    openssh)
      printf '%s\n' "openssh"
      ;;
    tailscale-cli)
      # The CLI adapter has no PTY flag. Preserve the proven OpenSSH terminal
      # path while allowing the previous noninteractive adapter as rollback.
      if [[ "$tty_mode" == "force" ]]; then
        printf '%s\n' "openssh"
      else
        printf '%s\n' "tailscale-cli"
      fi
      ;;
    *)
      wtmux_die "WTMUX_SSH_ENGINE must be auto, openssh, or tailscale-cli"
      ;;
  esac
}

wtmux_transport_socket_identity() {
  local machine_id="$1" remote_target="$2" port="$3" engine="$4"
  local state host_key node_id identity_file policy config_digest=""
  state="$(wtmux_machine_field "$machine_id" endpoint_identity_state)"
  host_key="$(wtmux_machine_field "$machine_id" endpoint_ssh_host_key_sha256)"
  node_id="$(wtmux_machine_field "$machine_id" endpoint_tailscale_node_id)"
  [[ "$state" == "verified" && ( -n "$host_key" || -n "$node_id" ) ]] || return 1
  identity_file="$(wtmux_machine_field "$machine_id" fallback_identity_file)"
  if [[ -n "${WTMUX_CONFIG_LOADED_PATH:-}" && -r "$WTMUX_CONFIG_LOADED_PATH" ]]; then
    config_digest="$(sha256sum "$WTMUX_CONFIG_LOADED_PATH" | awk '{print $1}')"
  fi
  policy="${WTMUX_TRANSPORT_POLICY_REVISION:-$config_digest}"
  python3 "${WTMUX_REPO_ROOT}/lib/ssh_reuse.py" identity "$machine_id" \
    "$(wtmux_machine_field "$machine_id" endpoint_id)" "$remote_target" "$port" "$engine" \
    "$(wtmux_machine_field "$machine_id" endpoint_authentication)" "$host_key" "$node_id" "$identity_file" "$policy"
}

wtmux_ssh_control_persist() {
  # How long an idle multiplexed master lingers after its last session.
  # Short values free resources quickly but re-pay the handshake on every
  # burst of activity; relayed peers benefit from longer windows.
  local value="${WTMUX_SSH_CONTROL_PERSIST:-30}"
  case "$value" in
    ""|*[!0-9]*)
      wtmux_die "WTMUX_SSH_CONTROL_PERSIST must be a whole number of seconds"
      ;;
  esac
  (( value >= 1 )) || wtmux_die "WTMUX_SSH_CONTROL_PERSIST must be at least 1 second"
  printf '%s\n' "$value"
}

wtmux_add_ssh_reuse_options() {
  local target_var="$1"
  local -n command_ref="$target_var"
  local machine_id="$2"
  local remote_target="$3"
  local port="$4"
  local engine="$5"
  local enabled="${WTMUX_SSH_REUSE:-1}"
  local socket_id

  case "$enabled" in
    0|"")
      return 0
      ;;
    1)
      ;;
    *)
      wtmux_die "WTMUX_SSH_REUSE must be 0 or 1"
      ;;
  esac
  socket_id="$(wtmux_transport_socket_identity "$machine_id" "$remote_target" "$port" "$engine")" \
    || wtmux_die "SSH reuse requires a verified endpoint identity"
  local options=()
  mapfile -d '' -t options < <(python3 "${WTMUX_REPO_ROOT}/lib/ssh_reuse.py" options "$socket_id")
  command_ref+=("${options[@]}")
}

wtmux_machine_remote_target() {
  local machine_id="$1"
  local transport
  local user
  local host

  transport="$(wtmux_transport_for_machine "$machine_id")"
  user="$(wtmux_machine_field "$machine_id" "linux_username")"
  if [[ "$transport" == "ssh" ]]; then
    host="$(wtmux_machine_field "$machine_id" "fallback_ssh_host")"
    if [[ -z "$host" ]]; then
      host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    fi
  else
    host="$(wtmux_machine_field "$machine_id" "tailscale_node")"
  fi
  printf '%s@%s\n' "$user" "$host"
}

wtmux_machine_ssh_target() {
  local machine_id="$1"
  local transport
  local user
  local host
  local resolved_host=""
  local endpoint_address

  transport="$(wtmux_transport_for_machine "$machine_id")"
  user="$(wtmux_machine_field "$machine_id" "linux_username")"
  endpoint_address="$(wtmux_machine_field "$machine_id" "endpoint_address")"

  if [[ -n "$endpoint_address" ]]; then
    host="$endpoint_address"
  elif [[ "$transport" == "ssh" ]]; then
    host="$(wtmux_machine_field "$machine_id" "fallback_ssh_host")"
    if [[ -z "$host" ]]; then
      host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    fi
  else
    host="$(wtmux_machine_field "$machine_id" "tailscale_node")"
    resolved_host="$(wtmux_machine_field "$machine_id" "fallback_ip")"
    if [[ -n "$resolved_host" ]]; then
      host="$resolved_host"
    else
      resolved_host="$(wtmux_tailscale_peer_ip "$host" 2>/dev/null || true)"
      if [[ -n "$resolved_host" ]]; then
        host="$resolved_host"
      fi
    fi
  fi

  printf '%s@%s\n' "$user" "$host"
}

wtmux_require_verified_endpoint() {
  local machine_id="$1"
  local engine="$2"
  local network state host_key node_id

  network="$(wtmux_machine_field "$machine_id" "endpoint_network")"
  state="$(wtmux_machine_field "$machine_id" "endpoint_identity_state")"
  host_key="$(wtmux_machine_field "$machine_id" "endpoint_ssh_host_key_sha256")"
  node_id="$(wtmux_machine_field "$machine_id" "endpoint_tailscale_node_id")"

  if [[ "$state" != "verified" ]]; then
    wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} endpoint identity is ${state:-unverified}"
  fi
  if [[ "$engine" == "openssh" && -z "$host_key" ]]; then
    wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} has no verified SSH host-key evidence"
  fi
  if [[ "$network" == "tailnet" && -z "$node_id" ]]; then
    wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} has no verified Tailnet node evidence"
  fi
  if [[ "$engine" == "tailscale-cli" && -z "$node_id" ]]; then
    wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} has no verified Tailnet node evidence"
  fi
}

wtmux_bind_endpoint_evidence() {
  local machine_id="$1"
  local engine="$2"
  local address network port host_key node_id tailscale_node pinned

  address="$(wtmux_machine_field "$machine_id" "endpoint_address")"
  network="$(wtmux_machine_field "$machine_id" "endpoint_network")"
  port="$(wtmux_machine_field "$machine_id" "endpoint_port")"
  port="${port:-22}"
  host_key="$(wtmux_machine_field "$machine_id" "endpoint_ssh_host_key_sha256")"
  node_id="$(wtmux_machine_field "$machine_id" "endpoint_tailscale_node_id")"
  tailscale_node="$(wtmux_machine_field "$machine_id" "tailscale_node")"

  if ! pinned="$(
    python3 "${WTMUX_REPO_ROOT}/lib/endpoint_evidence.py" \
      --address "$address" \
      --port "$port" \
      --engine "$engine" \
      --network "$network" \
      --ssh-host-key "$host_key" \
      --tailscale-node-id "$node_id" \
      --tailscale-node "$tailscale_node" \
      2>/dev/null
  )"; then
    wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} endpoint evidence does not match the live transport"
  fi
  printf '%s\n' "$pinned"
}

wtmux_ssh_connect_timeout() {
  python3 "${WTMUX_REPO_ROOT}/lib/connection_budget.py" connect
}

wtmux_build_ssh_command_internal() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  local tty_mode="${3:-none}"
  shift 3
  local remote_target
  local identity_file
  local remote_shell
  local remote_command
  local port
  local pinned_known_hosts

  remote_target="$(wtmux_machine_ssh_target "$machine_id")"
  identity_file="$(wtmux_machine_field "$machine_id" "fallback_identity_file")"
  port="$(wtmux_machine_field "$machine_id" "endpoint_port")"
  port="${port:-22}"
  wtmux_require_verified_endpoint "$machine_id" "openssh"
  pinned_known_hosts="$(wtmux_bind_endpoint_evidence "$machine_id" "openssh")"
  [[ -n "$pinned_known_hosts" ]] \
    || wtmux_die "ENDPOINT_REVERIFY_REQUIRED: ${machine_id} has no pinned known-hosts file"
  remote_shell="$(wtmux_shell_quote_join "$@")"
  printf -v remote_command 'bash -lc %q' "$remote_shell"

  out_ref=(
    "ssh"
    "-o" "BatchMode=yes"
    "-o" "ConnectTimeout=$(wtmux_ssh_connect_timeout)"
    "-o" "IdentitiesOnly=yes"
    "-o" "StrictHostKeyChecking=yes"
    "-o" "UserKnownHostsFile=${pinned_known_hosts}"
    "-o" "GlobalKnownHostsFile=/dev/null"
    "-o" "UpdateHostKeys=no"
    "-p" "$port"
  )
  if [[ "$tty_mode" == "force" ]]; then
    out_ref+=("-tt")
  fi
  if [[ -n "$identity_file" ]]; then
    out_ref+=("-i" "$identity_file")
  fi
  wtmux_add_ssh_reuse_options "$target_var" "$machine_id" "$remote_target" "$port" "openssh"
  out_ref+=("$remote_target" "$remote_command")
}

wtmux_build_ssh_command() {
  local target_var="$1"
  local machine_id="$2"
  shift 2
  wtmux_build_ssh_command_internal "$target_var" "$machine_id" "none" "$@"
}

wtmux_build_ssh_tty_command() {
  local target_var="$1"
  local machine_id="$2"
  shift 2
  wtmux_build_ssh_command_internal "$target_var" "$machine_id" "force" "$@"
}

wtmux_use_ssh_client_for_tailscale_transport() {
  [[ "$(wtmux_detect_platform)" == "termux" ]]
}

wtmux_build_machine_command() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  shift 2
  local transport
  local remote_target
  local engine

  transport="$(wtmux_transport_for_machine "$machine_id")"
  engine="$(wtmux_ssh_engine_for_machine "$machine_id" "none")"
  case "$transport" in
    local)
      out_ref=("$@")
      ;;
    ssh)
      wtmux_build_ssh_command "$target_var" "$machine_id" "$@"
      ;;
    ""|tailscale)
      if [[ "$engine" == "openssh" ]]; then
        wtmux_build_ssh_command "$target_var" "$machine_id" "$@"
      else
        wtmux_require_verified_endpoint "$machine_id" "$engine"
        wtmux_bind_endpoint_evidence "$machine_id" "$engine" >/dev/null
        remote_target="$(wtmux_machine_remote_target "$machine_id")"
        wtmux_build_tailscale_ssh_command "$target_var" "$remote_target" "$@"
      fi
      ;;
    *)
      wtmux_die "unsupported transport '${transport}' for ${machine_id}"
      ;;
  esac
}

wtmux_build_interactive_machine_command() {
  local target_var="$1"
  local -n out_ref="$target_var"
  local machine_id="$2"
  shift 2
  local transport
  local remote_target
  local engine

  transport="$(wtmux_transport_for_machine "$machine_id")"
  engine="$(wtmux_ssh_engine_for_machine "$machine_id" "force")"
  case "$transport" in
    local)
      out_ref=("$@")
      ;;
    ssh)
      wtmux_build_ssh_tty_command "$target_var" "$machine_id" "$@"
      ;;
    ""|tailscale)
      if [[ "$engine" != "openssh" ]]; then
        wtmux_die "TTY_UNAVAILABLE: selected SSH engine cannot allocate a terminal"
      fi
      wtmux_build_ssh_tty_command "$target_var" "$machine_id" "$@"
      ;;
    *)
      wtmux_die "unsupported transport '${transport}' for ${machine_id}"
      ;;
  esac
}

wtmux_prepare_ssh_reuse() {
  local target_var="$1"
  local -n command_ref="$target_var"
  [[ "${command_ref[0]:-}" == "ssh" ]] || return 0
  local prepared=()
  mapfile -d '' -t prepared < <(python3 "${WTMUX_REPO_ROOT}/lib/ssh_reuse.py" prepare -- "${command_ref[@]}")
  (( ${#prepared[@]} > 0 )) && command_ref=("${prepared[@]}")
  return 0
}

wtmux_exec_machine_command() {
  local machine_id="$1"
  shift
  local command=()
  local stdout_file
  local stderr_file
  local status=0

  wtmux_build_machine_command command "$machine_id" "$@"
  wtmux_prepare_ssh_reuse command
  stdout_file="$(mktemp)"
  stderr_file="$(mktemp)"

  set +e
  wtmux_run_bounded_command "$stdout_file" "$stderr_file" "" "${command[@]}"
  status=$?
  set -e

  if (( status != 0 )); then
    wtmux_handle_tailscale_auth_requirement "$machine_id" "$(cat "$stderr_file")" || true
    # Structured helpers, including conversation actions, return bounded JSON
    # error frames on stdout even when their process status is non-zero. Keep
    # that frame so native clients can show the precise retryable failure.
    cat "$stdout_file"
    cat "$stderr_file" >&2
    rm -f "$stdout_file" "$stderr_file"
    return "$status"
  fi

  cat "$stdout_file"
  cat "$stderr_file" >&2
  rm -f "$stdout_file" "$stderr_file"
}

# Execute a long-lived command without buffering stdout in temporary files.
# Conversation frames are already bounded and sanitized by the host helper.
wtmux_stream_machine_command() {
  local machine_id="$1"
  shift
  local command=()

  wtmux_build_machine_command command "$machine_id" "$@"
  wtmux_prepare_ssh_reuse command
  exec "${command[@]}"
}

wtmux_exec_machine_command_with_stdin_file() {
  local machine_id="$1"
  local stdin_path="$2"
  shift 2
  local command=()
  local stdout_file
  local stderr_file
  local status=0

  [[ -r "$stdin_path" ]] || wtmux_die "stdin file not readable: ${stdin_path}"
  [[ "${WTMUX_TRANSFER_MODE:-stream}" == "stream" ]] \
    || wtmux_die "SFTP transfer is disabled because host policy atomicity is not equivalent"
  wtmux_build_machine_command command "$machine_id" "$@"
  wtmux_prepare_ssh_reuse command
  stdout_file="$(mktemp)"
  stderr_file="$(mktemp)"

  set +e
  wtmux_run_bounded_command "$stdout_file" "$stderr_file" "$stdin_path" "${command[@]}"
  status=$?
  set -e

  if (( status != 0 )); then
    wtmux_handle_tailscale_auth_requirement "$machine_id" "$(cat "$stderr_file")" || true
    cat "$stdout_file"
    cat "$stderr_file" >&2
    rm -f "$stdout_file" "$stderr_file"
    return "$status"
  fi

  cat "$stdout_file"
  cat "$stderr_file" >&2
  rm -f "$stdout_file" "$stderr_file"
}

wtmux_default_host_command_for_machine() {
  local machine_id="$1"
  local projects_root=""
  local linux_username=""
  local home_dir=""

  projects_root="$(wtmux_machine_field "$machine_id" "projects_root")"
  linux_username="$(wtmux_machine_field "$machine_id" "linux_username")"

  if [[ -n "$projects_root" && "$projects_root" == */projects ]]; then
    home_dir="${projects_root%/projects}"
  elif [[ -n "$linux_username" ]]; then
    home_dir="/home/${linux_username}"
  fi

  if [[ -n "$home_dir" ]]; then
    printf '%s/.local/bin/wtmux-host\n' "$home_dir"
    return 0
  fi

  printf '%s\n' "wtmux-host"
}

wtmux_machine_host_command() {
  local machine_id="$1"
  local command_name
  command_name="$(wtmux_machine_field "$machine_id" "host_command")"
  if [[ -z "$command_name" || "$command_name" == "wtmux-host" ]]; then
    wtmux_default_host_command_for_machine "$machine_id"
    return 0
  fi
  printf '%s\n' "$command_name"
}

wtmux_machine_host_runtime_command() {
  local machine_id="$1"
  local host_command
  host_command="$(wtmux_machine_host_command "$machine_id")"
  if [[ "$host_command" == */* ]]; then
    printf '%s/wtmux-host-runtime\n' "${host_command%/*}"
  else
    printf '%s\n' "wtmux-host-runtime"
  fi
}

wtmux_exec_host_runtime_command() {
  local machine_id="$1"
  local channel="$2"
  shift 2
  local transport
  local command=()
  local runtime_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  runtime_command="$(wtmux_machine_host_runtime_command "$machine_id")"
  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host-runtime" "$channel" "--machine" "$machine_id" "$@")
  else
    command=("$runtime_command" "$channel" "--machine" "$machine_id" "$@")
  fi
  wtmux_exec_machine_command "$machine_id" "${command[@]}"
}

wtmux_stream_host_runtime_command() {
  local machine_id="$1"
  local channel="$2"
  shift 2
  local transport
  local command=()
  local runtime_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  runtime_command="$(wtmux_machine_host_runtime_command "$machine_id")"
  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host-runtime" "$channel" "--machine" "$machine_id" "$@")
  else
    command=("$runtime_command" "$channel" "--machine" "$machine_id" "$@")
  fi
  wtmux_stream_machine_command "$machine_id" "${command[@]}"
}

wtmux_exec_host_runtime_command_with_stdin_file() {
  local machine_id="$1"
  local stdin_path="$2"
  local channel="$3"
  shift 3
  local transport
  local command=()
  local runtime_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  runtime_command="$(wtmux_machine_host_runtime_command "$machine_id")"
  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host-runtime" "$channel" "--machine" "$machine_id" "$@")
  else
    command=("$runtime_command" "$channel" "--machine" "$machine_id" "$@")
  fi
  wtmux_exec_machine_command_with_stdin_file "$machine_id" "$stdin_path" "${command[@]}"
}

wtmux_exec_host_command() {
  local machine_id="$1"
  shift
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_exec_machine_command "$machine_id" "${command[@]}"
}

wtmux_stream_host_command() {
  local machine_id="$1"
  shift
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_stream_machine_command "$machine_id" "${command[@]}"
}

wtmux_exec_host_command_with_stdin_file() {
  local machine_id="$1"
  local stdin_path="$2"
  shift 2
  local transport
  local command=()
  local host_command

  transport="$(wtmux_transport_for_machine "$machine_id")"
  host_command="$(wtmux_machine_host_command "$machine_id")"

  if [[ "$transport" == "local" ]]; then
    command=("${WTMUX_REPO_ROOT}/scripts/wtmux-host" "--machine" "$machine_id" "$@")
  else
    command=("$host_command" "--machine" "$machine_id" "$@")
  fi

  wtmux_exec_machine_command_with_stdin_file "$machine_id" "$stdin_path" "${command[@]}"
}

wtmux_probe_machine() {
  local machine_id="$1"
  local runtime_command
  local probe_command=()
  local output=""
  local status=0
  local transport
  local engine

  transport="$(wtmux_transport_for_machine "$machine_id")"
  engine="$(wtmux_ssh_engine_for_machine "$machine_id" "none")"
  runtime_command="$(wtmux_machine_host_runtime_command "$machine_id")"
  WTMUX_LAST_PROBE_ENGINE="$engine"

  if [[ "$transport" == "local" ]]; then
    WTMUX_LAST_PROBE_COMMAND="$(wtmux_shell_quote_join "$runtime_command" "describe")"
    if [[ "$runtime_command" != */* ]]; then
      # A bare command name is resolved through PATH at execution time, so the
      # executable check must resolve it the same way instead of probing a
      # path relative to the current working directory.
      local resolved_runtime_command=""
      resolved_runtime_command="$(command -v "$runtime_command" 2>/dev/null || true)"
      if [[ -z "$resolved_runtime_command" || ! -x "$resolved_runtime_command" ]]; then
        WTMUX_LAST_PROBE_OUTPUT="registry-declared host runtime is missing or not executable"
        WTMUX_LAST_PROBE_STATUS="HOST_RUNTIME_MISSING"
        return 1
      fi
    elif [[ ! -x "$runtime_command" ]]; then
      WTMUX_LAST_PROBE_OUTPUT="registry-declared host runtime is missing or not executable"
      WTMUX_LAST_PROBE_STATUS="HOST_RUNTIME_MISSING"
      return 1
    fi

    set +e
    output="$("$runtime_command" describe 2>&1)"
    status=$?
    set -e
    WTMUX_LAST_PROBE_OUTPUT="$output"
    WTMUX_LAST_PROBE_STATUS="$(wtmux_transport_error_code "$status" "$output")"
    [[ "$WTMUX_LAST_PROBE_STATUS" == "OK" ]]
    return
  fi

  wtmux_build_machine_command probe_command "$machine_id" "$runtime_command" "describe"
  WTMUX_LAST_PROBE_COMMAND="$(wtmux_shell_quote_join "${probe_command[@]}")"

  set +e
  output="$("${probe_command[@]}" 2>&1)"
  status=$?
  set -e

  WTMUX_LAST_PROBE_OUTPUT="$output"
  WTMUX_LAST_PROBE_STATUS="$(wtmux_transport_error_code "$status" "$output")"
  if [[ "$WTMUX_LAST_PROBE_STATUS" == "SSH_CHECK_REQUIRED" ]]; then
    wtmux_handle_tailscale_auth_requirement "$machine_id" "$output" || true
  fi
  [[ "$WTMUX_LAST_PROBE_STATUS" == "OK" ]]
}
