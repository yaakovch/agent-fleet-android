"""Read-only tmux session incarnation. Reused names never imply reused identity."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

try:
    from lib.tmux_safety import command_from_environment
except ModuleNotFoundError:
    # The public read-only lookup is also sent over stdin to older hosts.
    def command_from_environment() -> tuple[str, ...]:
        managed = Path.home() / ".local/bin/tmux"
        binary = os.environ.get("WTMUX_TMUX_BIN") or (str(managed) if managed.is_file() else "tmux")
        socket = os.environ.get("WTMUX_SCHEDULER_TMUX_SOCKET")
        return (binary, "-L", socket) if socket else (binary,)


def process_start(pid: int, root: Path = Path("/proc")) -> str:
    fields = (root / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
    value = fields[19]
    if not value.isdigit() or int(value) <= 0:
        raise ValueError("process creation identity is unavailable")
    return value


def session_identity(host: str, session: str) -> dict:
    if not re.fullmatch(r"[A-Za-z0-9._-]{1,160}", host) or not re.fullmatch(r"[A-Za-z0-9._-]{1,128}", session):
        raise ValueError("invalid host or exact session name")
    fields = ("#{session_name}", "#{session_id}", "#{session_created}", "#{pid}",
              "#{pane_start_path}", "#{@wtmux_backend}", "#{@wtmux_tool}", "#{@wtmux_project_path}")
    result = subprocess.run([*command_from_environment(), "display-message", "-p", "-t", "=" + session + ":",
                             "\x1f".join(fields)], capture_output=True, timeout=5, check=True)
    values = result.stdout.decode("utf-8").rstrip("\n").split("\x1f")
    if (len(values) != len(fields) or values[0] != session or not re.fullmatch(r"\$\d+", values[1])
            or not values[2].isdigit() or not values[3].isdigit() or int(values[3]) <= 0):
        raise ValueError("session identity could not be verified")
    root = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    boot = (root / "sys/kernel/random/boot_id").read_text().strip()
    if not re.fullmatch(r"[a-fA-F0-9-]{36}", boot):
        raise ValueError("host boot identity is unavailable")
    backend = values[5] or "linux"
    tool = values[6] or "shell"
    if backend not in {"linux", "windows", "termux"} or tool not in {"shell", "bash", "codex", "claude", "copilot"}:
        raise ValueError("session metadata is unsupported")
    incarnation = hashlib.sha256(json.dumps([boot, os.getuid(), values[3], process_start(int(values[3]), root),
                                            values[1], values[2]], separators=(",", ":")).encode()).hexdigest()
    return {"schemaVersion": 1, "host": host, "session": session, "incarnationId": incarnation,
            "projectRoot": values[7] or values[4], "backend": backend, "tool": "shell" if tool == "bash" else tool}


if __name__ == "__main__":
    import sys
    try:
        print(json.dumps(session_identity(sys.argv[1], sys.argv[2]), separators=(",", ":")))
    except (OSError, ValueError, subprocess.SubprocessError) as error:
        raise SystemExit(f"Session identity unavailable: {error}") from error
