"""Re-use only process/file-descriptor proved provider bindings; no transcript text."""
from __future__ import annotations

import hashlib
import fcntl
import json
import os
from pathlib import Path
import tempfile
from typing import Any

from lib.history_index import cache_root, entry_size, evict, MAX_BYTES, private_directory, PARSER_VERSION
from lib.session_identity import process_start


def fingerprint(pid: int, proc: Path) -> tuple[str, str]:
    return process_start(pid, proc), hashlib.sha256((proc / str(pid) / "cmdline").read_bytes()).hexdigest()


def descendant(pid: int, root: int, proc: Path) -> bool:
    for _ in range(64):
        if pid == root:
            return True
        if pid <= 1:
            return False
        fields = (proc / str(pid) / "stat").read_text().rsplit(")", 1)[1].split()
        pid = int(fields[1])
    return False


def binding_path(incarnation: str, info: dict[str, Any]) -> Path:
    key = hashlib.sha256(json.dumps([incarnation, info["pid"], info["pane"], info.get("backend"),
                                    info.get("declaredTool"), info.get("cwd"), PARSER_VERSION],
                                   separators=(",", ":")).encode()).hexdigest()
    return cache_root() / f"binding-{key}.json"


def load(incarnation: str, info: dict[str, Any]) -> tuple[str, Path] | None:
    if not incarnation or os.environ.get("WTMUX_HISTORY_INDEX", "1") == "0":
        return None
    try:
        proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
        file = binding_path(incarnation, info)
        if file.is_symlink() or file.stat().st_size > 8192:
            return None
        value = json.loads(file.read_text())
        if tuple(value["rootFingerprint"]) != fingerprint(info["pid"], proc):
            return None
        pid = value["owner"]
        if not descendant(pid, info["pid"], proc) or tuple(value["ownerFingerprint"]) != fingerprint(pid, proc):
            return None
        path = Path(value["source"])
        metadata = path.stat()
        if [metadata.st_dev, metadata.st_ino] != value["sourceIdentity"]:
            return None
        if os.readlink(proc / str(pid) / "fd" / value["fd"]) != str(path):
            return None
        if value["adapter"] not in {"codex", "claude", "copilot"}:
            return None
        return value["adapter"], path
    except (OSError, ValueError, KeyError, TypeError, IndexError):
        return None


def save(incarnation: str, info: dict[str, Any], adapter: str, path: Path | None, pids: list[int]) -> None:
    if not incarnation or path is None or adapter not in {"codex", "claude", "copilot"}:
        return
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    temporary = ""
    try:
        root = cache_root()
        private_directory(root)
        metadata = path.stat()
        for pid in pids[:128]:
            descriptors = proc / str(pid) / "fd"
            try:
                candidates = list(descriptors.iterdir())[:256]
            except OSError:
                continue
            for candidate in candidates:
                try:
                    if os.readlink(candidate) != str(path):
                        continue
                    value = {"adapter": adapter, "source": str(path), "sourceIdentity": [metadata.st_dev, metadata.st_ino],
                             "rootFingerprint": fingerprint(info["pid"], proc), "ownerFingerprint": fingerprint(pid, proc),
                             "owner": pid, "fd": candidate.name}
                    destination = binding_path(incarnation, info)
                    with (root / "budget.lock").open("a+b") as budget:
                        os.chmod(budget.name, 0o600)
                        fcntl.flock(budget, fcntl.LOCK_EX | fcntl.LOCK_NB)
                        evict(root, destination, 16 * 1024)
                        if entry_size(root) + 16 * 1024 > MAX_BYTES:
                            return
                        descriptor, temporary = tempfile.mkstemp(prefix=".binding-", dir=root)
                        with os.fdopen(descriptor, "w") as output:
                            json.dump(value, output, separators=(",", ":"))
                        os.replace(temporary, destination)
                    return
                except OSError:
                    continue
    except (OSError, ValueError, IndexError):
        pass
    finally:
        if temporary:
            Path(temporary).unlink(missing_ok=True)
