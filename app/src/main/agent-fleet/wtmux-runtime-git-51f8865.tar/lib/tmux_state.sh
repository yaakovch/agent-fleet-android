#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_TMUX_STATE_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_TMUX_STATE_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/vscode_restore.sh"

WTMUX_TMUX_ROW_SEP=$'\037'
WTMUX_TMUX_TITLE_FORMAT='wtmux · #{?@wtmux_display_name,#{@wtmux_display_name},#{session_name}}#{?@wtmux_title_target, · #{@wtmux_title_target},}#{?pane_title, | #{pane_title},}'

wtmux_tmux_available() {
  command -v tmux >/dev/null 2>&1
}

wtmux_tmux_row_join() {
  local field
  local first=1

  for field in "$@"; do
    if (( first )); then
      first=0
    else
      printf '%s' "$WTMUX_TMUX_ROW_SEP"
    fi
    printf '%s' "$field"
  done
  printf '\n'
}

wtmux_tmux_session_rows() {
  tmux list-sessions -F "#{session_name}${WTMUX_TMUX_ROW_SEP}#{session_activity}${WTMUX_TMUX_ROW_SEP}#{@wtmux_managed}${WTMUX_TMUX_ROW_SEP}#{@wtmux_project}${WTMUX_TMUX_ROW_SEP}#{@wtmux_display_name}${WTMUX_TMUX_ROW_SEP}#{@wtmux_backend}${WTMUX_TMUX_ROW_SEP}#{pane_title}${WTMUX_TMUX_ROW_SEP}#{pane_current_command}${WTMUX_TMUX_ROW_SEP}#{pane_start_path}" 2>/dev/null || true
}

wtmux_tmux_backfill_metadata() {
  local session_name="$1"
  local project_name="$2"
  local display_name="$3"
  local backend="${4:-linux}"
  local project_path="${5:-}"
  local location_kind="${6:-project}"

  tmux set-option -t "$session_name" -q @wtmux_managed "1"
  tmux set-option -t "$session_name" -q @wtmux_project "$project_name"
  tmux set-option -t "$session_name" -q @wtmux_display_name "$display_name"
  local name_mode
  local auto_display_name
  name_mode="$(tmux show-option -t "$session_name" -q -v @wtmux_name_mode 2>/dev/null || true)"
  auto_display_name="$(tmux show-option -t "$session_name" -q -v @wtmux_auto_display_name 2>/dev/null || true)"
  if [[ -z "$auto_display_name" ]]; then
    tmux set-option -t "$session_name" -q @wtmux_auto_display_name "$display_name"
  fi
  if [[ -z "$name_mode" ]]; then
    if wtmux_display_session_number "$project_name" "$display_name" >/dev/null 2>&1 && \
        [[ "$session_name" == wtmux-* || "$session_name" == "$display_name" ]]; then
      tmux set-option -t "$session_name" -q @wtmux_name_mode "automatic"
    else
      tmux set-option -t "$session_name" -q @wtmux_name_mode "manual"
    fi
  fi
  tmux set-option -t "$session_name" -q @wtmux_backend "$backend"
  tmux set-option -t "$session_name" -q @wtmux_execution_target_id "$([[ "$backend" == "windows" ]] && printf windows || printf linux)"
  [[ -n "$project_path" ]] && tmux set-option -t "$session_name" -q @wtmux_project_path "$project_path"
  tmux set-option -t "$session_name" -q @wtmux_location_kind "$location_kind"
}

wtmux_tmux_apply_status_defaults() {
  local session_name="$1"

  # Keep the always-on status path tmux-native. The former stats command
  # launched PowerShell CIM and GPU probes every two seconds for every attached
  # client, which multiplied idle host load as clients accumulated.
  tmux set-option -t "$session_name" -q status-interval 30
  tmux set-option -t "$session_name" -q status-right-length 80
  tmux set-option -t "$session_name" -q status-right "#H | %H:%M"
}

wtmux_tmux_apply_terminal_reply_safety() {
  local session_name="$1"
  local helper="${WTMUX_REPO_ROOT}/scripts/wtmux-tmux-safety"
  local managed=""

  managed="$(tmux show-option -t "$session_name" -q -v @wtmux_managed 2>/dev/null || true)"
  [[ "$managed" == "1" ]] || return 0

  command -v python3 >/dev/null 2>&1 || {
    wtmux_warn "python3 is required to protect terminal replies in managed tmux sessions"
    return 1
  }
  [[ -f "$helper" ]] || {
    wtmux_warn "tmux terminal-reply safety helper is missing: ${helper}"
    return 1
  }
  if ! python3 "$helper" apply --session "$session_name" >/dev/null; then
    wtmux_warn "could not protect ${session_name} from fragmented terminal capability replies"
    return 1
  fi
}

wtmux_tmux_apply_title_defaults() {
  local session_name="$1"
  local host_id="${2:-${WTMUX_TMUX_HOST_ID:-}}"
  local managed
  local project_name
  local display_name
  local backend
  local title_target=""
  local prefix="wtmux"
  local generated_name=""

  managed="$(tmux show-option -t "$session_name" -q -v @wtmux_managed 2>/dev/null || true)"
  [[ "$managed" == "1" ]] || return 0

  project_name="$(tmux show-option -t "$session_name" -q -v @wtmux_project 2>/dev/null || true)"
  display_name="$(tmux show-option -t "$session_name" -q -v @wtmux_display_name 2>/dev/null || true)"
  backend="$(tmux show-option -t "$session_name" -q -v @wtmux_backend 2>/dev/null || true)"
  if [[ "${backend:-linux}" == "windows" ]]; then
    prefix="wtmux-win"
  fi
  if [[ -n "$host_id" ]]; then
    title_target="$(wtmux_vscode_short_target "$host_id" "$backend" 2>/dev/null || true)"
    if [[ -n "$title_target" ]]; then
      tmux set-option -t "$session_name" -q @wtmux_title_target "$title_target"
    fi
  fi
  if [[ -n "$project_name" && -n "$display_name" ]]; then
    generated_name="$(wtmux_generated_session_name_for_display "$project_name" "$display_name" "$prefix" 2>/dev/null || true)"
  fi

  tmux set-option -t "$session_name" -q @wtmux_generated_name "$generated_name"
  tmux set-option -t "$session_name" -q set-titles on
  tmux set-option -t "$session_name" -q set-titles-string "$WTMUX_TMUX_TITLE_FORMAT"
}

wtmux_tmux_apply_scheduler_defaults() {
  local session_name="$1"
  local managed

  managed="$(tmux show-option -t "$session_name" -q -v @wtmux_managed 2>/dev/null || true)"
  [[ "$managed" == "1" ]] || return 0
  command -v python3 >/dev/null 2>&1 || return 0
  WTMUX_SCHEDULE_AUTO_DETECT="${WTMUX_SCHEDULE_AUTO_DETECT:-1}" \
    python3 "${WTMUX_REPO_ROOT}/scripts/wtmux-scheduler" configure >/dev/null 2>&1 || true
}

wtmux_tmux_maybe_backfill_row() {
  local projects_root="$1"
  local row="$2"
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path

  IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
  if [[ "$managed" == "1" ]]; then
    if [[ -z "$backend" ]]; then
      backend="linux"
      wtmux_tmux_backfill_metadata "$session_name" "$project" "$display" "$backend"
      wtmux_tmux_row_join "$session_name" "$activity" "$managed" "$project" "$display" "$backend" "$pane_title" "$pane_current_command" "$pane_start_path"
    else
      printf '%s\n' "$row"
    fi
    return 0
  fi

  if [[ "$session_name" =~ ^(.+):([0-9]+)$ ]]; then
    project="${BASH_REMATCH[1]}"
    display="$session_name"
    if [[ -d "${projects_root}/${project}" ]]; then
      backend="linux"
      wtmux_tmux_backfill_metadata "$session_name" "$project" "$display" "$backend"
      wtmux_tmux_row_join "$session_name" "$activity" "1" "$project" "$display" "$backend" "$pane_title" "$pane_current_command" "$pane_start_path"
      return 0
    fi
  fi

  return 1
}

wtmux_project_last_activity() {
  local project_name="$1"
  local projects_root="$2"
  local best=0
  local dir_activity=0
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    if [[ "$project" == "$project_name" ]] && (( activity > best )); then
      best="$activity"
    fi
  done < <(wtmux_tmux_session_rows)

  if [[ -d "${projects_root}/${project_name}" ]]; then
    dir_activity="$(stat -c '%Y' "${projects_root}/${project_name}" 2>/dev/null || printf '0\n')"
  fi
  if (( dir_activity > best )); then
    best="$dir_activity"
  fi
  printf '%s\n' "$best"
}

wtmux_list_projects() {
  local projects_root="$1"
  local project_path
  local project_name
  local activity

  [[ -d "$projects_root" ]] || return 0

  while IFS= read -r project_path; do
    project_name="$(basename "$project_path")"
    activity="$(wtmux_project_last_activity "$project_name" "$projects_root")"
    printf '%s\t%s\t%s\n' "$project_name" "$activity" "$project_path"
  done < <(find "$projects_root" -mindepth 1 -maxdepth 1 -type d | sort) | sort -t$'\t' -k2,2nr -k1,1
}

wtmux_clean_label_part() {
  local value="$1"
  value="${value//$'\t'/ }"
  value="${value//$'\r'/ }"
  value="${value//$'\n'/ }"
  value="$(sed -E 's/[[:space:]]+/ /g; s/^ //; s/ $//' <<<"$value")"
  printf '%s\n' "$value"
}

wtmux_generated_session_name_for_display() {
  local project_name="$1"
  local display_name="$2"
  local prefix="${3:-wtmux}"
  local number

  number="$(wtmux_display_session_number "$project_name" "$display_name" 2>/dev/null)" || return 1
  printf '%s-%s-%s\n' "$prefix" "$(wtmux_slugify "$project_name")" "$number"
}

wtmux_session_picker_session_name() {
  local project_name="$1"
  local session_name="$2"
  local display_name="$3"
  local generated_name=""
  local generated_windows_name=""

  if [[ -n "$display_name" ]]; then
    generated_name="$(wtmux_generated_session_name_for_display "$project_name" "$display_name" 2>/dev/null || true)"
    generated_windows_name="$(wtmux_generated_session_name_for_display "$project_name" "$display_name" "wtmux-win" 2>/dev/null || true)"
  fi

  if [[ -n "$display_name" && ( "$session_name" == "$display_name" || "$session_name" == "$generated_name" || "$session_name" == "$generated_windows_name" ) ]]; then
    wtmux_clean_label_part "$display_name"
  else
    wtmux_clean_label_part "$session_name"
  fi
}

wtmux_pane_title_is_meaningful() {
  local pane_title="$1"
  local project_name="$2"
  local session_label="$3"
  local session_name="$4"
  local display_name="$5"
  local hostname_short=""
  local hostname_full=""
  local title_lower
  local candidate

  pane_title="$(wtmux_clean_label_part "$pane_title")"
  [[ -n "$pane_title" ]] || return 1

  title_lower="${pane_title,,}"
  hostname_short="$(hostname -s 2>/dev/null || true)"
  hostname_full="$(hostname 2>/dev/null || true)"

  for candidate in "$project_name" "$session_label" "$session_name" "$display_name" "$hostname_short" "$hostname_full"; do
    [[ -n "$candidate" ]] || continue
    if [[ "$title_lower" == "${candidate,,}" ]]; then
      return 1
    fi
  done

  return 0
}

wtmux_pane_title_is_codex_status() {
  local pane_title="$1"
  local project_name="$2"
  local session_label="$3"
  local clean_title
  local title_lower
  local project_lower
  local session_lower

  clean_title="$(wtmux_clean_label_part "$pane_title")"
  [[ -n "$clean_title" ]] || return 1

  title_lower="${clean_title,,}"
  project_lower="${project_name,,}"
  session_lower="${session_label,,}"

  if [[ -n "$project_lower" && "$title_lower" == *"$project_lower" ]] && (( ${#clean_title} <= ${#project_name} + 3 )); then
    return 0
  fi
  if [[ -n "$session_lower" && "$title_lower" == *"$session_lower" ]] && (( ${#clean_title} <= ${#session_label} + 3 )); then
    return 0
  fi

  return 1
}

wtmux_truncate_label_part() {
  local value="$1"
  local max_length="${2:-120}"

  if (( ${#value} > max_length )); then
    printf '%s...\n' "${value:0:max_length}"
  else
    printf '%s\n' "$value"
  fi
}

wtmux_json_escape_for_grep() {
  local value="$1"
  value="${value//\\/\\\\}"
  value="${value//\"/\\\"}"
  printf '%s\n' "$value"
}

wtmux_codex_latest_user_title_from_file() {
  local session_file="$1"

  command -v node >/dev/null 2>&1 || return 1
  [[ -r "$session_file" ]] || return 1

  node - "$session_file" <<'NODE'
const fs = require("fs");
const readline = require("readline");

const sessionFile = process.argv[2];
let latest = "";

function recordText(text) {
  const clean = text
    .replace(/# AGENTS\.md instructions/g, " ")
    .replace(/<environment_context>[\s\S]*?<\/environment_context>/g, " ")
    .replace(/<[^>]+>[\s\S]*?<\/[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  if (!clean) return;
  const lower = clean.toLowerCase();
  if (["exit", "quit", "q", "yes", "no", "try again", "implement the plan", "implement the plan."].includes(lower)) return;
  latest = clean;
}

const size = fs.statSync(sessionFile).size;
const stream = fs.createReadStream(sessionFile, { encoding: "utf8", start: Math.max(0, size - 512 * 1024) });
stream.on("error", () => process.exit(1));

const reader = readline.createInterface({ input: stream, crlfDelay: Infinity });
reader.on("line", (line) => {
  let entry;
  try {
    entry = JSON.parse(line);
  } catch {
    return;
  }

  const payload = entry.payload || {};
  const texts = [];
  if (payload.type === "message" && payload.role === "user" && Array.isArray(payload.content)) {
    for (const item of payload.content) {
      if (item && typeof item.text === "string") texts.push(item.text);
    }
  }
  if (entry.type === "user_message" && typeof payload.text === "string") {
    texts.push(payload.text);
  }
  if (entry.type === "event_msg" && payload.type === "user_message" && typeof payload.message === "string") {
    texts.push(payload.message);
  }

  for (const text of texts) {
    recordText(text);
  }
});

reader.on("close", () => {
  if (!latest) process.exit(1);
  process.stdout.write(latest);
});
NODE
}

wtmux_session_name_mode() {
  local project_name="$1"
  local session_name="$2"
  local display_name="$3"
  local mode
  local automatic_name

  mode="$(tmux show-option -t "$session_name" -q -v @wtmux_name_mode 2>/dev/null || true)"
  if [[ "$mode" == "automatic" || "$mode" == "manual" ]]; then
    printf '%s\n' "$mode"
    return 0
  fi

  automatic_name="$(tmux show-option -t "$session_name" -q -v @wtmux_auto_display_name 2>/dev/null || true)"
  automatic_name="${automatic_name:-$project_name:1}"
  if [[ "$display_name" == "${project_name}:"* && "$session_name" == wtmux-* ]]; then
    mode="automatic"
    tmux set-option -t "$session_name" -q @wtmux_auto_display_name "$display_name" 2>/dev/null || true
  else
    mode="manual"
    tmux set-option -t "$session_name" -q @wtmux_auto_display_name "$automatic_name" 2>/dev/null || true
  fi
  tmux set-option -t "$session_name" -q @wtmux_name_mode "$mode" 2>/dev/null || true
  printf '%s\n' "$mode"
}

wtmux_session_smart_title() {
  local project_name="$1"
  local session_name="$2"
  local display_name="$3"
  local pane_title="$4"
  local pane_current_command="${5:-}"
  local pane_start_path="${6:-}"
  local clean_project
  local session_label
  local clean_title
  local codex_title=""
  local cached_title=""

  clean_project="$(wtmux_clean_label_part "$project_name")"
  session_label="$(wtmux_session_picker_session_name "$project_name" "$session_name" "$display_name")"
  clean_title="$(wtmux_clean_label_part "$pane_title")"

  if [[ "$pane_current_command" == "node" || "$pane_current_command" == "codex" ]]; then
    if ! wtmux_pane_title_is_meaningful "$clean_title" "$clean_project" "$session_label" "$session_name" "$display_name" || \
      wtmux_pane_title_is_codex_status "$clean_title" "$clean_project" "$session_label"; then
      codex_title="$(wtmux_codex_title_for_path "$pane_start_path" 2>/dev/null || true)"
      [[ -n "$codex_title" ]] && clean_title="$codex_title"
    fi
  fi

  if wtmux_pane_title_is_meaningful "$clean_title" "$clean_project" "$session_label" "$session_name" "$display_name"; then
    clean_title="$(wtmux_truncate_label_part "$clean_title" 120)"
    tmux set-option -t "$session_name" -q @wtmux_smart_title "$clean_title" 2>/dev/null || true
    printf '%s\n' "$clean_title"
    return 0
  fi

  cached_title="$(tmux show-option -t "$session_name" -q -v @wtmux_smart_title 2>/dev/null || true)"
  cached_title="$(wtmux_clean_label_part "$cached_title")"
  [[ -n "$cached_title" ]] || return 1
  wtmux_truncate_label_part "$cached_title" 120
}

wtmux_codex_title_for_path() {
  local pane_start_path="$1"
  local sessions_dirs=()
  local sessions_dir
  local escaped_cwd
  local candidate_line
  local candidate_file
  local title

  [[ "${WTMUX_CODEX_TITLE_FALLBACK:-1}" != "0" ]] || return 1
  [[ -n "$pane_start_path" ]] || return 1

  if [[ -n "${CODEX_HOME:-}" ]]; then
    sessions_dirs+=("${CODEX_HOME}/sessions")
  fi
  if [[ -z "${CODEX_HOME:-}" || "${CODEX_HOME}/sessions" != "${HOME}/.codex/sessions" ]]; then
    sessions_dirs+=("${HOME}/.codex/sessions")
  fi

  escaped_cwd="$(wtmux_json_escape_for_grep "$pane_start_path")"

  for sessions_dir in "${sessions_dirs[@]}"; do
    [[ -d "$sessions_dir" ]] || continue
    while IFS= read -r candidate_line; do
      candidate_file="${candidate_line#* }"
      [[ -r "$candidate_file" ]] || continue
      if sed -n '1p' "$candidate_file" | grep -Fq "\"cwd\":\"${escaped_cwd}\""; then
        title="$(wtmux_codex_latest_user_title_from_file "$candidate_file" 2>/dev/null || true)"
        if [[ -n "$title" ]]; then
          wtmux_truncate_label_part "$(wtmux_clean_label_part "$title")" 120
          return 0
        fi
      fi
    done < <(find "$sessions_dir" -type f -name '*.jsonl' -mtime -14 -printf '%T@ %p\n' 2>/dev/null | sort -nr | head -n 40)
  done

  return 1
}

wtmux_session_picker_label() {
  local project_name="$1"
  local session_name="$2"
  local display_name="$3"
  local pane_title="$4"
  local pane_current_command="${5:-}"
  local pane_start_path="${6:-}"
  local clean_project
  local session_label
  local clean_title
  local smart_title=""

  clean_project="$(wtmux_clean_label_part "$project_name")"
  session_label="$(wtmux_session_picker_session_name "$project_name" "$session_name" "$display_name")"
  smart_title="$(wtmux_session_smart_title "$project_name" "$session_name" "$display_name" "$pane_title" "$pane_current_command" "$pane_start_path" 2>/dev/null || true)"

  if [[ -n "$smart_title" ]]; then
    printf '%s | %s | %s\n' "$clean_project" "$session_label" "$smart_title"
  else
    printf '%s | %s\n' "$clean_project" "$session_label"
  fi
}

wtmux_list_session_metadata_json() {
  local projects_root="$1"
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path
  local title
  local mode

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    [[ "$managed" == "1" && -n "$project" ]] || continue
    title="$(wtmux_session_smart_title "$project" "$session_name" "$display" "$pane_title" "$pane_current_command" "$pane_start_path" 2>/dev/null || true)"
    mode="$(wtmux_session_name_mode "$project" "$session_name" "$display")"
    wtmux_tmux_row_join "$session_name" "$display" "$title" "$mode"
  done < <(wtmux_tmux_session_rows) | python3 -c '
import json, sys
sep = "\x1f"
items = []
for raw in sys.stdin:
    fields = raw.rstrip("\n").split(sep)
    if len(fields) == 4:
        items.append({"internalName": fields[0], "name": fields[1], "title": fields[2], "nameMode": fields[3]})
print(json.dumps(items, ensure_ascii=False, separators=(",", ":")))
'
}

wtmux_list_sessions() {
  local project_name="$1"
  local projects_root="$2"
  local backend_filter="${3:-}"
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path
  local label

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    backend="${backend:-linux}"
    [[ -z "$backend_filter" || "$backend" == "$backend_filter" ]] || continue
    if [[ "$project" == "$project_name" ]]; then
      label="$(wtmux_session_picker_label "$project" "$session_name" "$display" "$pane_title" "$pane_current_command" "$pane_start_path")"
      printf '%s\t%s\t%s\n' "$label" "$session_name" "$activity"
    fi
  done < <(wtmux_tmux_session_rows) | sort -t$'\t' -k3,3nr -k1,1
}

wtmux_list_all_sessions() {
  local projects_root="$1"
  local backend_filter="${2:-}"
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path
  local label

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    backend="${backend:-linux}"
    [[ -z "$backend_filter" || "$backend" == "$backend_filter" ]] || continue
    [[ -n "$project" ]] || continue
    label="$(wtmux_session_picker_label "$project" "$session_name" "$display" "$pane_title" "$pane_current_command" "$pane_start_path")"
    printf '%s\t%s\t%s\t%s\n' "$project" "$label" "$session_name" "$activity"
  done < <(wtmux_tmux_session_rows) | sort -t$'\t' -k4,4nr -k1,1 -k2,2
}

wtmux_list_all_session_identities() {
  local projects_root="$1"
  local backend_filter="${2:-}"
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    backend="${backend:-linux}"
    [[ -z "$backend_filter" || "$backend" == "$backend_filter" ]] || continue
    [[ "$managed" == "1" && -n "$project" && -n "$display" && -n "$session_name" ]] || continue
    printf '%s\t%s\t%s\t%s\n' "$project" "$display" "$session_name" "$activity"
  done < <(wtmux_tmux_session_rows) | sort -t$'\t' -k4,4nr -k1,1 -k2,2
}

wtmux_display_session_number() {
  local project_name="$1"
  local display_name="$2"
  local prefix="${project_name}:"
  local suffix

  [[ "$display_name" == "$prefix"* ]] || return 1
  suffix="${display_name#"$prefix"}"
  [[ "$suffix" =~ ^[0-9]+$ ]] || return 1
  printf '%s\n' "$suffix"
}

wtmux_next_session_number() {
  local project_name="$1"
  local projects_root="$2"
  local backend_filter="${3:-linux}"
  local row
  local session_name activity managed project display backend pane_title pane_current_command pane_start_path
  local number
  local highest=0

  while IFS= read -r row; do
    row="$(wtmux_tmux_maybe_backfill_row "$projects_root" "$row" || true)"
    [[ -n "$row" ]] || continue
    IFS="$WTMUX_TMUX_ROW_SEP" read -r session_name activity managed project display backend pane_title pane_current_command pane_start_path <<<"$row"
    backend="${backend:-linux}"
    [[ "$project" == "$project_name" ]] || continue
    [[ -z "$backend_filter" || "$backend" == "$backend_filter" ]] || continue

    if number="$(wtmux_display_session_number "$project_name" "$display" 2>/dev/null)"; then
      :
    elif number="$(wtmux_display_session_number "$project_name" "$session_name" 2>/dev/null)"; then
      :
    else
      continue
    fi

    if (( number > highest )); then
      highest="$number"
    fi
  done < <(wtmux_tmux_session_rows)

  printf '%s\n' $((highest + 1))
}

wtmux_create_session_with_backend() {
  local project_name="$1"
  local project_path="$2"
  local backend="${3:-linux}"
  local shell_command="${4:-}"
  local tool="${5:-shell}"
  local location_kind="${6:-project}"
  local metadata_path="${7:-$project_path}"
  local next_number
  local display_name
  local internal_name
  local slug
  local prefix="wtmux"

  next_number="$(wtmux_next_session_number "$project_name" "$(dirname "$project_path")" "$backend")"
  display_name="${project_name}:${next_number}"
  slug="$(wtmux_slugify "$project_name")"
  if [[ "$backend" == "windows" ]]; then
    prefix="wtmux-win"
  fi
  internal_name="${prefix}-${slug}-${next_number}"
  while tmux has-session -t "$internal_name" 2>/dev/null; do
    next_number=$((next_number + 1))
    display_name="${project_name}:${next_number}"
    internal_name="${prefix}-${slug}-${next_number}"
  done

  if [[ -n "$shell_command" ]]; then
    tmux new-session -d -s "$internal_name" -c "$project_path" "$shell_command"
  elif [[ "$backend" == "linux" && "${WTMUX_SHELL_INTEGRATION:-1}" != "0" && -x "${WTMUX_REPO_ROOT}/scripts/wtmux-shell" ]]; then
    tmux new-session -d -s "$internal_name" -c "$project_path" "${WTMUX_REPO_ROOT}/scripts/wtmux-shell"
  else
    tmux new-session -d -s "$internal_name" -c "$project_path"
  fi
  tmux rename-window -t "${internal_name}:1" "$project_name"
  wtmux_tmux_backfill_metadata "$internal_name" "$project_name" "$display_name" "$backend" "$metadata_path" "$location_kind"
  tmux set-option -t "$internal_name" -q @wtmux_tool "$tool"
  tmux set-option -t "$internal_name" -q @wtmux_started_at "$(date +%s)"
  if ! wtmux_tmux_apply_terminal_reply_safety "$internal_name"; then
    tmux kill-session -t "$internal_name" >/dev/null 2>&1 || true
    wtmux_die "refusing to open an unprotected managed tmux session"
  fi
  wtmux_tmux_apply_status_defaults "$internal_name"
  wtmux_tmux_apply_title_defaults "$internal_name"
  wtmux_tmux_apply_scheduler_defaults "$internal_name"
  printf '%s\t%s\n' "$display_name" "$internal_name"
}

wtmux_create_session() {
  local project_name="$1"
  local project_path="$2"
  wtmux_create_session_with_backend "$project_name" "$project_path" "linux"
}

wtmux_attach_session() {
  local session_name="$1"
  if ! wtmux_tmux_apply_terminal_reply_safety "$session_name"; then
    wtmux_die "refusing to attach an unprotected managed tmux session"
  fi
  wtmux_tmux_apply_title_defaults "$session_name"
  wtmux_tmux_apply_scheduler_defaults "$session_name"
  exec tmux attach-session -t "$session_name"
}

wtmux_kill_session() {
  local session_name="$1"
  tmux kill-session -t "$session_name"
}
