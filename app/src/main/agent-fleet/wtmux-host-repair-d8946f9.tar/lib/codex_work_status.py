"""Bounded, read-only observations of already running Codex daemons.

Codex TUI processes can share a daemon. An open rollout in that daemon therefore
does not identify the conversation displayed by any one terminal. Match a live
TUI's native title AND project against the complete loaded-thread inventory.
Never resume a thread, start a daemon, or select the most recently written log.
"""
from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path, PureWindowsPath
import re
import select
import socket
import struct
import subprocess
import time
from typing import Any

from lib.session_identity import process_start
from lib.work_status import instant

MAX_FRAME = 1024 * 1024
MAX_BYTES = 4 * MAX_FRAME
MAX_THREADS = 128
MAX_PROFILES = 8
POLL_BUDGET = 4.0


class DaemonError(ValueError):
    pass


class Connection:
    """RFC6455 over an existing Unix socket or Codex's raw stdio socket proxy."""

    def __init__(self, endpoint: Path | list[str], deadline: float):
        self.deadline = deadline
        self.buffer = bytearray()
        self.received = 0
        self.sequence = 0
        self.process: subprocess.Popen | None = None
        self.socket: socket.socket | None = None
        self.reader = self.writer = -1
        try:
            if isinstance(endpoint, Path):
                self.socket = socket.socket(socket.AF_UNIX)
                self.socket.settimeout(max(0.01, deadline - time.monotonic()))
                self.socket.connect(str(endpoint))
                self.reader = self.writer = self.socket.fileno()
            else:
                # Windows programs can stall during startup with an inherited
                # WSL UNC working directory. Use the verified executable's
                # native directory for this raw proxy process.
                executable = endpoint[1] if endpoint[0] == "/init" else endpoint[0]
                self.process = subprocess.Popen(endpoint, stdin=subprocess.PIPE,
                                                stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                                                cwd=Path(executable).parent)
                assert self.process.stdout is not None and self.process.stdin is not None
                self.reader, self.writer = self.process.stdout.fileno(), self.process.stdin.fileno()
            os.set_blocking(self.reader, False)
            os.set_blocking(self.writer, False)
            key = base64.b64encode(os.urandom(16)).decode()
            self.write(("GET / HTTP/1.1\r\nHost: localhost\r\nUpgrade: websocket\r\n"
                        "Connection: Upgrade\r\nSec-WebSocket-Key: " + key +
                        "\r\nSec-WebSocket-Version: 13\r\n\r\n").encode())
            header = bytearray()
            while not header.endswith(b"\r\n\r\n"):
                header.extend(self.read(1))
                if len(header) > 16384:
                    raise DaemonError("oversized upgrade header")
            lines = bytes(header).decode("ascii").split("\r\n")
            fields = {k.lower().strip(): v.strip() for k, v in
                      (line.split(":", 1) for line in lines[1:] if ":" in line)}
            expected = base64.b64encode(hashlib.sha1(
                (key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
            if (lines[0] != "HTTP/1.1 101 Switching Protocols"
                    or fields.get("sec-websocket-accept", "") != expected
                    or fields.get("upgrade", "").lower() != "websocket"
                    or "upgrade" not in fields.get("connection", "").lower().split(",")):
                raise DaemonError("invalid websocket upgrade")
            self.request("initialize", {"clientInfo": {"name": "wtmux_work_status", "version": "1.0.0"}})
            self.send(1, b'{"method":"initialized"}')
        except BaseException:
            self.close()
            raise

    def ready(self, writing: bool = False) -> None:
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise DaemonError("daemon observation deadline")
        readers, writers, _ = select.select([] if writing else [self.reader],
                                             [self.writer] if writing else [], [], remaining)
        if not (readers or writers):
            raise DaemonError("daemon observation deadline")

    def read(self, count: int) -> bytes:
        if count > MAX_FRAME:
            raise DaemonError("daemon frame budget")
        while len(self.buffer) < count:
            self.ready()
            try:
                data = os.read(self.reader, min(65536, MAX_BYTES - self.received + 1))
            except BlockingIOError:
                continue
            if not data:
                raise DaemonError("daemon connection closed")
            self.received += len(data)
            if self.received > MAX_BYTES:
                raise DaemonError("daemon observation byte budget")
            self.buffer.extend(data)
        value = bytes(self.buffer[:count])
        del self.buffer[:count]
        return value

    def write(self, data: bytes) -> None:
        while data:
            self.ready(True)
            try:
                written = os.write(self.writer, data)
            except BlockingIOError:
                continue
            if not written:
                raise DaemonError("daemon connection closed")
            data = data[written:]

    def send(self, opcode: int, payload: bytes) -> None:
        if len(payload) > 65535:
            raise DaemonError("request exceeds budget")
        mask = os.urandom(4)
        size = len(payload)
        header = bytes([0x80 | opcode, 0x80 | size]) if size < 126 else bytes(
            [0x80 | opcode, 0x80 | 126]) + struct.pack("!H", size)
        self.write(header + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(payload)))

    def receive(self) -> dict:
        parts = bytearray()
        fragmented = False
        for _ in range(128):
            first, second = self.read(2)
            opcode, final = first & 15, bool(first & 128)
            if first & 112 or second & 128:
                raise DaemonError("invalid websocket frame")
            size = second & 127
            if size == 126:
                size = struct.unpack("!H", self.read(2))[0]
            elif size == 127:
                size = struct.unpack("!Q", self.read(8))[0]
            data = self.read(size)
            if opcode in (8, 9, 10):
                if not final or size > 125:
                    raise DaemonError("invalid websocket control frame")
                if opcode == 8:
                    raise DaemonError("daemon closed connection")
                if opcode == 9:
                    self.send(10, data)
                continue
            if opcode not in (0, 1) or (opcode == 0) != fragmented:
                raise DaemonError("invalid fragmented websocket message")
            parts.extend(data)
            if len(parts) > MAX_FRAME:
                raise DaemonError("daemon message budget")
            if final:
                value = json.loads(parts)
                if not isinstance(value, dict):
                    raise DaemonError("invalid daemon response")
                return value
            fragmented = True
        raise DaemonError("daemon frame count budget")

    def request(self, method: str, params: dict) -> dict:
        if method not in {"initialize", "thread/loaded/list", "thread/read"}:
            raise DaemonError("method is not read-only")
        self.sequence += 1
        self.send(1, json.dumps({"id": self.sequence, "method": method, "params": params}).encode())
        for _ in range(128):
            frame = self.receive()
            if frame.get("id") == self.sequence:
                if "error" in frame or not isinstance(frame.get("result"), dict):
                    raise DaemonError("daemon rejected metadata request")
                return frame["result"]
        raise DaemonError("daemon notification budget")

    def loaded_ids(self) -> list[str]:
        inventory = self.request("thread/loaded/list", {})
        ids = inventory.get("data")
        if (not isinstance(ids, list) or len(ids) > MAX_THREADS
                or inventory.get("nextCursor") is not None
                or any(not isinstance(i, str) or not re.fullmatch(r"[a-zA-Z0-9_-]{1,160}", i) for i in ids)
                or len(set(ids)) != len(ids)):
            raise DaemonError("invalid loaded thread inventory")
        return ids

    def threads(self) -> list[dict]:
        ids = self.loaded_ids()
        result = []
        for identifier in ids:
            thread = self.request("thread/read", {"threadId": identifier, "includeTurns": False}).get("thread")
            if not isinstance(thread, dict) or thread.get("id") != identifier or thread.get("turns", []):
                raise DaemonError("invalid thread metadata")
            result.append({key: thread.get(key) for key in ("id", "name", "cwd", "status")})
        if set(self.loaded_ids()) != set(ids):
            raise DaemonError("loaded thread inventory changed during observation")
        return result

    def close(self) -> None:
        if self.socket is not None:
            self.socket.close()
        if self.process is not None:
            if self.process.stdin is not None:
                self.process.stdin.close()
            if self.process.stdout is not None:
                self.process.stdout.close()
            try:
                self.process.wait(timeout=0.2)
            except subprocess.TimeoutExpired:
                self.process.terminate()
                try:
                    self.process.wait(timeout=0.2)
                except subprocess.TimeoutExpired:
                    self.process.kill()
                    self.process.wait(timeout=0.2)


def state(status: Any) -> str:
    if not isinstance(status, dict):
        return "unknown"
    kind = status.get("type")
    if kind == "idle":
        return "waiting"
    if kind == "systemError":
        return "attention"
    if kind == "active":
        flags = status.get("activeFlags")
        if not isinstance(flags, list) or any(f not in {"waitingOnApproval", "waitingOnUserInput"} for f in flags):
            return "unknown"
        return "attention" if flags else "working"
    return "unknown"


def project_path(value: str, windows: bool) -> str:
    if windows:
        if value.startswith("/mnt/") and len(value) > 7 and value[6] == "/":
            value = value[5].upper() + ":/" + value[7:]
        return str(PureWindowsPath(value)).casefold()
    return os.path.realpath(value)


def native_title(value: str) -> str:
    # Exact Codex 0.160/0.162 activity decorations, never generic prefix removal.
    # Spinner changes are presentation, not a thread switch.
    if len(value) > 2 and value[0] in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏" and value[1] == " ":
        return value[2:]
    for prefix in ("[ ! ] Action Required | ", "[ . ] Action Required | "):
        if value.startswith(prefix):
            return value[len(prefix):]
    return value


def match(row: dict, threads: list[dict], windows: bool = False) -> dict | None:
    """Exact native title and project only; never fuzzy or recency matching."""
    title = row.get("pane_title", "")
    if not title or any(ord(c) < 32 or ord(c) == 127 for c in title):
        return None
    titles = {title, native_title(title)}
    paths = {project_path(v, windows) for v in (
        row.get("@wtmux_project_path", ""), row.get("pane_current_path", "")) if v}
    candidates = []
    for thread in threads:
        name, cwd = thread.get("name"), thread.get("cwd")
        if not isinstance(name, str) or not name or not isinstance(cwd, str) or not cwd:
            continue
        folder = PureWindowsPath(cwd).name if windows else Path(cwd).name
        # Codex 0.160/0.162 emits at most 48 graphemes of thread name and
        # 24 of project name, ending shortened segments with three dots.
        # ASCII has unambiguous grapheme boundaries. Keep longer Unicode
        # segments exact-only rather than guess at grapheme segmentation.
        def segment(value, limit):
            return value[:limit - 3] + "..." if value.isascii() and len(value) > limit else value
        rendered_name, rendered_folder = segment(name, 48), segment(folder, 24)
        if project_path(cwd, windows) in paths and titles.intersection({
                name, name + " | " + folder, rendered_name,
                rendered_name + " | " + rendered_folder}):
            candidates.append(thread)
    return candidates[0] if len(candidates) == 1 else None


def linux_profile(pid: int) -> Path:
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    payload = (proc / str(pid) / "environ").read_bytes()
    if len(payload) > 128 * 1024:
        raise DaemonError("provider environment budget")
    environment = dict(part.split(b"=", 1) for part in payload.split(b"\0") if b"=" in part)
    home = Path(os.fsdecode(environment.get(b"CODEX_HOME", os.fsencode(Path.home() / ".codex")))).resolve()
    if home.stat().st_uid != os.getuid():
        raise DaemonError("provider profile owner mismatch")
    return home


def linux_identity(home: Path) -> tuple:
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    file = home / "app-server-daemon/daemon.pid"
    if file.stat().st_size > 4096 or file.stat().st_uid != os.getuid():
        raise DaemonError("unsafe daemon identity file")
    value = json.loads(file.read_text())
    pid = value["pid"]
    identity = value["processIdentity"]
    started = process_start(pid, proc)
    if (str(identity["startTicks"]) != started
            or identity["bootId"] != (proc / "sys/kernel/random/boot_id").read_text().strip()
            or (proc / str(pid)).stat().st_uid != os.getuid()
            or b"app-server" not in (proc / str(pid) / "cmdline").read_bytes().split(b"\0")):
        raise DaemonError("daemon process identity mismatch")
    endpoint = home / "app-server-control/app-server-control.sock"
    if endpoint.stat().st_uid != os.getuid():
        raise DaemonError("daemon socket owner mismatch")
    return pid, started, str(endpoint.resolve())


WINDOWS_DISCOVERY = r'''
$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'
$homePath=[Environment]::GetFolderPath('UserProfile')
$profiles=@(Join-Path $homePath '.codex') + @(Get-ChildItem -LiteralPath $homePath -Directory -Filter '.codex-*' | ForEach-Object FullName)
$uncertain=$false
$result=@(foreach($profile in $profiles) {
  $file=Join-Path $profile 'app-server-daemon/daemon.pid'
  if(!(Test-Path -LiteralPath $file) -or (Get-Item -LiteralPath $file).Length -gt 4096){continue}
  try {
    $meta=Get-Content -LiteralPath $file -Raw | ConvertFrom-Json
    try { $process=Get-Process -Id $meta.pid -ErrorAction Stop }
    catch { if($_.FullyQualifiedErrorId -like 'NoProcessFoundForGivenId*'){continue}; throw }
    $created=[string]$process.StartTime.ToFileTimeUtc()
    $exe=$process.Path
    if($created -ne [string]$meta.processStartTime){continue}
    if(!$exe -or !$exe.StartsWith((Join-Path $profile 'packages/app-server-daemon/releases/').Replace('/','\'),[StringComparison]::OrdinalIgnoreCase)){throw 'unverified live daemon executable'}
    [PSCustomObject]@{home=$profile;pid=$meta.pid;created=$created;exe=$exe;socket=(Join-Path $profile 'app-server-control/app-server-control.sock')}
  } catch { $uncertain=$true; continue }
})
ConvertTo-Json -InputObject @{complete=(!$uncertain);profiles=@($result)} -Compress -Depth 3
'''


def windows_profiles() -> list[dict]:
    executable = Path("/mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe")
    if not executable.is_file():
        return []
    command = [str(executable), "-NoProfile", "-NonInteractive", "-EncodedCommand",
               base64.b64encode(WINDOWS_DISCOVERY.encode("utf-16le")).decode()]
    if not Path("/proc/sys/fs/binfmt_misc/WSLInterop").exists():
        command.insert(0, "/init")
    result = subprocess.run(command, capture_output=True, timeout=2, check=True,
                            cwd=executable.parent)
    if len(result.stdout) > 32768:
        raise DaemonError("Windows daemon inventory budget")
    payload = json.loads(result.stdout.decode("utf-8-sig"))
    if not isinstance(payload, dict) or payload.get("complete") is not True:
        raise DaemonError("Windows daemon inventory is incomplete")
    profiles = payload.get("profiles")
    if not isinstance(profiles, list) or len(profiles) > MAX_PROFILES:
        raise DaemonError("Windows daemon profile budget")
    return profiles


def windows_endpoint(profile: dict) -> list[str]:
    value = profile["exe"]
    if not isinstance(value, str) or not re.match(r"^[A-Za-z]:[\\/]", value):
        raise DaemonError("invalid native proxy path")
    executable = "/mnt/" + value[0].lower() + "/" + value[3:].replace("\\", "/")
    command = [executable, "app-server", "proxy", "--sock", profile["socket"]]
    if not Path("/proc/sys/fs/binfmt_misc/WSLInterop").exists():
        command.insert(0, "/init")
    return command


class DaemonObserver:
    def __init__(self) -> None:
        self.connections: dict[tuple, Connection] = {}

    def close(self) -> None:
        for connection in self.connections.values():
            connection.close()
        self.connections.clear()

    def observe(self, rows: list[dict], adapter: Any, table: dict) -> tuple[dict, set[str]]:
        began = time.monotonic()
        deadline = began + POLL_BUDGET
        profiles: dict[tuple, tuple[Path | list[str], list[dict]]] = {}
        frontends: dict[str, list[tuple[int, str]]] = {}
        handled: set[str] = set()
        proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
        for row in rows:
            if row.get("@wtmux_backend") == "windows":
                continue
            homes = set()
            for pid in adapter.descendants(int(row["pane_pid"]), table)[:128]:
                try:
                    command = (proc / str(pid) / "cmdline").read_bytes().split(b"\0")
                    executable = Path(os.fsdecode(command[0])).name
                    if executable not in {"codex", "codex.exe"} or b"app-server" in command:
                        continue
                    home = linux_profile(pid)
                    if (home / "app-server-daemon/daemon.pid").is_file():
                        handled.add(row["session_name"])
                    identity = linux_identity(home)
                    homes.add(home)
                    frontends.setdefault(row["session_name"], []).append((pid, process_start(pid, proc)))
                    key = ("linux", str(home), *identity)
                    profiles.setdefault(key, (home / "app-server-control/app-server-control.sock", []))[1].append(row)
                except (OSError, ValueError, KeyError, IndexError, TypeError):
                    continue
            if homes:
                handled.add(row["session_name"])
        windows_rows = [r for r in rows if r.get("@wtmux_backend") == "windows"
                        and adapter.infer_tool({"pid": int(r["pane_pid"]),
                                                "command": r.get("pane_current_command", ""),
                                                "declaredTool": r.get("@wtmux_tool", ""),
                                                "backend": "windows"}, table) == "codex"]
        windows_failed = False
        native_profiles = []
        if windows_rows:
            handled.update(r["session_name"] for r in windows_rows)
            try:
                native_profiles = windows_profiles()
                for profile in native_profiles:
                    key = ("windows", profile["home"], profile["pid"], profile["created"])
                    profiles[key] = windows_endpoint(profile), windows_rows
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
                windows_failed = True
        active = set(profiles)
        for key in set(self.connections) - active:
            self.connections.pop(key).close()
        results: dict[str, list[dict]] = {}
        windows_threads: list[dict] = []
        if len(profiles) > MAX_PROFILES:
            return {}, handled
        for key, (endpoint, candidates) in profiles.items():
            connection = self.connections.get(key)
            try:
                if time.monotonic() >= deadline:
                    raise DaemonError("collector daemon budget")
                if connection is None:
                    connection = Connection(endpoint, min(deadline, time.monotonic() + 1.5))
                    self.connections[key] = connection
                connection.deadline = deadline
                connection.received = 0
                threads = connection.threads()
                if key[0] == "linux" and linux_identity(Path(key[1])) != key[2:]:
                    raise DaemonError("daemon changed during observation")
                if key[0] == "windows":
                    windows_threads.extend(threads)
                else:
                    for row in candidates:
                        thread = match(row, threads)
                        if thread is not None:
                            results.setdefault(row["session_name"], []).append(thread)
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
                if connection is not None:
                    connection.close()
                self.connections.pop(key, None)
                if key[0] == "windows":
                    windows_failed = True
        if windows_rows and not windows_failed:
            try:
                # The proxy can connect after daemon replacement. FileTime PID
                # incarnation must still agree after the native RPC completes.
                def identity_fields(p):
                    return p["home"], p["pid"], p["created"]
                windows_failed = ({identity_fields(p) for p in windows_profiles()}
                                  != {identity_fields(p) for p in native_profiles})
            except (OSError, ValueError, KeyError, TypeError, subprocess.SubprocessError):
                windows_failed = True
        if not windows_failed:
            for row in windows_rows:
                thread = match(row, windows_threads, True)
                if thread is not None:
                    results[row["session_name"]] = [thread]
        observed = instant(time.time())
        # Recheck the pane's identity/title after RPCs; a concurrent switch may
        # change either, even while the daemon's thread inventory remains valid.
        confirmed = {}
        for name, values in results.items():
            try:
                if len(values) != 1 or any(process_start(pid, proc) != started
                                           for pid, started in frontends.get(name, [])):
                    continue
            except (OSError, ValueError, IndexError):
                continue
            confirmed[name] = {"state": state(values[0]["status"]), "observedAt": observed}
        return confirmed, handled
