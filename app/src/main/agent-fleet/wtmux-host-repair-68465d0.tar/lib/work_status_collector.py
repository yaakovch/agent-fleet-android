"""One demand-driven collector for a tmux host, shared by every client.

The cache contains session IDs, status and timestamps only. Provider transcripts
are read incrementally in memory; optional failures never affect live inventory.
"""

from __future__ import annotations

import fcntl
import importlib.machinery
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time

from lib.work_status import ProviderObservation, SYMBOLS, fresh, instant
from lib.tmux_safety import command_from_environment
from lib.session_identity import process_start

POLL_SECONDS = 2
IDLE_SECONDS = 30
MAX_SESSIONS = 128
SEP = "\x1f"
FIELDS = (
    "session_name",
    "session_attached",
    "@wtmux_managed",
    "pane_id",
    "pane_pid",
    "@wtmux_backend",
    "@wtmux_tool",
    "pane_current_command",
    "pane_current_path",
    "@wtmux_project",
    "pane_dead",
    "pane_active",
    "window_active",
    "pane_title",
    "@wtmux_shell_state",
)


def directory() -> Path:
    base = Path(os.environ.get("WTMUX_STATE_DIR", Path.home() / ".local/state/wtmux"))
    # Isolated test sockets must never share the production collector/cache.
    socket = os.environ.get("WTMUX_SCHEDULER_TMUX_SOCKET", "default")
    import hashlib

    path = base / "work-status" / hashlib.sha256(socket.encode()).hexdigest()[:16]
    path.mkdir(parents=True, exist_ok=True, mode=0o700)
    if path.is_symlink() or path.stat().st_uid != os.getuid():
        raise ValueError("unsafe work-status directory")
    path.chmod(0o700)
    return path


def atomic(path: Path, value: dict) -> None:
    fd, temporary = tempfile.mkstemp(prefix=".status-", dir=path.parent)
    try:
        with os.fdopen(fd, "w") as stream:
            json.dump(value, stream, ensure_ascii=False, separators=(",", ":"))
        os.replace(temporary, path)
    finally:
        Path(temporary).unlink(missing_ok=True)


def touch_and_read(root: Path, *, demand: bool = True) -> dict:
    """Non-blocking cache lookup. The collector owns all expensive observation."""
    path = directory()
    if demand and os.environ.get("WTMUX_WORK_STATUS_NO_SPAWN") != "1":
        pid = os.getpid()
        atomic(
            path / f"consumer-{pid}.json",
            {"pid": pid, "start": process_start(pid), "at": time.time()},
        )
        with (path / "collector.lock").open("a+b") as lock:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                pass
            else:
                subprocess.Popen(
                    [sys.executable, str(root / "scripts/wtmux-work-status"), "serve"],
                    stdin=subprocess.DEVNULL,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    start_new_session=True,
                    close_fds=True,
                )
    try:
        file = path / "snapshot.json"
        if file.is_symlink() or file.stat().st_size > 128 * 1024:
            return {}
        values = json.loads(file.read_text()).get("sessions", {})
        now = time.time()
        return {
            key: valid for key, value in values.items() if (valid := fresh(value, now))
        }
    except (OSError, ValueError, AttributeError, TypeError):
        return {}


def consumers(path: Path, now: float) -> bool:
    active = False
    for file in list(path.glob("consumer-*.json"))[:512]:
        try:
            value = json.loads(file.read_text())
            valid = (
                now - value["at"] < 10 and process_start(value["pid"]) == value["start"]
            )
        except (OSError, ValueError, KeyError, TypeError, IndexError):
            valid = False
        if valid:
            active = True
        else:
            file.unlink(missing_ok=True)
    return active


def run_tmux(args: list[str]) -> str:
    value = subprocess.run(
        [*command_from_environment(), *args],
        capture_output=True,
        timeout=1.5,
        check=True,
    )
    if len(value.stdout) > 2 * 1024 * 1024:
        raise ValueError("pane inspection budget exceeded")
    return value.stdout.decode("utf-8", "replace")


def pane_inventory() -> list[dict]:
    fmt = SEP.join("#{" + field + "}" for field in FIELDS)
    result = []
    for line in run_tmux(["list-panes", "-a", "-F", fmt]).splitlines():
        values = line.split(SEP)
        if len(values) != len(FIELDS):
            continue
        row = dict(zip(FIELDS, values))
        if (
            row["@wtmux_managed"] == "1"
            and row["pane_active"] == row["window_active"] == "1"
        ):
            if re.fullmatch(
                r"[A-Za-z0-9._:-]{1,128}", row["session_name"]
            ) and re.fullmatch(r"%\d+", row["pane_id"]):
                result.append(row)
    return result[:500]


def capture_batch(rows: list[dict]) -> dict[str, str]:
    """One tmux invocation; current viewport only, never scrollback."""
    import secrets

    marker = "wtmux-status-" + secrets.token_hex(16)
    args: list[str] = []
    for row in rows:
        if args:
            args.append(";")
        args.extend(
            [
                "display-message",
                "-p",
                marker + row["pane_id"],
                ";",
                "capture-pane",
                "-p",
                "-t",
                row["pane_id"],
                "-S",
                "0",
            ]
        )
    if not args:
        return {}
    output = run_tmux(args)
    parts = output.split(marker)
    return {part.partition("\n")[0]: part.partition("\n")[2] for part in parts[1:]}


def writable_descriptor(fd: Path) -> bool:
    try:
        details = (fd.parent.parent / "fdinfo" / fd.name).read_text()
        flags = next(
            line.split()[1]
            for line in details.splitlines()
            if line.startswith("flags:")
        )
        return int(flags, 8) & os.O_ACCMODE != os.O_RDONLY
    except (OSError, ValueError, StopIteration):
        return False


def proved_source(info: dict, adapter, table: dict) -> tuple[str, Path, tuple] | None:
    """Use provider PID/FD or provider-owned process registry, never cwd matching."""
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    pids = adapter.descendants(info["pid"], table)[:128]
    tool = adapter.infer_tool(info, table)
    for pid in pids:
        command = table.get(pid, (0, ""))[1].lower()
        if tool not in {"codex", "claude", "copilot"} or tool not in command:
            continue
        try:
            owner = (pid, process_start(pid, proc))
            if tool == "codex":
                candidates = []
                for fd in list((proc / str(pid) / "fd").iterdir())[:256]:
                    try:
                        # Only the provider's open writer proves ownership;
                        # a tool reading some other session's log proves nothing.
                        if not writable_descriptor(fd):
                            continue
                        source = Path(os.readlink(fd))
                        if (
                            source.suffix == ".jsonl"
                            and "sessions" in source.parts
                            and any(p.startswith(".codex") for p in source.parts)
                        ):
                            candidates.append((tool, source, (*owner, str(fd))))
                    except OSError:
                        continue
                if len(candidates) == 1:
                    return candidates[0]
            elif tool == "claude":
                registry = Path.home() / ".claude/sessions" / f"{pid}.json"
                value = json.loads(registry.read_text())
                identifier = value.get("sessionId", "")
                if re.fullmatch(r"[A-Za-z0-9-]{8,80}", identifier):
                    matches = list(
                        (Path.home() / ".claude/projects").glob(f"*/{identifier}.jsonl")
                    )
                    if len(matches) == 1:
                        return tool, matches[0], owner
            else:
                matches = list(
                    (Path.home() / ".copilot/session-state").glob(f"*/inuse.{pid}.lock")
                )
                if len(matches) == 1:
                    return tool, matches[0].parent / "events.jsonl", owner
        except (OSError, ValueError, IndexError):
            continue
    return None


def process_epoch(ticks: str) -> float:
    proc = Path(os.environ.get("WTMUX_CONVERSATION_PROC_ROOT", "/proc"))
    boot = next(
        line.split()[1]
        for line in (proc / "stat").read_text().splitlines()
        if line.startswith("btime ")
    )
    return float(boot) + int(ticks) / os.sysconf("SC_CLK_TCK")


def serve(root: Path) -> None:
    path = directory()
    with (path / "collector.lock").open("a+b") as lock:
        os.chmod(lock.name, 0o600)
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            return
        loader = importlib.machinery.SourceFileLoader(
            "work_status_adapters", str(root / "scripts/wtmux-conversation")
        )
        spec = importlib.util.spec_from_loader(loader.name, loader)
        assert spec is not None
        adapter = importlib.util.module_from_spec(spec)
        loader.exec_module(adapter)
        observations: dict[str, ProviderObservation] = {}
        sources: dict[str, tuple] = {}
        previous: dict[str, tuple] = {}
        changed: set[str] = set()
        footer_samples: dict[str, tuple] = {}
        last_demand = time.monotonic()
        offset = 0
        last_statuses: dict[str, dict] = {}
        while True:
            began, now = time.monotonic(), time.time()
            rows, statuses = [], {}
            try:
                rows = pane_inventory()
                demanded = consumers(path, now) or any(
                    row["session_attached"] != "0" for row in rows
                )
                if demanded:
                    last_demand = began
                elif began - last_demand >= IDLE_SECONDS:
                    break
                # Bounded fair rotation; unobserved sessions expire to Unknown.
                selected = (rows + rows)[offset : offset + min(MAX_SESSIONS, len(rows))]
                offset = (offset + MAX_SESSIONS) % max(1, len(rows))
                table = adapter.process_table()
                try:
                    panes = capture_batch(selected)
                except (OSError, ValueError, subprocess.SubprocessError):
                    panes = {}
                alive = {row["session_name"] for row in rows}
                observations = {
                    key: value for key, value in observations.items() if key in alive
                }
                sources = {key: value for key, value in sources.items() if key in alive}
                changed.clear()
                updates: list[str] = []
                for row in selected:
                    name, pane = row["session_name"], row["pane_id"]
                    info = {
                        "pid": int(row["pane_pid"]),
                        "command": row["pane_current_command"],
                        "declaredTool": row["@wtmux_tool"],
                        "backend": row["@wtmux_backend"],
                    }
                    try:
                        identity = (pane, info["pid"], process_start(info["pid"]))
                    except (OSError, ValueError, IndexError):
                        identity = (pane, info["pid"], "missing")
                    state = "unknown"
                    if previous.get(name, (None,))[0] != identity:
                        observations.pop(name, None)
                        footer_samples.pop(name, None)
                        sources.pop(name, None)
                    if row["pane_dead"] == "1":
                        state = "stopped"
                    elif identity[-1] != "missing":
                        source = sources.get(name)
                        if source:
                            try:
                                owner = source[2]
                                valid = (
                                    len(owner) == 3
                                    and process_start(owner[0]) == owner[1]
                                    and owner[0]
                                    in adapter.descendants(info["pid"], table)
                                )
                                if len(owner) == 3:
                                    valid = (
                                        valid
                                        and os.readlink(owner[2]) == str(source[1])
                                        and writable_descriptor(Path(owner[2]))
                                    )
                                if not valid:
                                    source = None
                            except (OSError, ValueError, IndexError):
                                source = None
                        source = source or proved_source(info, adapter, table)
                        if source:
                            sources[name] = source
                        else:
                            sources.pop(name, None)
                        if source:
                            tool, file, owner = source
                            try:
                                value = observations.setdefault(
                                    name, ProviderObservation()
                                ).read(
                                    file,
                                    (*identity, *owner),
                                    tool,
                                    adapter.NORMALIZERS[tool],
                                    now,
                                    process_epoch(owner[1]),
                                )
                                state = value["state"]
                            except (OSError, ValueError, TypeError):
                                observations.pop(name, None)
                        else:
                            observations.pop(name, None)
                            if adapter.infer_tool(info, table) == "shell":
                                parts = row["@wtmux_shell_state"].split(":")
                                if (
                                    len(parts) == 3
                                    and parts[0] == str(info["pid"])
                                    and parts[1].isdigit()
                                    and int(parts[1]) >= process_epoch(identity[-1]) - 1
                                ):
                                    state = {
                                        "prompt": "waiting",
                                        "running": "working",
                                    }.get(parts[2], "unknown")
                        # A ticking live Codex footer also covers Windows-backed
                        # panes without inspecting Windows processes per session.
                        activity = (
                            adapter.codex_provider_activity(panes.get(pane, ""))
                            if adapter.infer_tool(info, table) == "codex"
                            else None
                        )
                        if activity:
                            old = footer_samples.get(name)
                            elapsed = activity["elapsedSeconds"]
                            if (
                                old
                                and elapsed > old[0]
                                and abs((elapsed - old[0]) - (now - old[1])) < 4
                            ):
                                state = "working"
                            footer_samples[name] = (elapsed, now)
                        else:
                            footer_samples.pop(name, None)
                        viewport = panes.get(pane, "")
                        if (source or activity) and (
                            adapter.pane_has_structured_question_menu(viewport)
                            or adapter.pending_approval(
                                {"pane": pane, "pid": info["pid"]}, viewport
                            )[0]
                            is not None
                        ):
                            state = "attention"
                    statuses[name] = {"state": state, "observedAt": instant(now)}
                    # Titles contain no escape controls or tmux format expansion
                    # from pane content. set-option's value is literal metadata.
                    symbol = SYMBOLS[state]
                    if updates:
                        updates.append(";")
                    updates.extend(
                        [
                            "set-option",
                            "-t",
                            "=" + name + ":",
                            "@wtmux_work_observed",
                            str(int(now)),
                        ]
                    )
                    if previous.get(name) != (identity, symbol):
                        if updates:
                            updates.append(";")
                        updates.extend(
                            [
                                "set-option",
                                "-t",
                                "=" + name + ":",
                                "@wtmux_work_symbol",
                                symbol,
                            ]
                        )
                        previous[name] = (identity, symbol)
                        changed.add(name)
                if changed:
                    for line in run_tmux(
                        [
                            "list-clients",
                            "-F",
                            "#{client_name}" + SEP + "#{session_name}",
                        ]
                    ).splitlines():
                        client, _, session = line.partition(SEP)
                        if session in changed:
                            if updates:
                                updates.append(";")
                            updates.extend(["refresh-client", "-S", "-t", client])
                if updates:
                    try:
                        run_tmux(updates)
                    except (OSError, ValueError, subprocess.SubprocessError):
                        pass
                last_statuses = {
                    key: value
                    for key, value in {**last_statuses, **statuses}.items()
                    if key in alive and fresh(value, now)
                }
                atomic(
                    path / "snapshot.json",
                    {"version": 1, "pid": os.getpid(), "sessions": last_statuses},
                )
            except (OSError, ValueError, IndexError, subprocess.SubprocessError):
                # Do not renew cached evidence after a failed inspection.
                if time.monotonic() - last_demand >= IDLE_SECONDS:
                    break
            time.sleep(max(0.05, POLL_SECONDS - (time.monotonic() - began)))
