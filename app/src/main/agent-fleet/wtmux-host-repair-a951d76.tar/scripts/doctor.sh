#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/config.sh"
source "${WTMUX_REPO_ROOT}/lib/picker.sh"
source "${WTMUX_REPO_ROOT}/lib/transport.sh"
source "${WTMUX_REPO_ROOT}/lib/vscode.sh"

# Optional local agent diagnostics; does not contact or configure another host.
if [[ "${1:-}" == "--agent" ]]; then
  shift
  agent_doctor_path="${AGENT_DOCTOR_PATH:-$HOME/projects/agent-config/bin/agent_doctor.py}"
  [[ -f "$agent_doctor_path" ]] || { echo "Missing agent doctor: $agent_doctor_path" >&2; exit 1; }
  exec /usr/bin/python3 "$agent_doctor_path" "$@"
fi

MACHINE_ID=""
VERBOSE=0
CONFIG_ONLY=0
GH_CHECK=0

while (($# > 0)); do
  case "$1" in
    --machine)
      MACHINE_ID="$2"
      shift 2
      ;;
    --verbose)
      VERBOSE=1
      shift
      ;;
    --config)
      CONFIG_ONLY=1
      shift
      ;;
    --gh)
      GH_CHECK=1
      shift
      ;;
    -h|--help)
      cat <<'EOF'
Usage: doctor.sh [--machine ID] [--verbose] [--config] [--gh] | --agent [agent_doctor.py options]
EOF
      exit 0
      ;;
    *)
      wtmux_die "unknown doctor flag: $1"
      ;;
  esac
done

wtmux_require_config "$(wtmux_config_path)"
if ! wtmux_validate_loaded_config "$(wtmux_config_path)"; then
  wtmux_die "config validation failed"
fi

if [[ "$CONFIG_ONLY" == "1" ]]; then
  printf 'config ok: %s\n' "$(wtmux_config_path)"
  printf 'registry=%s\trecords=%s\tcache=%s\n' \
    "$(wtmux_registry_capability)" \
    "$(wtmux_registry_record_count)" \
    "$(wtmux_registry_cache_path)"
  exit 0
fi

pick_host_machine() {
  local __result_var="$1"
  local local_id
  local machine_id
  local label
  local options=()
  local chosen=""

  local_id="$(wtmux_detect_local_machine_id 2>/dev/null || true)"
  while IFS= read -r machine_id; do
    [[ -n "$machine_id" ]] || continue
    label="$(wtmux_machine_name "$machine_id") (${machine_id})"
    if [[ -n "$local_id" && "$machine_id" == "$local_id" ]]; then
      label="${label} [local]"
    fi
    options+=("${label}|${machine_id}")
  done < <(wtmux_machine_ids_with_role "host")

  [[ "${#options[@]}" -gt 0 ]] || wtmux_die "no host-role machines exist in $(wtmux_config_path)"
  wtmux_pick_option "Choose a machine to diagnose" chosen "${options[@]}" || exit 1
  printf -v "$__result_var" '%s' "$chosen"
}

prompt_doctor_menu() {
  local local_id
  local choice=""

  local_id="$(wtmux_detect_local_machine_id 2>/dev/null || true)"
  if [[ -n "$MACHINE_ID" || "$CONFIG_ONLY" == "1" ]]; then
    return 0
  fi

  if ! wtmux_is_interactive; then
    return 0
  fi

  if [[ -n "$local_id" ]]; then
    wtmux_pick_option "Doctor" choice \
      "Current machine ($(wtmux_machine_name "$local_id"))|current" \
      "Choose another machine|pick" \
      "All host machines|all" \
      "Validate config only|config" || exit 1
  else
    wtmux_pick_option "Doctor" choice \
      "Choose a machine|pick" \
      "All host machines|all" \
      "Validate config only|config" || exit 1
  fi

  case "$choice" in
    current)
      MACHINE_ID="$local_id"
      ;;
    pick)
      pick_host_machine MACHINE_ID
      ;;
    all)
      ;;
    config)
      CONFIG_ONLY=1
      ;;
  esac

  if [[ "$CONFIG_ONLY" != "1" && "$VERBOSE" != "1" ]]; then
    if wtmux_confirm "Show verbose details?"; then
      VERBOSE=1
    fi
  fi

  if [[ "$CONFIG_ONLY" != "1" && "$GH_CHECK" != "1" ]]; then
    if wtmux_confirm "Check GitHub readiness too?"; then
      GH_CHECK=1
    fi
  fi
}

print_machine_status() {
  local machine_id="$1"
  local status_text="ok"
  local transport
  local local_id
  local scheduler_output
  local resource_output

  transport="$(wtmux_transport_for_machine "$machine_id")"
  local_id="$(wtmux_detect_local_machine_id 2>/dev/null || true)"

  # Client-only records do not expose a wtmux-host endpoint. In particular,
  # their localhost fallback is local to the client and must not be probed
  # from this machine.
  if ! wtmux_machine_has_role "$machine_id" "host"; then
    printf '%s\ttransport=%s\tstatus=client_only\n' "$machine_id" "$transport"
    return 0
  fi

  if ! wtmux_probe_machine "$machine_id"; then
    status_text="$WTMUX_LAST_PROBE_STATUS"
  fi

  printf '%s\ttransport=%s\tstatus=%s\n' "$machine_id" "$transport" "$status_text"
  if [[ "$GH_CHECK" == "1" && "$status_text" == "ok" ]]; then
    if ! wtmux_exec_host_command "$machine_id" gh-ready >/dev/null 2>&1; then
      printf '%s\tgithub=not-ready\n' "$machine_id"
    else
      printf '%s\tgithub=ready\n' "$machine_id"
    fi
  fi
  if [[ "$VERBOSE" == "1" ]]; then
    printf '  local_machine=%s\n' "${local_id:-none}"
    printf '  probe_command=%s\n' "${WTMUX_LAST_PROBE_COMMAND:-n/a}"
    if [[ -n "${WTMUX_LAST_PROBE_OUTPUT:-}" ]]; then
      printf '  probe_output=%s\n' "$WTMUX_LAST_PROBE_OUTPUT"
    fi
  fi
  if [[ "$status_text" == "ok" ]]; then
    scheduler_output="$(wtmux_exec_host_command "$machine_id" schedule status --kv 2>/dev/null || true)"
    if [[ -n "$scheduler_output" ]]; then
      printf '%s\t%s\n' "$machine_id" "$scheduler_output"
    else
      printf '%s\tscheduler=unavailable\n' "$machine_id"
    fi
    if [[ "$VERBOSE" == "1" ]]; then
      resource_output="$(wtmux_exec_host_command "$machine_id" resource-health --kv 2>/dev/null || true)"
      if [[ -n "$resource_output" ]]; then
        printf '%s\t%s\n' "$machine_id" "$resource_output"
      else
        printf '%s\tresource_health=unavailable\n' "$machine_id"
      fi
    fi
  fi
}

configure_vscode_tabs() {
  wtmux_vscode_configure_terminal_tabs || true
  printf 'vscode_tabs=%s' "$WTMUX_VSCODE_SETTINGS_STATUS"
  if [[ -n "$WTMUX_VSCODE_SETTINGS_RESOLVED_PATH" ]]; then
    printf '\tpath=%s' "$WTMUX_VSCODE_SETTINGS_RESOLVED_PATH"
  fi
  printf '\n'

  if [[ "$(wtmux_detect_platform)" == "wsl" ]]; then
    wtmux_vscode_managed_profile_status || true
    printf 'vscode_profile=%s\n' "$WTMUX_VSCODE_PROFILE_STATUS"
    wtmux_vscode_persistence_status || true
    printf 'vscode_persistence=%s\n' "$WTMUX_VSCODE_PERSISTENCE_STATUS"
    wtmux_vscode_companion_status || true
    printf 'vscode_companion=%s' "$WTMUX_VSCODE_COMPANION_STATUS"
    if [[ -n "$WTMUX_VSCODE_CLI_RESOLVED_PATH" ]]; then
      printf '\tcli=%s' "$WTMUX_VSCODE_CLI_RESOLVED_PATH"
    fi
    printf '\n'
  else
    printf 'vscode_profile=not-applicable\n'
    printf 'vscode_persistence=not-applicable\n'
    printf 'vscode_companion=not-applicable\n'
  fi
}

prompt_doctor_menu

if [[ "$CONFIG_ONLY" == "1" ]]; then
  printf 'config ok: %s\n' "$(wtmux_config_path)"
  printf 'registry=%s\trecords=%s\tcache=%s\n' \
    "$(wtmux_registry_capability)" \
    "$(wtmux_registry_record_count)" \
    "$(wtmux_registry_cache_path)"
  exit 0
fi

if [[ -n "$MACHINE_ID" ]]; then
  print_machine_status "$MACHINE_ID"
else
  while IFS= read -r MACHINE_ID; do
    [[ -n "$MACHINE_ID" ]] || continue
    print_machine_status "$MACHINE_ID"
  done < <(wtmux_machine_ids_with_role "host")
fi

configure_vscode_tabs
