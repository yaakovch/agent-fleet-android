const assert = require('assert');
const fsp = require('fs/promises');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { hostFileTarget, hostFileReferences, metadata, verify, publish, runInvocation, registerHostFiles } = require('../src/host-files');
const golden = require('../../../fleet/host-file-behavior-v1.json');
const info = require('../../../fleet/contracts/fixtures/valid/linked-file-v1.json');

async function until(condition) {
  const deadline = Date.now() + 5000;
  while (!await condition()) { if (Date.now() > deadline) throw new Error('Timed out waiting for the preview state.'); await new Promise(resolve => setTimeout(resolve, 10)); }
}

async function run() {
  for (const row of golden.targets) assert.strictEqual(hostFileTarget(row.value, row.explicit), row.target, row.value);
  for (const row of golden.extractions) assert.deepStrictEqual(hostFileReferences(row.text).map(ref => ref.target), row.targets, row.text);
  assert.deepStrictEqual(metadata(info), info);
  assert.throws(() => metadata({ ...info, privatePath: '/tmp/x' }));
  const root = await fsp.mkdtemp(path.join(os.tmpdir(), 'wtmux-preview-test-'));
  try {
    const bytes = Buffer.from('Verified preview bytes.\n'); const digest = crypto.createHash('sha256').update(bytes).digest('hex');
    const source = path.join(root, 'source'); await fsp.writeFile(source, bytes);
    const downloads = path.join(root, 'Downloads');
    const first = await publish(source, downloads, 'report.txt', bytes.length, digest);
    const second = await publish(source, downloads, 'report.txt', bytes.length, digest);
    assert.strictEqual(path.basename(first), 'report.txt'); assert.strictEqual(path.basename(second), 'report (1).txt');
    await fsp.writeFile(source, 'corruption');
    await assert.rejects(() => publish(source, downloads, 'report.txt', bytes.length, digest), /integrity/);
    assert.deepStrictEqual(await fsp.readFile(first), bytes); assert.deepStrictEqual(await fsp.readFile(second), bytes);
    assert.deepStrictEqual((await fsp.readdir(downloads)).sort(), ['report (1).txt', 'report.txt']);

    const utf8 = await runInvocation({ command: process.execPath, args: ['-e', 'process.stdout.write(Buffer.from([0xe2]));setTimeout(()=>process.stdout.write(Buffer.from([0x82,0xac])),10)'] });
    assert.strictEqual(utf8.stdout, '€');
    await assert.rejects(runInvocation({ command: process.execPath, args: ['-e', 'process.stdout.write("x".repeat(100000));setInterval(()=>{},100)'] }), /exceeded/);
    await assert.rejects(runInvocation({ command: process.execPath, args: ['-e', 'process.stderr.write(JSON.stringify({type:"progress",received:5,total:10})+"\\n"+JSON.stringify({type:"progress",received:4,total:10})+"\\n");setInterval(()=>{},100)'] }), /invalid file progress/);
    const abort = new AbortController();
    const running = runInvocation({ command: process.execPath, args: ['-e', 'setInterval(()=>{},100)'] }, abort.signal);
    setTimeout(() => abort.abort(), 20);
    await assert.rejects(running, /cancelled/);

    const originating = { name: 'Originating managed terminal' }; const other = { name: 'Other terminal' };
    const calls = []; const errors = []; let lastState; let privateDirectory;
    const panels = [];
    const vscode = {
      Uri: { file: file => ({ fsPath: file, toString: () => `file://${file}` }) }, ViewColumn: { Active: 1 },
      commands: { registerCommand: () => ({ dispose() {} }) },
      env: { openExternal: async () => true },
      window: {
        activeTerminal: other, registerTerminalLinkProvider: () => ({ dispose() {} }), showErrorMessage: value => errors.push(value),
        createWebviewPanel: () => {
          let disposed; let receive;
          const panel = { title: '', webview: { html: '', cspSource: 'fixture:', asWebviewUri: uri => `fixture://${uri.fsPath}`,
            postMessage: async () => true, onDidReceiveMessage: callback => { receive = callback; } },
            onDidDispose: callback => { disposed = callback; }, dispose: () => disposed(),
            request: (method, action) => receive({ id: 1, method, action }) };
          panels.push(panel); return panel;
        }
      }
    };
    const context = { extensionPath: path.dirname(__dirname), subscriptions: [] };
    const service = registerHostFiles(vscode, context, {
      isManaged: terminal => terminal === originating, resolve: async terminal => { assert.strictEqual(terminal, originating); return { hostId: 'origin-host', session: 'origin-session' }; },
      invocation: args => ({ command: 'fixture', args }), localPath: async value => value,
      previewHtml: () => '<html><body>Trusted controls</body></html>', downloadsDirectory: () => downloads,
      onState: (state, directory) => { lastState = { ...state }; privateDirectory = directory; },
      runInvocation: async invocation => {
        calls.push(invocation.args);
        assert.strictEqual(invocation.args[invocation.args.indexOf('--host') + 1], 'origin-host');
        assert.strictEqual(invocation.args[invocation.args.indexOf('--session') + 1], 'origin-session');
        if (invocation.args[1] === 'inspect') return { stdout: JSON.stringify({ ...info, name: 'report.txt', mediaKind: 'text', size: bytes.length }) };
        const directory = invocation.args[invocation.args.indexOf('--output-dir') + 1];
        const file = path.join(directory, 'report.txt'); await fsp.writeFile(file, bytes);
        return { stdout: JSON.stringify({ status: 'downloaded', name: 'report.txt', size: bytes.length, sha256: digest, path: file }) };
      }
    });
    const links = service.provider.provideTerminalLinks({ terminal: originating, line: 'Read /tmp/report.txt' });
    assert.strictEqual(links.length, 1); assert.strictEqual(calls.length, 0, 'Recognizing a link must not prefetch file bytes.');
    assert.deepStrictEqual(service.provider.provideTerminalLinks({ terminal: other, line: '/tmp/report.txt' }), []);
    await service.provider.handleTerminalLink(links[0]); await until(() => lastState?.ready);
    await panels[0].request('action', 'save');
    assert.deepStrictEqual(await fsp.readFile(path.join(downloads, 'report (2).txt')), bytes);
    await panels[0].request('action', 'refresh'); await until(() => calls.length === 4 && lastState.ready);
    const directory = privateDirectory; panels[0].dispose();
    await until(async () => { try { await fsp.stat(directory); return false; } catch { return true; } });
    assert.deepStrictEqual(errors, []);
    console.log('ok host-file fixtures, exact publication, UTF-8, limits, cancellation, origin binding, refresh and cleanup');
  } finally { await fsp.rm(root, { recursive: true, force: true }); }
}
run().catch(error => { console.error(error); process.exitCode = 1; });
