const assert = require('node:assert/strict');
const fs = require('node:fs/promises');
const path = require('node:path');
const os = require('node:os');
const cp = require('node:child_process');
const { runInvocation } = require('../src/host-files');

async function run() {
  if (process.platform !== 'win32') { console.log('skip real WSL transport (Windows required)'); return; }
  const distro = process.env.WTMUX_TEST_WSL_DISTRO || 'Ubuntu';
  const prefix = ['-d', distro, '--cd', '~'];
  const invoke = code => ({ command: 'wsl.exe', args: [...prefix, '--', 'python3', '-c', code], timeoutMs: 20000 });
  const delayed = await runInvocation(invoke('import sys,time;time.sleep(0.2);sys.stdout.buffer.write(bytes([226,130,172]));sys.stdout.flush()'));
  assert.equal(delayed.stdout, '€', 'WSL must retain delayed UTF-8 output');
  await assert.rejects(runInvocation(invoke('import time,sys;time.sleep(0.2);sys.exit(7)')), /unavailable/, 'setsid must propagate the child failure');
  const directory = await fs.mkdtemp(path.join(os.tmpdir(), 'wtmux-wsl-cancel-'));
  const receipt = path.join(directory, 'owned-pids.json');
  const converted = cp.spawnSync('wsl.exe', [...prefix, '--exec', 'wslpath', '-u', receipt], { encoding: 'utf8', timeout: 10000, windowsHide: true });
  assert.equal(converted.status, 0);
  const abort = new AbortController();
  const running = runInvocation(invoke(`import os,subprocess,time,json;child=subprocess.Popen(['sleep','600']);open(${JSON.stringify(converted.stdout.trim())},'w').write(json.dumps([os.getpid(),child.pid]));time.sleep(600)`), abort.signal);
  const rejected = assert.rejects(running, /cancelled/);
  try {
    let pids;
    for (let i=0;i<100;i++) { try { pids=JSON.parse(await fs.readFile(receipt, 'utf8')); break; } catch {} await new Promise(r=>setTimeout(r,100)); }
    assert.ok(pids, 'owned receiver did not start');
    abort.abort(); await rejected;
    let alive = true;
    for (let i=0;i<30;i++) {
      const check = cp.spawnSync('wsl.exe', [...prefix, '--exec', 'python3', '-c', `import pathlib,sys;pids=${JSON.stringify(pids)};sys.exit(any((pathlib.Path('/proc')/str(p)/'stat').exists() and (pathlib.Path('/proc')/str(p)/'stat').read_text().split(') ',1)[1][0]!='Z' for p in pids))`], { timeout: 10000, windowsHide: true });
      alive = check.status !== 0; if (!alive) break; await new Promise(r=>setTimeout(r,100));
    }
    assert.equal(alive, false, 'cancellation must stop the owned receiver and SSH descendants');
    console.log('ok real WSL delayed UTF-8, child exit status and process-group cancellation');
  } finally { abort.abort(); await rejected; await fs.rm(directory, { recursive: true, force: true }); }
}
run().catch(error=>{ console.error(error); process.exitCode=1; });
