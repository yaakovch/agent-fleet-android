const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const root = path.resolve(__dirname, '../media/host-file-preview');
const receipt = JSON.parse(fs.readFileSync(path.join(root, 'asset-receipt.json'), 'utf8'));
if (receipt.schemaVersion !== 1 || !receipt.files || Object.keys(receipt.files).length < 5
  || !Object.keys(receipt.files).some(name => name.includes('pdf.worker')) || !receipt.files['host-file-preview.html']) {
  throw new Error('Build the complete preview assets before packaging the Companion.');
}
for (const [name, expected] of Object.entries(receipt.files)) {
  if (!/^(?:host-file-preview[.]html|assets[/][A-Za-z0-9._-]+)$/.test(name) || !/^[a-f0-9]{64}$/.test(expected)) throw new Error('Invalid preview asset receipt.');
  const file = path.join(root, name);
  if (!fs.lstatSync(file).isFile() || crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') !== expected) throw new Error('Preview asset is missing or changed: ' + name);
}
for (const name of ['PDF.js', 'DOMPurify', 'marked']) if (!fs.statSync(path.join(root, 'LICENSE-' + name + '.txt')).isFile()) throw new Error('Missing preview license.');
console.log('Complete bundled preview assets verified.');
