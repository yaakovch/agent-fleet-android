#!/usr/bin/env node
// Ship the same tested viewer bundle as Windows; never load a library from a CDN.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const rootIndex = process.argv.indexOf('--windows-root');
if (rootIndex < 0 || !process.argv[rootIndex + 1]) throw new Error('Pass --windows-root with a built Agent Fleet Windows checkout.');
const windowsRoot = path.resolve(process.argv[rootIndex + 1]);
const renderer = path.join(windowsRoot, 'out', 'renderer');
const destination = path.join(__dirname, '..', 'media', 'host-file-preview');
const html = fs.readFileSync(path.join(renderer, 'host-file-preview.html'), 'utf8');
const files = new Set(['host-file-preview.html']);
for (const match of html.matchAll(/(?:src|href)="\.\/([^"<>]+)"/g)) files.add(match[1]);
const assets = fs.readdirSync(path.join(renderer, 'assets'));
for (const relative of files) {
  if (!relative.endsWith('.js')) continue;
  const code = fs.readFileSync(path.join(renderer, relative), 'utf8');
  for (const asset of assets) if (code.includes(asset)) files.add(`assets/${asset}`);
}
fs.rmSync(destination, { recursive: true, force: true });
fs.mkdirSync(destination, { recursive: true });
const receipt = { schemaVersion: 1, source: 'Agent Fleet Windows production viewer', files: {} };
for (const relative of files) {
  const bytes = fs.readFileSync(path.join(renderer, relative));
  fs.mkdirSync(path.dirname(path.join(destination, relative)), { recursive: true });
  fs.writeFileSync(path.join(destination, relative), bytes);
  receipt.files[relative] = crypto.createHash('sha256').update(bytes).digest('hex');
}
for (const [name, relative] of [['PDF.js', 'pdfjs-dist/LICENSE'], ['DOMPurify', 'dompurify/LICENSE'], ['marked', 'marked/LICENSE']]) {
  fs.writeFileSync(path.join(destination, `LICENSE-${name}.txt`), fs.readFileSync(path.join(windowsRoot, 'node_modules', relative)));
}
fs.writeFileSync(path.join(destination, 'asset-receipt.json'), JSON.stringify(receipt, null, 2) + '\n');
console.log(`Bundled ${files.size} verified viewer files.`);
