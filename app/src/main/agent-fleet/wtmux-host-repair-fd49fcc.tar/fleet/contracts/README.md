# Agent Fleet Contracts

This directory is the canonical, topology-independent contract package for the
Agent Fleet product. Until migration activation, wtmux owns the package and the
Windows and Android repositories consume byte-identical fixture mirrors pinned
by `contract-lock-v1.json`.

Rules:

- `manifest-v1.json` is the package index and protocol/unknown-field policy.
  The modernization package is `1.11.0` and must ship as contracts component
  sequence `21`; deployed `1.10.0` / `20` remains the rollback identity.
- `limits-v1.json` owns structural size and count limits shared by consumers.
- `privacy-v1.json` classifies channels and forbidden persisted content.
- `compatibility-v1.json` records current component/protocol compatibility.
- `supervisor-v1.schema.json` and its conformance fixture define the shared
  client lifecycle, resource bounds, backpressure, and channel failure domains
  without prescribing a platform process implementation.
- `transport-v1.schema.json` defines engine capabilities, stable failures,
  recovery actions, direct-network opt-in, and the measured adoption state of
  OpenSSH convergence, connection reuse, and SFTP.
- `host-runtime-v1.schema.json` defines the stable host entrypoint, channel
  privacy boundaries, negotiation contract, operation bindings, resource
  budgets, error/recovery taxonomy, and session-index decision.
- `pairing-bundle-v1.schema.json` defines the one data-only, digest-bound fleet
  configuration reviewed and atomically activated by both clients. Its
  allowlist contains registry facts, client policy, host trust, and
  compatibility metadata only.
- `diagnostics-v2.schema.json` defines the shared eleven-layer read-only probe,
  ephemeral correlation identity, stable codes, durations, versions, and
  recovery actions used by both client diagnostics surfaces. Its metadata-only
  `legacyUsage` record is the removal gate for compatibility projections: two
  successful release cycles, complete host/client migration verification, and
  zero observed legacy signals are all required.
- `provider-confidence-v1.schema.json` defines the cross-provider replay corpus
  and fail-closed Native mutation states used by both clients.
- `schemas/` contains JSON Schema 2020-12 structural contracts.
- `generated/` contains deterministic structural catalogs and Python,
  TypeScript, and Kotlin models produced by
  `scripts/integration/generate-contract-models`.
- `fixtures/valid/` and `fixtures/invalid/` contain bounded conformance cases.
- JSON schemas do not replace handwritten trust, identity, path, revision,
  authorization, privacy, or state-transition validation.
- Array schemas marked with `x-agent-fleet-uniqueBy` define required semantic
  identity, not a documentary hint. Every producer and consumer must reject a
  repeated key even when the duplicate objects differ in other fields. A
  multi-field value such as `["physicalHostId", "id"]` is a composite key.
- Physical-host IDs and legacy-host aliases share one routing namespace: an
  alias may equal its owning physical-host ID, but must never equal another
  physical host's ID or alias.
- An awaiting pairing review is one identity-bound security object. Its
  `deviceId`, `deviceName`, and `platform` envelope fields must exactly match
  `proposal.id`, `proposal.name`, and `proposal.platform`; a nonempty proposal
  `tailscaleNode` must match the verified `peer` after DNS case and trailing-dot
  normalization. Clients must reject a mismatch before displaying decisions.
- Control v1 and conversation v2 reject unknown fields. Additive fields require
  a negotiated protocol/capability or a documented compatibility exception.
- Generated models and mirrors must never be edited directly; regenerate them
  from this package. The generator also rebuilds the package lock and mirrors
  that lock and every conformance fixture to both supplied client roots.

The old `fleet/schema/` files remain compatibility mirrors during migration.
Tests require them to be byte-identical to their canonical counterparts.

Cross-client alert and external-link behavior is specified separately in
`../client-behavior-v1.json` because it is a local client UX contract rather
than a wire or runtime contract. Passing both client roots to the generator
mirrors that golden fixture into their test resources without changing the
runtime contract-package identity. External-link bounds use UTF-16 code units
so Kotlin, Java, JavaScript, and JSON clients enforce the same exact limit.

`conversation.turns.v1` is opt-in through host capabilities and `stream --view`.
Conversation counts visible rows before paging and exposes cursor-paged `activity`
requests (25 entries initially). Legacy callers receive no added fields. Turn IDs
come from provider metadata or stable source offsets; unknown prose stays visible.
Scans stop at 16 MiB, frames at 256 KiB, page items at 192 KiB. Partial summaries
are explicit. Clients retain at most eight activity pages of 200 entries, within
a four MiB cache budget, cancel obsolete reads, and never persist activity text.

Validation for the Native turn projection includes 1,001-tool turns, activity
pagination retaining tool inputs/results, bounded scan exhaustion, replacement
cursors, legacy callers, and phase-less Claude/Copilot transcripts. Unknown
assistant prose is retained. The public and installed host launchers both forward
the negotiated view and read-only activity arguments.
