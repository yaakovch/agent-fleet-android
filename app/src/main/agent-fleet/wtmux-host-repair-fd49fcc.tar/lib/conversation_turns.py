"""Opt-in Native turn projection. No provider calls or transcript persistence."""
from __future__ import annotations

from collections import OrderedDict
import base64
import hashlib
import json
from typing import Any, cast

CAPABILITY = "conversation.turns.v1"
MAX_TRACKED_TURNS = 64
MAX_TRACKED_ITEMS = 4096


def cursor(value: dict[str, Any]) -> str:
    return "turns1:" + base64.urlsafe_b64encode(
        json.dumps(value, separators=(",", ":"), sort_keys=True).encode()
    ).decode().rstrip("=")


def decode_cursor(value: str, inode: int, size: int, view: str) -> dict[str, Any]:
    if not isinstance(value, str) or not value.startswith("turns1:") or len(value) > 512:
        raise ValueError("invalid conversation view cursor")
    encoded = value[7:]
    decoded = json.loads(base64.urlsafe_b64decode(encoded + "=" * (-len(encoded) % 4)))
    if (not isinstance(decoded, dict) or decoded.get("v") != view or decoded.get("i") != inode
            or type(decoded.get("e")) is not int or not 0 <= decoded["e"] <= size
            or type(decoded.get("b")) is not int or not 0 <= decoded["b"] <= decoded["e"]
            or type(decoded.get("n")) is not int or not 0 <= decoded["n"] <= 256
            or not isinstance(decoded.get("t"), str) or len(decoded["t"]) > 160
            or decoded.get("s") not in {"running", "complete", "error", "unknown"}):
        raise ValueError("conversation history changed; reload from the newest page")
    return decoded


def stable_turn(adapter: str, identity: str) -> str:
    return f"{adapter}:" + hashlib.sha256(identity.encode()).hexdigest()[:24]


def message_purpose(record: dict[str, Any], value: dict[str, Any]) -> str:
    if value.get("role") == "user":
        return "user"
    payload = record.get("payload")
    if not isinstance(payload, dict):
        return "unknown"
    completed = payload.get("item")
    phase = completed.get("phase") if isinstance(completed, dict) else payload.get("phase")
    return "progress" if phase == "commentary" else "final" if phase == "final_answer" else "unknown"


class TurnProjection:
    """Track provider boundaries and count activity without retaining tool output.

    Callers own scan/frame budgets. Provider IDs are used when present; explicit
    user/turn-start boundaries supply stable byte anchors otherwise. A scan that
    starts inside an unidentified turn is marked partial, never guessed from prose.
    """

    def __init__(self, adapter: str, inode: int, start: int = 0, *, retain: bool = True,
                 inherited: dict[str, Any] | None = None, details: bool = True):
        self.adapter, self.inode, self.start = adapter, inode, start
        self.retain = retain
        self.details = details
        self.inherited = inherited or {}
        self.current = ""
        self.turns: OrderedDict[str, dict[str, Any]] = OrderedDict()
        self.seen: OrderedDict[tuple[str, str], str] = OrderedDict()
        self.rows: list[tuple[int, int, dict[str, Any]]] = []
        self.progress: dict[str, tuple[int, int, dict[str, Any]]] = {}

    def _turn(self, identity: str, offset: int) -> dict[str, Any]:
        if identity not in self.turns:
            self.turns[identity] = {
                "turnId": identity, "state": "unknown", "toolCount": 0,
                "changeCount": 0, "progressCount": 0, "otherCount": 0,
                "partial": self.start > 0, "latestProgress": "", "start": offset,
                "end": offset, "position": (offset, 1), "timestamp": "", "aborted": False, "hasUser": False,
            }
            if not self.retain and len(self.turns) > MAX_TRACKED_TURNS:
                while len(self.turns) > MAX_TRACKED_TURNS:
                    old, _ = self.turns.popitem(last=False)
                    self.progress.pop(old, None)
        return self.turns[identity]

    def _remember(self, category: str, identifier: str, turn_id: str) -> bool:
        key = (category, identifier)
        if key in self.seen:
            return False
        self.seen[key] = turn_id
        if len(self.seen) > MAX_TRACKED_ITEMS:
            self.seen.popitem(last=False)
            if turn_id in self.turns:
                self.turns[turn_id]["partial"] = True
        return True

    def _context(self, record: dict[str, Any], offset: int) -> tuple[dict[str, Any], str]:
        payload = cast(dict[str, Any], record["payload"]) if isinstance(record.get("payload"), dict) else {}
        event = str(payload.get("type") or "")
        outer = record.get("type")
        explicit = payload.get("turn_id") or record.get("turn_id") or record.get("turnId")
        if isinstance(explicit, str) and explicit:
            self.current = stable_turn(self.adapter, explicit)
        elif self.adapter == "claude" and outer == "user" and not record.get("isMeta"):
            content = (record.get("message") or {}).get("content")
            real_user = isinstance(content, str) or (isinstance(content, list) and any(
                isinstance(part, dict) and part.get("type") in {"text", "input_text"} for part in content))
            if real_user:
                self.current = stable_turn(self.adapter, str(record.get("uuid") or f"{self.inode}:{offset}"))
        elif outer == "user.message":
            self.current = stable_turn(self.adapter, str(record.get("id") or f"{self.inode}:{offset}"))
        elif event == "task_started" or (outer == "assistant.turn_start" and not self.current):
            self.current = stable_turn(self.adapter, f"{self.inode}:{offset}")
        legacy_user = (event == "user_message" or (outer == "response_item" and payload.get("role") == "user")
                       or (event == "item_completed" and isinstance(payload.get("item"), dict) and payload["item"].get("type") == "UserMessage"))
        previous = self.turns.get(self.current)
        if not explicit and legacy_user and (not previous or previous["hasUser"] or previous["state"] == "complete"):
            self.current = stable_turn(self.adapter, f"user:{self.inode}:{offset}")
        if not self.current:
            self.current = str(self.inherited.get("t") or stable_turn(self.adapter, f"partial:{self.inode}:{self.start}"))
        turn = self._turn(self.current, offset)
        if event == "task_started" or outer == "assistant.turn_start":
            turn["state"] = "running"
            turn["partial"] = False
        elif event == "task_complete" or outer == "assistant.turn_end" or (
                self.adapter == "claude" and record.get("subtype") == "turn_duration"):
            turn["state"] = "error" if turn["aborted"] else "complete"
        elif event == "turn_aborted":
            turn["state"], turn["aborted"] = "error", True
        if self.inherited.get("t") == self.current and self.inherited.get("s") in {"complete", "error"}:
            turn["state"] = self.inherited["s"]
        return turn, event

    def consume(self, record: dict[str, Any], offset: int, end: int,
                values: list[dict[str, Any]]) -> list[dict[str, Any]]:
        turn, event = self._context(record, offset)
        turn["end"] = end
        updates: list[dict[str, Any]] = []
        for raw_index, original in enumerate(values):
            index = raw_index * 2
            value = dict(original)
            kind, identifier = value["kind"], value["id"]
            owner = self.seen.get(("tool", identifier)) if kind == "tool" else None
            owner_turn = self.turns.get(owner, turn) if owner else turn
            turn_id = owner_turn["turnId"]
            value["turnId"] = turn_id
            owner_turn["end"] = max(owner_turn["end"], end)
            owner_turn["timestamp"] = value.get("timestamp") or owner_turn["timestamp"]
            if kind == "message":
                purpose = message_purpose(record, value)
                value["messagePurpose"] = purpose
                if purpose == "user":
                    owner_turn["hasUser"] = True
                    owner_turn["position"] = max(owner_turn["position"], (offset, index + 1))
                elif purpose == "progress":
                    if self._remember("progress", identifier, turn_id):
                        owner_turn["progressCount"] += 1
                    owner_turn["latestProgress"] = " ".join(value.get("text", "").split())[:240]
                    self.progress[turn_id] = (offset, index, value)
                    updates.append({**value, "id": f"progress:{turn_id}"})
                if self.retain and (self.details or purpose != "progress"):
                    self.rows.append((offset, index, value))
                if purpose != "progress":
                    updates.append(value)
            elif kind == "status" and (event in {"task_started", "task_complete"}
                                       or record.get("type") in {"assistant.turn_start", "assistant.turn_end"}
                                       or record.get("subtype") == "turn_duration"):
                if self.retain and self.details:
                    self.rows.append((offset, index, value))
            else:
                if kind == "tool":
                    # Provider starts and completions share a stable ID.
                    if self._remember("tool", identifier, turn_id):
                        owner_turn["toolCount"] += 1
                elif kind == "change":
                    if self._remember("change", identifier, turn_id):
                        owner_turn["changeCount"] += 1
                elif kind not in {"plan", "question", "approval", "fallback"}:
                    if self._remember("other", identifier, turn_id):
                        owner_turn["otherCount"] += 1
                if (kind == "error" or value.get("state") == "error") and owner_turn["state"] != "complete":
                    owner_turn["state"] = "error"
                if self.retain and (self.details or kind in {"plan", "question", "approval", "fallback", "error", "attachment"} or value.get("attachments") or value.get("state") == "error"):
                    self.rows.append((offset, index, value))
                if kind in {"plan", "question", "approval", "fallback", "error", "attachment"} or value.get("attachments") or value.get("state") == "error":
                    updates.append(value)
            if owner_turn is not turn:
                updates.append(self.summary(owner_turn))
        if values or event in {"task_started", "task_complete", "turn_aborted"}:
            updates.append(self.summary(turn))
        return updates

    def summary(self, turn: dict[str, Any]) -> dict[str, Any]:
        public = {key: turn[key] for key in ["turnId", "state", "toolCount", "changeCount",
                                            "progressCount", "otherCount", "partial"]}
        public["latestProgress"] = turn["latestProgress"] if turn["state"] != "complete" else ""
        public["cursor"] = cursor({"v": "activity", "i": self.inode, "e": turn["end"],
                                   "b": turn["end"], "n": 256, "t": turn["turnId"], "s": turn["state"]})
        return {"id": f"activity:{turn['turnId']}", "kind": "activity", "timestamp": turn["timestamp"] or "unknown",
                "role": "", "title": "Activity", "text": "", "detail": "", "state": "running" if turn["state"] == "running" else "error" if turn["state"] == "error" else "complete",
                "tool": "", "attachments": [], "choices": [], "turnId": turn["turnId"], "activitySummary": public}

    def projected_rows(self, view: str) -> list[tuple[int, int, dict[str, Any]]]:
        if view == "detailed":
            return list(self.rows)
        output = []
        for offset, index, value in self.rows:
            kind = value["kind"]
            if kind == "message" and value.get("messagePurpose") != "progress":
                output.append((offset, index, value))
            elif kind in {"plan", "question", "approval", "fallback", "attachment"} or value.get("attachments"):
                output.append((offset, index, value))
            elif (kind == "error" or value.get("state") == "error") and self.turns[value["turnId"]]["state"] != "complete":
                output.append((offset, index, value))
        for turn in self.turns.values():
            if any(turn[key] for key in ("toolCount", "changeCount", "progressCount", "otherCount")) or turn["state"] == "running":
                output.append((*turn["position"], self.summary(turn)))
            if turn["state"] != "complete" and turn["turnId"] in self.progress:
                offset, index, value = self.progress[turn["turnId"]]
                output.append((offset, index, {**value, "id": f"progress:{turn['turnId']}"}))
        return sorted(output, key=lambda row: (row[0], row[1], row[2]["id"]))

    def activity_rows(self, turn_id: str) -> list[tuple[int, int, dict[str, Any]]]:
        return [(offset, index, value) for offset, index, value in self.rows
                if value.get("turnId") == turn_id and (value["kind"] in {"tool", "change", "activity", "task_list", "error"}
                    or value.get("messagePurpose") == "progress")]
