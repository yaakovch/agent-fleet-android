#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/platform.sh"
source "${WTMUX_REPO_ROOT}/lib/github.sh"

wtmux_install_local_gh() {
  local api version arch archive_name archive_path install_root

  api="$(curl -fsSL https://api.github.com/repos/cli/cli/releases/latest)"
  version="$(printf '%s\n' "$api" | awk -F'"' '/"tag_name"/ {print $4; exit}')"
  [[ -n "$version" ]] || wtmux_die "failed to discover latest GitHub CLI release"

  case "$(uname -m)" in
    x86_64|amd64)
      arch="amd64"
      ;;
    aarch64|arm64)
      arch="arm64"
      ;;
    *)
      wtmux_die "unsupported architecture for local gh install: $(uname -m)"
      ;;
  esac

  archive_name="gh_${version#v}_linux_${arch}.tar.gz"
  archive_path="$(mktemp)"
  install_root="${HOME}/.local/lib/wtmux/gh/${version}"
  mkdir -p "$install_root"

  curl -fsSL -o "$archive_path" "https://github.com/cli/cli/releases/download/${version}/${archive_name}"
  tar -xzf "$archive_path" -C "$install_root" --strip-components=2 "gh_${version#v}_linux_${arch}/bin/gh"
  mkdir -p "${HOME}/.local/bin"
  ln -snf "${install_root}/gh" "${HOME}/.local/bin/gh"
  rm -f "$archive_path"
}

if wtmux_gh_ready; then
  wtmux_info "GitHub CLI is already ready"
  exit 0
fi

if ! wtmux_gh_installed; then
  if command -v apt-get >/dev/null 2>&1 && command -v sudo >/dev/null 2>&1; then
    if sudo -n apt-get install -y gh >/dev/null 2>&1; then
      wtmux_info "installed gh via apt"
    else
      wtmux_warn "apt-based gh install failed; falling back to a user-local install"
      wtmux_install_local_gh
    fi
  else
    wtmux_install_local_gh
  fi
fi

case "$(wtmux_detect_platform)" in
  wsl|termux)
    gh auth login --git-protocol https
    ;;
  *)
    gh auth login --git-protocol https --web --clipboard
    ;;
esac
