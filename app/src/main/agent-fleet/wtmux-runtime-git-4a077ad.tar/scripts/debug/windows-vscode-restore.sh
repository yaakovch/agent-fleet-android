#!/usr/bin/env bash
set -euo pipefail

WTMUX_REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
export WTMUX_REPO_ROOT
source "${WTMUX_REPO_ROOT}/lib/vscode.sh"

wtmux_isolated_fail() {
  printf '[wtmux][error] %s\n' "$*" >&2
  printf '[wtmux][error] isolated evidence retained at: %s\n' "${WTMUX_ISOLATED_ROOT:-unknown}" >&2
  exit 1
}

[[ "$(wtmux_detect_platform)" == "wsl" ]] ||
  wtmux_isolated_fail "the isolated VS Code restore check requires WSL"

WTMUX_ISOLATED_CLI="$(wtmux_vscode_windows_cli 2>/dev/null || true)"
[[ -n "$WTMUX_ISOLATED_CLI" ]] ||
  wtmux_isolated_fail "Windows VS Code was not detected"

WTMUX_ISOLATED_MACHINE="gaming-desktop-ubuntu"
WTMUX_ISOLATED_WINDOWS_PROJECT="wtmux-vscode-restore-test"
WTMUX_ISOLATED_WINDOWS_SESSION="wtmux-win-wtmux-vscode-restore-test-1"
WTMUX_ISOLATED_WINDOWS_PATH="/mnt/c/projects/${WTMUX_ISOLATED_WINDOWS_PROJECT}"
WTMUX_ISOLATED_CREATED_SESSION=0

wtmux_isolated_cleanup_fixture() {
  if [[ "$WTMUX_ISOLATED_CREATED_SESSION" == "1" ]]; then
    "${WTMUX_REPO_ROOT}/scripts/wtmux-host" --machine "$WTMUX_ISOLATED_MACHINE" \
      kill --session "$WTMUX_ISOLATED_WINDOWS_SESSION" >/dev/null 2>&1 || true
  fi
  if [[ -d "$WTMUX_ISOLATED_WINDOWS_PATH" ]]; then
    rmdir "$WTMUX_ISOLATED_WINDOWS_PATH" 2>/dev/null || true
  fi
}
trap wtmux_isolated_cleanup_fixture EXIT

if tmux has-session -t "$WTMUX_ISOLATED_WINDOWS_SESSION" 2>/dev/null; then
  "${WTMUX_REPO_ROOT}/scripts/wtmux-host" --machine "$WTMUX_ISOLATED_MACHINE" \
    kill --session "$WTMUX_ISOLATED_WINDOWS_SESSION" >/dev/null
fi
mkdir -p "$WTMUX_ISOLATED_WINDOWS_PATH"
"${WTMUX_REPO_ROOT}/scripts/wtmux-host" --machine "$WTMUX_ISOLATED_MACHINE" \
  windows-launch --project "$WTMUX_ISOLATED_WINDOWS_PROJECT" --tool bash >/dev/null
tmux has-session -t "$WTMUX_ISOLATED_WINDOWS_SESSION" 2>/dev/null ||
  wtmux_isolated_fail "the isolated Windows tmux fixture was not created"
WTMUX_ISOLATED_CREATED_SESSION=1

WTMUX_ISOLATED_TEMP_PARENT="${WTMUX_ISOLATED_CLI%%/AppData/*}/AppData/Local/Temp"
[[ "$WTMUX_ISOLATED_TEMP_PARENT" == /mnt/?/Users/*/AppData/Local/Temp ]] ||
  wtmux_isolated_fail "the Windows temporary directory could not be resolved safely"
mkdir -p "$WTMUX_ISOLATED_TEMP_PARENT"
WTMUX_ISOLATED_ROOT="$(mktemp -d "${WTMUX_ISOLATED_TEMP_PARENT}/wtmux-vscode-isolated.XXXXXX")"
WTMUX_ISOLATED_EXTENSION="${WTMUX_ISOLATED_ROOT}/extension"
WTMUX_ISOLATED_PHASE="${WTMUX_ISOLATED_EXTENSION}/test/.windows-isolated-phase.json"
WTMUX_ISOLATED_RESULT="${WTMUX_ISOLATED_EXTENSION}/test/.windows-isolated-result.json"

mkdir -p \
  "${WTMUX_ISOLATED_ROOT}/user-data/User" \
  "${WTMUX_ISOLATED_ROOT}/extensions" \
  "${WTMUX_ISOLATED_ROOT}/workspace"
cp -a "${WTMUX_REPO_ROOT}/vscode/wtmux-image-paste" "$WTMUX_ISOLATED_EXTENSION"
python3 "${WTMUX_REPO_ROOT}/scripts/wtmux-vscode-settings" configure \
  --path "${WTMUX_ISOLATED_ROOT}/user-data/User/settings.json" \
  --distro Ubuntu >/dev/null
python3 -c '
import json
import pathlib
import sys
path = pathlib.Path(sys.argv[1])
payload = json.loads(path.read_text(encoding="utf-8"))
payload["terminal.integrated.defaultProfile.windows"] = "wtmux (WSL Ubuntu)"
path.write_text(json.dumps(payload, indent=4) + "\n", encoding="utf-8")
' "${WTMUX_ISOLATED_ROOT}/user-data/User/settings.json"

wtmux_isolated_run_phase() {
  wtmux_vscode_cli_run "$WTMUX_ISOLATED_CLI" \
    --wait \
    --user-data-dir "${WTMUX_ISOLATED_ROOT}/user-data" \
    --extensions-dir "${WTMUX_ISOLATED_ROOT}/extensions" \
    --extensionDevelopmentPath "$WTMUX_ISOLATED_EXTENSION" \
    --extensionDevelopmentPath "${WTMUX_ISOLATED_EXTENSION}/test/windows-isolated-driver" \
    --disable-workspace-trust \
    --disable-updates \
    --skip-welcome \
    --skip-release-notes \
    --new-window \
    "${WTMUX_ISOLATED_ROOT}/workspace"
}

printf '[wtmux] isolated VS Code lifecycle: tabs, split, duplicate, reload, relaunch, and PTY host restart\n'
wtmux_isolated_run_phase
for _ in $(seq 1 180); do
  [[ -f "$WTMUX_ISOLATED_RESULT" ]] && break
  sleep 1
done
[[ -f "$WTMUX_ISOLATED_RESULT" ]] ||
  wtmux_isolated_fail "the reloaded extension host did not produce lifecycle evidence"
if ! python3 -c '
import json
import sys
payload = json.load(open(sys.argv[1], encoding="utf-8"))
if payload.get("status") != "passed":
    raise SystemExit(2)
print("[wtmux] isolated VS Code restore check passed: " + ", ".join(payload["scenarios"]))
' "$WTMUX_ISOLATED_RESULT"; then
  wtmux_isolated_fail "the isolated VS Code lifecycle reported a failure"
fi
[[ ! -e "$WTMUX_ISOLATED_PHASE" ]] ||
  wtmux_isolated_fail "the isolated VS Code lifecycle did not complete its second phase"

case "$WTMUX_ISOLATED_ROOT" in
  "${WTMUX_ISOLATED_TEMP_PARENT}"/wtmux-vscode-isolated.*)
    WTMUX_ISOLATED_CLEANED=0
    for _ in $(seq 1 30); do
      if [[ ! -e "$WTMUX_ISOLATED_ROOT" ]] ||
        find "$WTMUX_ISOLATED_ROOT" -depth -delete 2>/dev/null; then
        WTMUX_ISOLATED_CLEANED=1
        break
      fi
      sleep 1
    done
    [[ "$WTMUX_ISOLATED_CLEANED" == "1" ]] ||
      wtmux_isolated_fail "the isolated VS Code evidence directory is still in use"
    ;;
  *)
    wtmux_isolated_fail "refusing to remove an unexpected isolated directory"
    ;;
esac
