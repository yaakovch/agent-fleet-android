#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_WINDOWS_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_WINDOWS_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_windows_projects_root() {
  printf '%s\n' "${WTMUX_WINDOWS_PROJECTS_ROOT:-C:\\projects}"
}

wtmux_windows_resolve_executable() {
  local executable="$1"

  if [[ "$executable" == */* ]]; then
    [[ -x "$executable" ]] || return 1
    printf '%s\n' "$executable"
  else
    command -v "$executable"
  fi
}

wtmux_windows_interop_launcher_for_path() {
  local executable="$1"
  local marker="${WTMUX_WINDOWS_INTEROP_MARKER:-/proc/sys/fs/binfmt_misc/WSLInterop}"
  local launcher="${WTMUX_WINDOWS_INTEROP_LAUNCHER:-/init}"

  [[ "$executable" == /mnt/[A-Za-z]/* ]] || return 1
  [[ ! -e "$marker" ]] || return 1
  [[ -x "$launcher" ]] || return 2
  printf '%s\n' "$launcher"
}

wtmux_windows_run_executable() {
  local executable
  local launcher=""
  local launcher_status=0

  executable="$(wtmux_windows_resolve_executable "$1")" || return 1
  shift
  if launcher="$(wtmux_windows_interop_launcher_for_path "$executable")"; then
    "$launcher" "$executable" "$@"
  else
    launcher_status=$?
    (( launcher_status == 2 )) && return 1
    "$executable" "$@"
  fi
}

wtmux_windows_user_profile() {
  local value="${WTMUX_WINDOWS_USER_PROFILE:-}"
  local cmd_path=""

  if [[ -n "$value" ]]; then
    printf '%s\n' "$value"
    return 0
  fi
  for cmd_path in cmd.exe /mnt/c/Windows/System32/cmd.exe; do
    if wtmux_windows_resolve_executable "$cmd_path" >/dev/null 2>&1; then
      value="$(wtmux_windows_run_executable "$cmd_path" /d /c 'echo %USERPROFILE%' 2>/dev/null | tr -d '\r' | tail -n 1 || true)"
      if [[ "$value" =~ ^[A-Za-z]:[\\/] ]]; then
        printf '%s\n' "$value"
        return 0
      fi
    fi
  done
  printf '%s\n' "C:\\Users\\${WTMUX_WINDOWS_USER:-${USER:-user}}"
}

wtmux_windows_transport_path() {
  local path="$1"
  printf '%s\n' "${path//\\//}"
}

wtmux_windows_git_bash_path() {
  printf '%s\n' "${WTMUX_WINDOWS_GIT_BASH:-C:\\Program Files\\Git\\bin\\bash.exe}"
}

wtmux_windows_git_bash_wsl_path() {
  wtmux_windows_to_wsl_path "$(wtmux_windows_git_bash_path)"
}

wtmux_windows_tool_command() {
  local tool="$1"

  case "$tool" in
    bash)
      printf '%s\n' ""
      ;;
    codex)
      printf '%s\n' "${WTMUX_WINDOWS_CODEX_CMD:-codex}"
      ;;
    claude)
      printf '%s\n' "${WTMUX_WINDOWS_CLAUDE_CMD:-claude}"
      ;;
    copilot)
      printf '%s\n' "${WTMUX_WINDOWS_COPILOT_CMD:-copilot --yolo}"
      ;;
    *)
      return 1
      ;;
  esac
}

wtmux_windows_validate_project_name() {
  local project_name="$1"

  [[ -n "$project_name" ]] || return 1
  [[ "$project_name" != "." && "$project_name" != ".." ]] || return 1
  [[ "$project_name" != */* && "$project_name" != *\\* ]] || return 1
}

wtmux_windows_join_path() {
  local root="$1"
  local child="$2"

  if [[ "$root" == /* ]]; then
    printf '%s/%s\n' "${root%/}" "$child"
    return 0
  fi

  if [[ "$root" == */* && "$root" != *\\* ]]; then
    printf '%s/%s\n' "${root%/}" "$child"
    return 0
  fi

  root="${root%\\}"
  root="${root%/}"
  printf '%s\\%s\n' "$root" "$child"
}

wtmux_windows_to_wsl_path() {
  local path="$1"
  local drive
  local rest

  if [[ "$path" == /* ]]; then
    printf '%s\n' "$path"
    return 0
  fi

  if command -v wslpath >/dev/null 2>&1; then
    wslpath -u "$path"
    return $?
  fi

  if [[ "$path" =~ ^([A-Za-z]):[\\/]?(.*)$ ]]; then
    drive="${BASH_REMATCH[1],,}"
    rest="${BASH_REMATCH[2]//\\//}"
    if [[ -n "$rest" ]]; then
      printf '/mnt/%s/%s\n' "$drive" "$rest"
    else
      printf '/mnt/%s\n' "$drive"
    fi
    return 0
  fi

  return 1
}

wtmux_windows_to_git_bash_path() {
  local path="$1"
  local drive
  local rest

  path="${path//\\//}"
  if [[ "$path" == /mnt/[A-Za-z]/* ]]; then
    drive="${path:5:1}"
    rest="${path:7}"
    printf '/%s/%s\n' "${drive,,}" "$rest"
    return 0
  fi
  if [[ "$path" =~ ^([A-Za-z]):/?(.*)$ ]]; then
    drive="${BASH_REMATCH[1],,}"
    rest="${BASH_REMATCH[2]}"
    if [[ -n "$rest" ]]; then
      printf '/%s/%s\n' "$drive" "$rest"
    else
      printf '/%s\n' "$drive"
    fi
    return 0
  fi
  printf '%s\n' "$path"
}

wtmux_windows_shell_single_quote() {
  local value="$1"
  printf "'%s'" "${value//\'/\'\\\'\'}"
}

wtmux_windows_powershell_quote() {
  local value="$1"
  printf "'%s'" "${value//\'/\'\'}"
}

wtmux_windows_powershell_path() {
  local candidate

  for candidate in \
    powershell.exe \
    pwsh.exe \
    /mnt/c/Windows/System32/WindowsPowerShell/v1.0/powershell.exe \
    /mnt/c/Program\ Files/PowerShell/7/pwsh.exe; do
    if command -v "$candidate" >/dev/null 2>&1; then
      command -v "$candidate"
      return 0
    fi
    if [[ -x "$candidate" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  done

  return 1
}

wtmux_windows_codex_identity_init() {
  cat <<'BASH'
_wtmux_codex_identity() {
  local identity="$1"
  shift

  if (($# == 0)); then
    env CODEX_HOME="$HOME/.codex-$identity" codex resume --last
  else
    env CODEX_HOME="$HOME/.codex-$identity" codex "$@"
  fi
}
export -f _wtmux_codex_identity

for _wtmux_codex_dir in "$HOME"/.codex-[0-9]*; do
  [[ -d "$_wtmux_codex_dir" ]] || continue
  _wtmux_codex_number="${_wtmux_codex_dir##*/}"
  _wtmux_codex_number="${_wtmux_codex_number#.codex-}"
  [[ "$_wtmux_codex_number" =~ ^[0-9]+$ ]] || continue
  eval "codex${_wtmux_codex_number}() { _wtmux_codex_identity '${_wtmux_codex_number}' \"\$@\"; }"
  export -f "codex${_wtmux_codex_number}"
done
unset _wtmux_codex_dir _wtmux_codex_number
BASH
}

wtmux_windows_bash_command() {
  local project_path="$1"
  local tool="$2"
  local git_bash_project
  local quoted_project
  local tool_command
  local codex_identity_init=""

  git_bash_project="$(wtmux_windows_to_git_bash_path "$project_path")"
  quoted_project="$(wtmux_windows_shell_single_quote "$git_bash_project")"
  tool_command="$(wtmux_windows_tool_command "$tool")" || return 1

  if [[ "$tool" == "bash" ]]; then
    codex_identity_init="$(wtmux_windows_codex_identity_init)"
    printf '%s\ncd %s; exec bash --noprofile --norc -i\n' "$codex_identity_init" "$quoted_project"
  else
    printf 'cd %s && exec %s\n' "$quoted_project" "$tool_command"
  fi
}

wtmux_windows_tmux_shell_command() {
  local project_path="$1"
  local tool="$2"
  local git_bash_wsl
  local bash_command
  local interop_launcher=""
  local launcher_status=0
  local command=()

  git_bash_wsl="$(wtmux_windows_git_bash_wsl_path)" || return 1
  bash_command="$(wtmux_windows_bash_command "$project_path" "$tool")" || return 1
  command=("$git_bash_wsl")
  if interop_launcher="$(wtmux_windows_interop_launcher_for_path "$git_bash_wsl")"; then
    command=("$interop_launcher" "$git_bash_wsl")
  else
    launcher_status=$?
    (( launcher_status == 2 )) && return 1
  fi
  wtmux_shell_quote_join "${command[@]}" --noprofile --norc -lc "$bash_command"
}

wtmux_windows_print_launch_script() {
  local project_path="$1"
  local git_bash="$2"
  local bash_command="$3"
  local title="$4"
  local ps_project
  local ps_git_bash
  local ps_bash_command
  local ps_title

  ps_project="$(wtmux_windows_powershell_quote "$project_path")"
  ps_git_bash="$(wtmux_windows_powershell_quote "$git_bash")"
  ps_bash_command="$(wtmux_windows_powershell_quote "$bash_command")"
  ps_title="$(wtmux_windows_powershell_quote "$title")"

  cat <<POWERSHELL
\$ErrorActionPreference = 'Stop'
\$ProjectPath = ${ps_project}
\$GitBash = ${ps_git_bash}
\$BashCommand = ${ps_bash_command}
\$Title = ${ps_title}

function ConvertTo-WtmuxProcessArgument {
  param([string]\$Value)

  if (\$null -eq \$Value -or \$Value.Length -eq 0) {
    return '""'
  }
  if (\$Value -notmatch '[\s"]') {
    return \$Value
  }

  \$escaped = \$Value -replace '(\\\\*)"', '\$1\$1\\"'
  \$escaped = \$escaped -replace '(\\\\+)\$', '\$1\$1'
  return '"' + \$escaped + '"'
}

function Start-WtmuxProcess {
  param(
    [string]\$FilePath,
    [string[]]\$Arguments
  )

  \$startInfo = [System.Diagnostics.ProcessStartInfo]::new()
  \$startInfo.FileName = \$FilePath
  \$startInfo.UseShellExecute = \$true

  if (\$null -ne \$startInfo.GetType().GetProperty('ArgumentList')) {
    foreach (\$argument in \$Arguments) {
      [void]\$startInfo.ArgumentList.Add(\$argument)
    }
    [void][System.Diagnostics.Process]::Start(\$startInfo)
    return
  }

  \$quotedArguments = \$Arguments | ForEach-Object { ConvertTo-WtmuxProcessArgument \$_ }
  Start-Process -FilePath \$FilePath -ArgumentList (\$quotedArguments -join ' ')
}

if (-not (Test-Path -LiteralPath \$ProjectPath -PathType Container)) {
  throw "Windows project path not found: \$ProjectPath"
}
if (-not (Test-Path -LiteralPath \$GitBash -PathType Leaf)) {
  throw "Git Bash not found: \$GitBash"
}

\$wt = Get-Command wt.exe -ErrorAction SilentlyContinue
if (\$null -ne \$wt) {
  Start-WtmuxProcess -FilePath \$wt.Source -Arguments @('new-tab', '--title', \$Title, \$GitBash, '-lc', \$BashCommand)
} else {
  Start-WtmuxProcess -FilePath \$GitBash -Arguments @('-lc', \$BashCommand)
}
POWERSHELL
}

wtmux_windows_launch() {
  local project_name="$1"
  local tool="$2"
  local root="${3:-$(wtmux_windows_projects_root)}"
  local project_path
  local git_bash
  local bash_command
  local title
  local powershell

  wtmux_windows_validate_project_name "$project_name" || wtmux_die "invalid Windows project name: ${project_name}"
  wtmux_windows_tool_command "$tool" >/dev/null || wtmux_die "unsupported Windows launcher tool: ${tool}"

  project_path="$(wtmux_windows_join_path "$root" "$project_name")"
  git_bash="$(wtmux_windows_git_bash_path)"
  bash_command="$(wtmux_windows_bash_command "$project_path" "$tool")"
  title="${project_name} - Windows ${tool}"

  if [[ "${WTMUX_WINDOWS_LAUNCH_MODE:-}" == "print" ]]; then
    wtmux_windows_print_launch_script "$project_path" "$git_bash" "$bash_command" "$title"
    return 0
  fi

  powershell="$(wtmux_windows_powershell_path)" || wtmux_die "missing powershell.exe or pwsh.exe for Windows launch"
  wtmux_windows_print_launch_script "$project_path" "$git_bash" "$bash_command" "$title" | \
    "$powershell" -NoProfile -NonInteractive -ExecutionPolicy Bypass -Command -
  printf 'launched Windows %s in %s\n' "$tool" "$project_path"
}
