#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_VSCODE_RESTORE_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_VSCODE_RESTORE_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

WTMUX_VSCODE_STABLE_TITLE_PREFIX="wtmux · "
WTMUX_VSCODE_RESTORE_TITLE_PREFIX="wtmux restore · "

wtmux_vscode_short_target() {
  local host_id="$1"
  local backend="${2:-linux}"
  local target="$host_id"

  if [[ "$target" == *_windows ]]; then
    target="${target%_windows}"
    backend="windows"
  fi
  target="${target%-ubuntu}"
  target="${target%-Ubuntu}"
  [[ -n "$target" ]] || return 1
  if [[ "$backend" == "windows" ]]; then
    printf '%s Windows\n' "$target"
  else
    printf '%s\n' "$target"
  fi
}

wtmux_vscode_stable_title() {
  local display_name="$1"
  local host_id="$2"
  local backend="${3:-linux}"
  local short_target

  [[ -n "$display_name" && "$display_name" != *"|"* && ! "$display_name" =~ [[:cntrl:]] ]] || return 1
  short_target="$(wtmux_vscode_short_target "$host_id" "$backend")" || return 1
  printf '%s%s · %s\n' "$WTMUX_VSCODE_STABLE_TITLE_PREFIX" "$display_name" "$short_target"
}

wtmux_vscode_normalize_managed_title() {
  local raw_title="$1"
  local stable_title="${raw_title%% | *}"
  local remainder
  local display_name
  local short_target

  [[ ${#stable_title} -le 512 && "$stable_title" == "$WTMUX_VSCODE_STABLE_TITLE_PREFIX"* ]] || return 1
  remainder="${stable_title#"$WTMUX_VSCODE_STABLE_TITLE_PREFIX"}"
  [[ "$remainder" == *" · "* ]] || return 1
  display_name="${remainder% · *}"
  short_target="${remainder##* · }"
  [[ -n "$display_name" && -n "$short_target" ]] || return 1
  [[ "$display_name" != *"|"* && "$short_target" != *"|"* ]] || return 1
  [[ ! "$display_name" =~ [[:cntrl:]] && ! "$short_target" =~ [[:cntrl:]] ]] || return 1
  printf '%s\n' "$stable_title"
}

wtmux_vscode_parse_managed_title() {
  local raw_title="$1"
  local __display_var="$2"
  local __target_var="$3"
  local stable_title
  local remainder
  local parsed_display
  local parsed_target

  stable_title="$(wtmux_vscode_normalize_managed_title "$raw_title")" || return 1
  remainder="${stable_title#"$WTMUX_VSCODE_STABLE_TITLE_PREFIX"}"
  parsed_display="${remainder% · *}"
  parsed_target="${remainder##* · }"
  printf -v "$__display_var" '%s' "$parsed_display"
  printf -v "$__target_var" '%s' "$parsed_target"
}

wtmux_vscode_state_helper() {
  printf '%s/scripts/wtmux-vscode-state\n' "$WTMUX_REPO_ROOT"
}

wtmux_vscode_binding_put() {
  local title="$1"
  local host_id="$2"
  local project="$3"
  local session="$4"
  local display_name="$5"

  python3 "$(wtmux_vscode_state_helper)" binding-put \
    --title "$title" \
    --host "$host_id" \
    --project "$project" \
    --session "$session" \
    --display "$display_name"
}

wtmux_vscode_binding_get() {
  python3 "$(wtmux_vscode_state_helper)" binding-get --title "$1"
}

wtmux_vscode_binding_remove() {
  python3 "$(wtmux_vscode_state_helper)" binding-remove --title "$1"
}
