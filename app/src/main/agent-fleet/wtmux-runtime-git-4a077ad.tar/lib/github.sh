#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_GITHUB_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_GITHUB_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_gh_installed() {
  command -v gh >/dev/null 2>&1
}

wtmux_gh_ready() {
  wtmux_gh_installed && gh auth status >/dev/null 2>&1
}

wtmux_gh_list_repos() {
  local limit="${1:-200}"
  gh repo list --limit "$limit" --json nameWithOwner,url --jq '.[] | [.nameWithOwner, .url] | @tsv'
}

wtmux_clone_repo() {
  local projects_root="$1"
  local repo="$2"
  local target_dir
  local project_name

  mkdir -p "$projects_root"
  if [[ "$repo" == http://* || "$repo" == https://* || "$repo" == git@* ]]; then
    project_name="$(basename "$repo" .git)"
    target_dir="${projects_root}/${project_name}"
    if [[ -d "$target_dir/.git" ]]; then
      printf '%s\t%s\n' "$project_name" "$target_dir"
      return 0
    fi
    git clone "$repo" "$target_dir" >/dev/null
    printf '%s\t%s\n' "$project_name" "$target_dir"
    return 0
  fi

  project_name="${repo##*/}"
  target_dir="${projects_root}/${project_name}"
  if [[ -d "$target_dir/.git" ]]; then
    printf '%s\t%s\n' "$project_name" "$target_dir"
    return 0
  fi

  if wtmux_gh_installed; then
    gh repo clone "$repo" "$target_dir" >/dev/null
  else
    git clone "https://github.com/${repo}.git" "$target_dir" >/dev/null
  fi
  printf '%s\t%s\n' "$project_name" "$target_dir"
}
