#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_PLATFORM_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_PLATFORM_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

wtmux_detect_platform() {
  if [[ -n "${TERMUX_VERSION:-}" ]] || [[ "${PREFIX:-}" == *"/com.termux/"* ]]; then
    printf '%s\n' "termux"
    return 0
  fi

  if [[ -n "${WSL_INTEROP:-}" ]] || grep -qiE '(microsoft|wsl)' /proc/version 2>/dev/null; then
    printf '%s\n' "wsl"
    return 0
  fi

  printf '%s\n' "linux"
}

wtmux_get_hostname_short() {
  hostname -s 2>/dev/null || hostname 2>/dev/null || printf '%s\n' "unknown-host"
}

wtmux_get_wsl_distro() {
  if [[ -n "${WSL_DISTRO_NAME:-}" ]]; then
    printf '%s\n' "$WSL_DISTRO_NAME"
    return 0
  fi
  if [[ -r /etc/os-release ]]; then
    local distro
    distro="$(awk -F= '$1 == "NAME" { value=$2; gsub(/^"|"$/, "", value); if (value != "") print value; exit }' /etc/os-release)"
    if [[ -n "$distro" ]]; then
      printf '%s\n' "$distro"
      return 0
    fi
  fi
  return 1
}

wtmux_get_android_device_name() {
  local candidate=""

  if command -v getprop >/dev/null 2>&1; then
    candidate="$(getprop ro.product.model 2>/dev/null | tr -d '\r')"
    if [[ -n "$candidate" && "$candidate" != "localhost" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi

    candidate="$(getprop ro.product.device 2>/dev/null | tr -d '\r')"
    if [[ -n "$candidate" && "$candidate" != "localhost" ]]; then
      printf '%s\n' "$candidate"
      return 0
    fi
  fi

  candidate="$(wtmux_get_hostname_short)"
  if [[ "$candidate" == "localhost" ]]; then
    candidate="android-device"
  fi
  printf '%s\n' "$candidate"
}

wtmux_suggest_local_machine_name() {
  case "$(wtmux_detect_platform)" in
    termux)
      wtmux_get_android_device_name
      ;;
    wsl)
      local host
      host="$(wtmux_get_hostname_short)"
      if [[ -n "${WSL_DISTRO_NAME:-}" ]]; then
        printf '%s\n' "${host}-${WSL_DISTRO_NAME}"
      else
        printf '%s\n' "$host"
      fi
      ;;
    *)
      wtmux_get_hostname_short
      ;;
  esac
}

wtmux_default_projects_root() {
  printf '%s\n' "${WTMUX_PROJECTS_ROOT:-${HOME}/projects}"
}

wtmux_platform_summary() {
  local platform
  platform="$(wtmux_detect_platform)"
  printf 'platform=%s hostname=%s user=%s' \
    "$platform" \
    "$(wtmux_get_hostname_short)" \
    "$(id -un)"

  if [[ "$platform" == "wsl" ]] && [[ -n "${WSL_DISTRO_NAME:-}" ]]; then
    printf ' wsl_distro=%s' "$WSL_DISTRO_NAME"
  fi
  printf '\n'
}
