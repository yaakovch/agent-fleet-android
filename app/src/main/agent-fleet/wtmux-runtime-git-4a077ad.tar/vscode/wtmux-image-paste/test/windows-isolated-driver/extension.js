const fs = require('fs');
const path = require('path');
const vscode = require('vscode');
const lifecycle = require('../windows-isolated');

const resultPath = path.join(__dirname, '..', '.windows-isolated-result.json');

async function closeIsolatedWindow() {
  await vscode.commands.executeCommand('workbench.action.closeWindow');
}

async function activate() {
  try {
    await lifecycle.run();
    if (fs.existsSync(resultPath)) {
      await closeIsolatedWindow();
    }
  } catch (error) {
    const message = error && error.stack ? error.stack : String(error);
    await fs.promises.writeFile(
      resultPath,
      JSON.stringify({ status: 'failed', error: message }) + '\n',
      { flag: 'w' }
    );
    console.error(error);
    await closeIsolatedWindow();
  }
}

function deactivate() {}

module.exports = { activate, deactivate };
