#!/usr/bin/env bash

if [[ -n "${WTMUX_LIB_IMAGES_SH:-}" ]]; then
  return 0
fi
WTMUX_LIB_IMAGES_SH=1

source "${WTMUX_REPO_ROOT}/lib/common.sh"

WTMUX_IMAGE_MAX_BYTES=33554432

wtmux_image_supported_ext() {
  local ext="${1,,}"
  case "$ext" in
    png|jpg|jpeg|webp|gif)
      return 0
      ;;
    *)
      return 1
      ;;
  esac
}

# The legacy verified image-transfer channel also carries explicitly selected
# documents. Keep the old image CLI strict; attachment send opts into this set.
wtmux_attachment_supported_ext() {
  wtmux_image_supported_ext "$1" && return 0
  case "${1,,}" in
    md|markdown|txt|text|log|json|jsonl|csv|tsv|yaml|yml|toml|xml|html|htm|pdf|doc|docx|rtf|odt|xls|xlsx|ods|ppt|pptx|odp) return 0 ;;
    *) return 1 ;;
  esac
}

wtmux_image_ext_from_path() {
  local path="$1"
  local base="${path##*/}"
  local ext

  [[ "$base" == *.* ]] || return 1
  ext="${base##*.}"
  ext="${ext,,}"
  if [[ "${WTMUX_ATTACHMENT_TRANSFER:-0}" == 1 ]]; then
    wtmux_attachment_supported_ext "$ext" || return 1
  else
    wtmux_image_supported_ext "$ext" || return 1
  fi
  printf '%s\n' "$ext"
}

wtmux_image_short_hash() {
  local path="$1"

  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$path" | awk '{print substr($1, 1, 8)}'
    return 0
  fi
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$path" | awk '{print substr($1, 1, 8)}'
    return 0
  fi

  wtmux_die "missing required command: sha256sum or shasum"
}

wtmux_image_sha256() {
  local path="$1"
  if command -v sha256sum >/dev/null 2>&1; then
    sha256sum "$path" | awk '{print $1}'
    return 0
  fi
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 "$path" | awk '{print $1}'
    return 0
  fi
  wtmux_die "missing required command: sha256sum or shasum"
}

wtmux_image_size() {
  local path="$1"
  local size
  size="$(wc -c <"$path")"
  size="${size//[[:space:]]/}"
  [[ "$size" =~ ^[0-9]+$ ]] || wtmux_die "image size could not be determined"
  ((size <= WTMUX_IMAGE_MAX_BYTES)) || wtmux_die "image exceeds the 32 MiB safety limit"
  printf '%s\n' "$size"
}

wtmux_image_destination_name() {
  local source_path="$1"
  local display_name="${2:-${1##*/}}"
  local ext
  local hash
  local timestamp

  [[ -r "$source_path" && -f "$source_path" ]] || wtmux_die "image file not readable: ${source_path}"
  ext="$(wtmux_image_ext_from_path "$display_name")" || wtmux_die "unsupported attachment extension: ${display_name}"
  hash="$(wtmux_image_short_hash "$source_path")"
  timestamp="$(date '+%Y-%m-%dT%H-%M-%S')"
  if wtmux_image_supported_ext "$ext"; then
    printf '%s-%s.%s\n' "$timestamp" "$hash" "$ext"
  else
    local stem="${display_name%.*}"
    stem="$(printf '%s' "$stem" | LC_ALL=C tr -c 'A-Za-z0-9._-' '_')"
    stem="${stem:0:100}"
    [[ -n "$stem" && "$stem" != . && "$stem" != .. ]] || stem=document
    printf '%s-%s.%s\n' "$stem" "$(wtmux_image_sha256 "$source_path")" "$ext"
  fi
}

wtmux_image_validate_destination_name() {
  local name="$1"
  local ext

  [[ "$name" != */* && "$name" != *\\* ]] || return 1
  [[ "$name" != "." && "$name" != ".." ]] || return 1
  [[ "$name" == *.* ]] || return 1
  ext="${name##*.}"
  ext="${ext,,}"
  wtmux_attachment_supported_ext "$ext" || return 1
  [[ "$name" =~ ^[A-Za-z0-9._-]+$ ]] || return 1
}

wtmux_image_gitignore_pattern_present() {
  local gitignore_path="$1"
  local storage="${2:-images}"

  [[ -f "$gitignore_path" ]] || return 1
  grep -Fxq ".wtmux/${storage}/" "$gitignore_path"
}

wtmux_image_ensure_gitignore() {
  local project_path="$1"
  local gitignore_path="${project_path}/.gitignore"
  local storage="${2:-images}"
  [[ "$storage" == images || "$storage" == attachments ]] || return 1

  if wtmux_image_gitignore_pattern_present "$gitignore_path" "$storage"; then
    return 0
  fi

  if [[ -f "$gitignore_path" && -s "$gitignore_path" ]]; then
    case "$(tail -c 1 "$gitignore_path" 2>/dev/null || true)" in
      $'\n') ;;
      *) printf '\n' >>"$gitignore_path" ;;
    esac
  fi
  printf '.wtmux/%s/\n' "$storage" >>"$gitignore_path"
}

wtmux_image_cleanup_expired() {
  local image_dir="$1"
  local retention_days="${2:-7}"

  [[ "$retention_days" =~ ^[0-9]+$ ]] || return 1
  ((retention_days >= 1 && retention_days <= 365)) || return 1
  [[ -d "$image_dir" ]] || return 0

  find "$image_dir" -mindepth 1 -maxdepth 1 -type f \
    ! -name '.*.tmp' -mtime "+${retention_days}" -delete
}
