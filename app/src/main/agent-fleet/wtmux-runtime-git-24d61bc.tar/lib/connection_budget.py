"""Phase budgets used by shell discovery and the persistent fleet bridge."""

import os
import sys


def connect_seconds() -> int:
    raw = os.environ.get("WTMUX_SSH_CONNECT_TIMEOUT", "5")
    if not raw.isascii() or not raw.isdecimal() or not 1 <= int(raw) <= 120:
        raise ValueError("WTMUX_SSH_CONNECT_TIMEOUT must be between 1 and 120 whole seconds")
    return int(raw)


def phase_seconds(phase: str) -> int:
    return {"connect": connect_seconds(), "handshake": connect_seconds() + 10,
            "inventory": connect_seconds() + 3, "snapshot": 30, "heartbeat": 30}[phase]


if __name__ == "__main__":
    try:
        print(phase_seconds(sys.argv[1]))
    except (ValueError, KeyError, IndexError) as error:
        raise SystemExit(str(error)) from error
