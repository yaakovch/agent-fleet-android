"""Resolve and validate the active fleet data without executing shell config."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import runpy
import sys
from typing import Any

sys.dont_write_bytecode = True


def require_registry_digest(source: Path, root: Path, expected: str) -> None:
    directory = active_registry(source, root) or registry_directory(source)
    values = validated_records(source, directory)
    actual = hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    if actual != expected:
        raise ValueError("fleet configuration changed after host review")


def registry_directory(source_root: Path) -> Path:
    override = os.environ.get("WTMUX_SHARED_REGISTRY_DIR")
    if override:
        return Path(override).expanduser()
    root = source_root.resolve()
    if root.parent.name == "releases":
        runtime_root = root.parent.parent
        for relative in ("fleet-config/current/registry/machines", "registry/current/machines"):
            candidate = runtime_root / relative
            pointer = runtime_root / relative.split("/current/", 1)[0] / "current"
            # A broken activation must fail validation, never fall back silently.
            if os.path.lexists(pointer):
                return candidate
    return root / "fleet" / "machines"


def validated_records(source_root: Path, directory: Path) -> list[dict[str, Any]]:
    api = runpy.run_path(str(source_root / "scripts/wtmux-registry"))
    if directory.parts[-4:] == ("fleet-config", "current", "registry", "machines"):
        config_api = runpy.run_path(str(source_root / "scripts/wtmux-fleet-config"))
        release = config_api["safe_pointer"](directory.parents[2], "current")
        if release is None:
            raise ValueError("activated fleet configuration is missing")
        config_api["validate_release"](release)
    if directory.parts[-3:] == ("registry", "current", "machines"):
        registry_release(directory.parents[1])
    resolved = directory.resolve(strict=True)
    records = api["load_registry"](resolved)
    if resolved.parent.name == "registry" and (resolved.parent.parent / "bundle.json").exists():
        config_api = runpy.run_path(str(source_root / "scripts/wtmux-fleet-config"))
        config_api["validate_release"](resolved.parent.parent)
    elif (resolved.parent / "registry-manifest.json").exists():
        runtime_api = runpy.run_path(str(source_root / "scripts/wtmux-runtime"))
        payload, _ = runtime_api["read_regular_snapshot"](resolved.parent / "registry-manifest.json")
        manifest = runtime_api["parse_registry_manifest"](payload)
        if {item["id"] for item in manifest["records"]} != {item["id"] for item in records}:
            raise ValueError("activated registry record inventory differs from its manifest")
        for item in manifest["records"]:
            payload, _ = runtime_api["read_regular_snapshot"](resolved.parent / item["path"])
            if len(payload) != item["size"] or hashlib.sha256(payload).hexdigest() != item["sha256"]:
                raise ValueError("activated registry record failed integrity validation")
    return records


def active_registry(source_root: Path, runtime_root: Path) -> Path | None:
    """Validate mutable activation independently of an app's bootstrap digest."""
    config_root = runtime_root / "fleet-config"
    if os.path.lexists(config_root / "current"):
        api = runpy.run_path(str(source_root / "scripts/wtmux-fleet-config"))
        release = api["safe_pointer"](config_root, "current")
        api["validate_release"](release)
        return config_root / "current/registry/machines"
    registry_root = runtime_root / "registry"
    pointer = registry_root / "current"
    if not os.path.lexists(pointer):
        return None
    registry_release(registry_root)
    directory = pointer / "machines"
    validated_records(source_root, directory)
    return directory


def registry_release(registry_root: Path) -> Path:
    pointer = registry_root / "current"
    if not pointer.is_symlink():
        raise ValueError("activated registry pointer must be a symlink")
    raw = Path(os.readlink(pointer))
    if raw.is_absolute() or len(raw.parts) != 2 or raw.parts[0] not in ("releases", "versions"):
        raise ValueError("activated registry pointer is unsafe")
    resolved = pointer.resolve(strict=True)
    if resolved.parent != (registry_root / raw.parts[0]).resolve() or (registry_root / raw).is_symlink():
        raise ValueError("activated registry pointer escapes its releases")
    if raw.parts[0] == "releases" and not (resolved / "registry-manifest.json").is_file():
        raise ValueError("activated registry manifest is missing")
    return resolved


def remove_registry_projections(existing: str) -> list[str]:
    lines = existing.splitlines()
    for label in ("wtmux-fleet configuration", "wtmux-runtime registry", "wtmux-managed shared-registry"):
        begin, end = f"# BEGIN {label}", f"# END {label}"
        if begin in lines or end in lines:
            if lines.count(begin) != 1 or lines.count(end) != 1 or lines.index(begin) >= lines.index(end):
                raise ValueError("fleet registry projection markers are malformed")
            del lines[lines.index(begin):lines.index(end) + 1]
    # The canonical loader initializes the host array. The template's empty
    # initializer must not clear it after a newly prepended projection; retain
    # real local overrides and legacy hand-written host entries.
    return [line for line in lines if line.strip() != "WTMUX_MACHINE_IDS=()"
            and not line.lstrip().startswith("wtmux_load_shared_registry ")]


if __name__ == "__main__":
    source = Path(__file__).resolve().parents[1]
    if len(sys.argv) == 3 and sys.argv[1] == "--active":
        try:
            active = active_registry(source, Path(sys.argv[2]))
            if active is None:
                raise SystemExit(3)
            print(active)
        except (ValueError, OSError, RuntimeError):
            raise SystemExit("REGISTRY_INVALID: activated fleet configuration failed validation") from None
    elif len(sys.argv) == 2:
        print(registry_directory(Path(sys.argv[1])))
    else:
        raise SystemExit("usage: fleet_registry.py SOURCE_ROOT")
