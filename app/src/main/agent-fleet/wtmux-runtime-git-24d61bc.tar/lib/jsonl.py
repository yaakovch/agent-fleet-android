"""Bounded JSONL framing shared by host and fleet control streams."""

from __future__ import annotations

import os
import time
from typing import Any

MAX_FRAME_BYTES = 256 * 1024
FRAME_READ_CHUNK_BYTES = 64 * 1024
FRAME_IDLE_TIMEOUT_SECONDS = 5
FRAME_TOTAL_TIMEOUT_SECONDS = 10


class ProtocolError(ValueError):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code


class BoundedFrameReader:
    """Incrementally assemble newline frames without blocking after readiness."""

    def __init__(
        self,
        maximum: int = MAX_FRAME_BYTES,
        idle_timeout: float = FRAME_IDLE_TIMEOUT_SECONDS,
        total_timeout: float = FRAME_TOTAL_TIMEOUT_SECONDS,
    ):
        self.maximum = maximum
        self.idle_timeout = idle_timeout
        self.total_timeout = total_timeout
        self.buffer = bytearray()
        self.started_at = 0.0
        self.last_progress_at = 0.0

    def feed(self, chunk: bytes, now: float | None = None) -> None:
        if not chunk:
            return
        observed_at = time.monotonic() if now is None else now
        if not self.buffer:
            self.started_at = observed_at
        self.last_progress_at = observed_at
        self.buffer.extend(chunk)
        newline = self.buffer.find(b"\n")
        if newline > self.maximum or (newline < 0 and len(self.buffer) > self.maximum):
            raise ProtocolError("resource_limit", "frame exceeds the protocol size limit")

    def pop(self) -> bytes | None:
        newline = self.buffer.find(b"\n")
        if newline < 0:
            return None
        if newline > self.maximum:
            raise ProtocolError("resource_limit", "frame exceeds the protocol size limit")
        payload = bytes(self.buffer[:newline])
        del self.buffer[:newline + 1]
        if self.buffer:
            self.started_at = self.last_progress_at
        else:
            self.started_at = 0.0
            self.last_progress_at = 0.0
        return payload

    def expired(self, now: float | None = None) -> bool:
        if not self.buffer:
            return False
        observed_at = time.monotonic() if now is None else now
        return (
            observed_at - self.last_progress_at >= self.idle_timeout
            or observed_at - self.started_at >= self.total_timeout
        )

    def require_complete_at_eof(self) -> None:
        if self.buffer:
            raise ProtocolError("invalid_response", "stream ended with a truncated frame")


def read_ready_chunk(stream: Any) -> bytes:
    """Read only currently-ready pipe bytes; file-like fallbacks are for tests."""
    try:
        return os.read(stream.fileno(), FRAME_READ_CHUNK_BYTES)
    except (AttributeError, OSError):
        return stream.read(FRAME_READ_CHUNK_BYTES)


