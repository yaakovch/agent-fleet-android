"""Protect managed tmux panes from fragmented or delayed terminal replies."""

from __future__ import annotations

import argparse
from dataclasses import asdict, dataclass
import json
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
from typing import Sequence


COMMAND_TIMEOUT_SECONDS = 5
MAX_COMMAND_OUTPUT_BYTES = 64 * 1024
# tmux accepts multiple commands in one invocation when they are separated by a
# standalone `;` argument. Batching palette updates avoids one process spawn per
# colour slot, which otherwise stalls session creation for seconds on slow
# platforms (Termux, WSL) whenever a guard must be installed or removed.
CHAIN_SEPARATOR = ";"
COMMANDS_PER_SPAWN = 64
ROW_SEPARATOR = "\x1f"
GUARD_MARKER = "@wtmux_terminal_reply_guard"
GLOBAL_GUARD_MARKER = "@wtmux_terminal_reply_global_guard"
HOOK_MARKER = "@wtmux_terminal_reply_hooks"
GUARD_VERSION = "v3"
LEGACY_GUARD_VERSIONS = ("v1", "v2")
MIN_REPLY_ESCAPE_TIME_MS = 500
HOOKS = (("after-split-window", 90821), ("after-new-window", 90822))
BASE_PALETTE = (
    "#000000",
    "#cd0000",
    "#00cd00",
    "#cdcd00",
    "#0000ee",
    "#cd00cd",
    "#00cdcd",
    "#e5e5e5",
    "#7f7f7f",
    "#ff0000",
    "#00ff00",
    "#ffff00",
    "#5c5cff",
    "#ff00ff",
    "#00ffff",
    "#ffffff",
)


def xterm_palette() -> tuple[str, ...]:
    """Return the complete deterministic xterm 256-colour palette."""
    colours = list(BASE_PALETTE)
    levels = (0, 95, 135, 175, 215, 255)
    for red in levels:
        for green in levels:
            for blue in levels:
                colours.append(f"#{red:02x}{green:02x}{blue:02x}")
    colours.extend(f"#{value:02x}{value:02x}{value:02x}" for value in range(8, 239, 10))
    if len(colours) != 256:
        raise AssertionError("xterm palette must contain exactly 256 entries")
    return tuple(colours)


PALETTE = xterm_palette()
SESSION_RE = re.compile(r"^[A-Za-z0-9._:+-]{1,320}$")
VERSION_RE = re.compile(r"^(?:tmux\s+)?(\d+)\.(\d+)([^\s]*)$")
PALETTE_ROW_RE = re.compile(r"^pane-colours\[(\d+)]\s+(.+)$")


class TmuxSafetyError(RuntimeError):
    """Raised when the active tmux server cannot be inspected or protected."""


@dataclass(frozen=True)
class TmuxSafetyStatus:
    clientVersion: str
    serverVersion: str
    terminalReplySafety: str
    managedPanes: int
    guardedPanes: int


def normalized_version(value: str) -> str:
    match = VERSION_RE.fullmatch(value.strip())
    return f"{match.group(1)}.{match.group(2)}{match.group(3)}" if match else ""


def version_safety(value: str) -> str:
    """Classify the tmux OSC-4 forwarding/parser behavior by server version."""
    normalized = normalized_version(value)
    match = VERSION_RE.fullmatch(normalized)
    if not match:
        return "unknown"
    major, minor = int(match.group(1)), int(match.group(2))
    if (major, minor) == (3, 6):
        return "vulnerable"
    return "safe"


class Tmux:
    def __init__(self, command: Sequence[str] = ("tmux",)) -> None:
        if not command or any(not part or "\x00" in part for part in command):
            raise ValueError("tmux command is invalid")
        self.command = tuple(command)

    def run(self, *arguments: str, check: bool = True) -> subprocess.CompletedProcess[bytes]:
        try:
            result = subprocess.run(
                [*self.command, *arguments],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                timeout=COMMAND_TIMEOUT_SECONDS,
                check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as error:
            raise TmuxSafetyError("tmux command could not be completed") from error
        if len(result.stdout) > MAX_COMMAND_OUTPUT_BYTES or len(result.stderr) > MAX_COMMAND_OUTPUT_BYTES:
            raise TmuxSafetyError("tmux command output exceeded its safety limit")
        if check and result.returncode != 0:
            raise TmuxSafetyError("tmux command failed")
        return result

    def text(self, *arguments: str, check: bool = True) -> str:
        return self.run(*arguments, check=check).stdout.decode("utf-8", "replace").strip()


def command_from_environment() -> tuple[str, ...]:
    command: tuple[str, ...] = (resolve_tmux_binary(),)
    socket_name = os.environ.get("WTMUX_SCHEDULER_TMUX_SOCKET")
    if socket_name:
        command += ("-L", socket_name)
    return command


def resolve_tmux_binary() -> str:
    override = os.environ.get("WTMUX_TMUX_BIN")
    if override:
        return override
    candidates: list[Path] = []
    prefix = os.environ.get("PREFIX")
    if prefix:
        candidates.append(Path(prefix) / "bin" / "tmux")
    candidates.append(Path.home() / ".local" / "bin" / "tmux")
    for candidate in candidates:
        if candidate.is_file() and os.access(candidate, os.X_OK):
            return str(candidate)
    return shutil.which("tmux") or "tmux"


def client_version(tmux: Tmux) -> str:
    try:
        return tmux.text("-V")
    except TmuxSafetyError:
        return "missing"


def server_version(tmux: Tmux) -> str:
    try:
        return normalized_version(tmux.text("display-message", "-p", "#{version}")) or "unknown"
    except TmuxSafetyError:
        return "not-running"


def server_escape_time(tmux: Tmux) -> int | None:
    """Return the active server's partial-key timeout, or None if untrusted."""
    try:
        value = tmux.text("show-options", "-s", "-v", "escape-time")
    except TmuxSafetyError:
        return None
    if not value.isdecimal():
        return None
    return int(value)


def reply_timeout_is_safe(tmux: Tmux) -> bool:
    value = server_escape_time(tmux)
    return value is not None and value >= MIN_REPLY_ESCAPE_TIME_MS


def enforce_reply_timeout(tmux: Tmux) -> None:
    if reply_timeout_is_safe(tmux):
        return
    tmux.run("set-option", "-s", "escape-time", str(MIN_REPLY_ESCAPE_TIME_MS))
    if not reply_timeout_is_safe(tmux):
        raise TmuxSafetyError("tmux terminal reply timeout could not be verified")


def managed_sessions(tmux: Tmux, requested: str | None = None) -> list[str]:
    if requested is not None:
        if not SESSION_RE.fullmatch(requested):
            raise TmuxSafetyError("tmux session name is invalid")
        managed = tmux.text("show-options", "-t", requested, "-q", "-v", "@wtmux_managed")
        if managed != "1":
            raise TmuxSafetyError("tmux session is not managed by wtmux")
        return [requested]

    rows = tmux.text(
        "list-sessions",
        "-F",
        f"#{{session_name}}{ROW_SEPARATOR}#{{@wtmux_managed}}",
    )
    sessions: list[str] = []
    for row in rows.splitlines():
        parts = row.split(ROW_SEPARATOR)
        if len(parts) != 2 or parts[1] != "1" or not SESSION_RE.fullmatch(parts[0]):
            continue
        sessions.append(parts[0])
    return sessions


def managed_panes(tmux: Tmux, requested: str | None = None) -> list[str]:
    panes: list[str] = []
    for session in managed_sessions(tmux, requested):
        output = tmux.text("list-panes", "-s", "-t", session, "-F", "#{pane_id}")
        for pane in output.splitlines():
            if re.fullmatch(r"%\d+", pane):
                panes.append(pane)
    return list(dict.fromkeys(panes))


def pane_palette_state(tmux: Tmux, pane: str) -> tuple[bool, dict[int, str]]:
    output = tmux.text("show-options", "-p", "-t", pane, "pane-colours", check=False)
    result: dict[int, str] = {}
    local = False
    for row in output.splitlines():
        if row == "pane-colours":
            local = True
            continue
        match = PALETTE_ROW_RE.fullmatch(row)
        if not match:
            continue
        local = True
        index = int(match.group(1))
        if 0 <= index <= 255:
            result[index] = match.group(2)
    return local, result


def pane_palette(tmux: Tmux, pane: str) -> dict[int, str]:
    return pane_palette_state(tmux, pane)[1]


def global_palette(tmux: Tmux) -> dict[int, str]:
    output = tmux.text("show-options", "-g", "pane-colours", check=False)
    result: dict[int, str] = {}
    for row in output.splitlines():
        match = PALETTE_ROW_RE.fullmatch(row)
        if not match:
            continue
        index = int(match.group(1))
        if 0 <= index <= 255:
            result[index] = match.group(2)
    return result


def global_is_guarded(tmux: Tmux) -> bool:
    palette = global_palette(tmux)
    return all(index in palette for index in range(len(PALETTE)))


def pane_is_guarded(tmux: Tmux, pane: str, inherited: dict[int, str] | None = None) -> bool:
    local, configured = pane_palette_state(tmux, pane)
    palette = configured if local else dict(global_palette(tmux) if inherited is None else inherited)
    return all(index in palette for index in range(len(PALETTE)))


def marker_version(value: str) -> str:
    version, separator, _ = value.partition(":")
    if separator and version in (*LEGACY_GUARD_VERSIONS, GUARD_VERSION):
        return version
    return ""


def marker_indexes(value: str) -> set[int]:
    version = marker_version(value)
    if not version:
        return set()
    raw_indexes = value.removeprefix(f"{version}:")
    if not raw_indexes:
        return set()
    indexes: set[int] = set()
    for raw in raw_indexes.split(","):
        if not raw.isdigit():
            return set()
        index = int(raw)
        if not 0 <= index < len(PALETTE):
            return set()
        indexes.add(index)
    return indexes


def run_chained(tmux: Tmux, commands: Sequence[Sequence[str]]) -> None:
    """Execute tmux commands in bounded batches of single process spawns."""
    for start in range(0, len(commands), COMMANDS_PER_SPAWN):
        chunk = commands[start : start + COMMANDS_PER_SPAWN]
        flattened: list[str] = []
        for position, command in enumerate(chunk):
            if position:
                flattened.append(CHAIN_SEPARATOR)
            flattened.extend(command)
        tmux.run(*flattened)


def marker_string(owned: set[int]) -> str:
    return f"{GUARD_VERSION}:{','.join(str(index) for index in sorted(owned))}"


def install_global_guard(tmux: Tmux) -> None:
    current = global_palette(tmux)
    existing_marker = tmux.text(
        "show-options", "-g", "-q", "-v", GLOBAL_GUARD_MARKER, check=False,
    )
    owned = marker_indexes(existing_marker)
    commands: list[tuple[str, ...]] = []
    for index, colour in enumerate(PALETTE):
        if index in current:
            continue
        commands.append(("set-option", "-g", "-o", "-q", f"pane-colours[{index}]", colour))
        owned.add(index)
    commands.append(("set-option", "-g", "-q", GLOBAL_GUARD_MARKER, marker_string(owned)))
    run_chained(tmux, commands)
    if not global_is_guarded(tmux):
        raise TmuxSafetyError("tmux global palette guard could not be verified")


def install_pane_guard(tmux: Tmux, pane: str, inherited: dict[int, str]) -> None:
    _, current = pane_palette_state(tmux, pane)
    existing_marker = tmux.text(
        "show-options", "-p", "-t", pane, "-q", "-v", GUARD_MARKER, check=False,
    )
    owned = marker_indexes(existing_marker)
    commands: list[tuple[str, ...]] = []
    for index, fallback in enumerate(PALETTE):
        if index in current:
            continue
        colour = inherited.get(index, fallback)
        commands.append(
            ("set-option", "-p", "-t", pane, "-o", "-q", f"pane-colours[{index}]", colour),
        )
        owned.add(index)
    commands.append(("set-option", "-p", "-t", pane, "-q", GUARD_MARKER, marker_string(owned)))
    run_chained(tmux, commands)
    local, configured = pane_palette_state(tmux, pane)
    if not local or not all(index in configured for index in range(len(PALETTE))):
        raise TmuxSafetyError("tmux pane palette guard could not be verified")


def remove_owned_global_guard(tmux: Tmux) -> None:
    marker = tmux.text(
        "show-options", "-g", "-q", "-v", GLOBAL_GUARD_MARKER, check=False,
    )
    owned = marker_indexes(marker)
    if not owned and not marker_version(marker):
        return
    current = global_palette(tmux)
    commands = [
        ("set-option", "-g", "-q", "-u", f"pane-colours[{index}]")
        for index in sorted(owned)
        if current.get(index, "").lower() == PALETTE[index]
    ]
    commands.append(("set-option", "-g", "-q", "-u", GLOBAL_GUARD_MARKER))
    run_chained(tmux, commands)


def remove_owned_guard(tmux: Tmux, pane: str) -> None:
    marker = tmux.text(
        "show-options", "-p", "-t", pane, "-q", "-v", GUARD_MARKER, check=False,
    )
    owned = marker_indexes(marker)
    if not owned and not marker_version(marker):
        return
    current = pane_palette(tmux, pane)
    commands = [
        ("set-option", "-p", "-t", pane, "-q", "-u", f"pane-colours[{index}]")
        for index in sorted(owned)
        if current.get(index, "").lower() == PALETTE[index]
    ]
    commands.append(("set-option", "-p", "-t", pane, "-q", "-u", GUARD_MARKER))
    run_chained(tmux, commands)


def legacy_hook_command() -> str:
    launcher = shutil.which("wtmux-tmux-safety")
    arguments = (
        *((launcher,) if launcher else (sys.executable, str(Path(__file__).resolve().parents[1] / "scripts" / "wtmux-tmux-safety"))),
        "apply",
        "--session",
        "#{session_name}",
    )
    command = shlex.join(arguments)
    return f"run-shell -b {shlex.quote(f'{command} >/dev/null 2>&1')}"


def hook_matches(existing: str, target: str, expected: str) -> bool:
    """Compare a rendered hook by argv because tmux normalizes shell quoting."""
    rows = existing.splitlines()
    if len(rows) != 1:
        return False
    try:
        return shlex.split(rows[0]) == [target, *shlex.split(expected)]
    except ValueError:
        return False


def remove_session_hooks(tmux: Tmux, session: str) -> None:
    marker = tmux.text("show-options", "-t", session, "-q", "-v", HOOK_MARKER, check=False)
    if marker not in LEGACY_GUARD_VERSIONS:
        return
    expected = legacy_hook_command()
    for hook_name, index in HOOKS:
        target = f"{hook_name}[{index}]"
        existing = tmux.text("show-hooks", "-t", session, target, check=False)
        if hook_matches(existing, target, expected):
            tmux.run("set-hook", "-t", session, "-u", target)
    tmux.run("set-option", "-t", session, "-q", "-u", HOOK_MARKER)


def inspect(tmux: Tmux, requested: str | None = None) -> TmuxSafetyStatus:
    installed = client_version(tmux)
    active = server_version(tmux)
    if installed == "missing":
        return TmuxSafetyStatus(installed, active, "missing", 0, 0)
    if active == "not-running":
        return TmuxSafetyStatus(installed, active, "inactive", 0, 0)
    classification = version_safety(active)
    if classification not in {"safe", "vulnerable"}:
        return TmuxSafetyStatus(installed, active, "unknown", 0, 0)
    try:
        panes = managed_panes(tmux, requested)
    except TmuxSafetyError:
        return TmuxSafetyStatus(installed, active, "unknown", 0, 0)
    if classification == "safe":
        state = "safe" if reply_timeout_is_safe(tmux) else "vulnerable"
        guarded = len(panes) if state == "safe" else 0
        return TmuxSafetyStatus(installed, active, state, len(panes), guarded)
    inherited = global_palette(tmux)
    guarded = sum(pane_is_guarded(tmux, pane, inherited) for pane in panes)
    state = (
        "mitigated"
        if reply_timeout_is_safe(tmux) and global_is_guarded(tmux) and guarded == len(panes)
        else "vulnerable"
    )
    return TmuxSafetyStatus(installed, active, state, len(panes), guarded)


def apply(tmux: Tmux, requested: str | None = None) -> TmuxSafetyStatus:
    active = server_version(tmux)
    if active == "not-running":
        return inspect(tmux, requested)
    classification = version_safety(active)
    if classification == "unknown":
        raise TmuxSafetyError("active tmux server version is unsupported")
    enforce_reply_timeout(tmux)
    sessions = managed_sessions(tmux, requested)
    panes: list[str] = []
    for session in sessions:
        panes.extend(managed_panes(tmux, session))
    panes = list(dict.fromkeys(panes))
    if classification == "vulnerable":
        install_global_guard(tmux)
        inherited = global_palette(tmux)
        for pane in panes:
            install_pane_guard(tmux, pane, inherited)
        for session in sessions:
            remove_session_hooks(tmux, session)
    else:
        remove_owned_global_guard(tmux)
        for pane in panes:
            remove_owned_guard(tmux, pane)
        for session in sessions:
            remove_session_hooks(tmux, session)
    status = inspect(tmux, requested)
    if status.terminalReplySafety not in {"safe", "mitigated", "inactive"}:
        raise TmuxSafetyError("active tmux server remains vulnerable to terminal reply injection")
    return status


def kv_status(status: TmuxSafetyStatus) -> str:
    return (
        f"tmux_client_version={status.clientVersion}\t"
        f"tmux_server_version={status.serverVersion}\t"
        f"terminal_reply_safety={status.terminalReplySafety}\t"
        f"managed_panes={status.managedPanes}\tguarded_panes={status.guardedPanes}"
    )


def main(arguments: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("status", "apply"))
    parser.add_argument("--session")
    parser.add_argument("--kv", action="store_true")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args(arguments)
    if args.kv and args.json:
        parser.error("--kv and --json are mutually exclusive")
    tmux = Tmux(command_from_environment())
    try:
        status = apply(tmux, args.session) if args.command == "apply" else inspect(tmux, args.session)
    except TmuxSafetyError as error:
        print(f"wtmux tmux safety: {error}", file=sys.stderr)
        return 1
    if args.json:
        print(json.dumps(asdict(status), sort_keys=True, separators=(",", ":")))
    elif args.kv:
        print(kv_status(status))
    else:
        print(
            f"terminal reply safety: {status.terminalReplySafety}; "
            f"tmux client={status.clientVersion}; server={status.serverVersion}; "
            f"guarded panes={status.guardedPanes}/{status.managedPanes}"
        )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
