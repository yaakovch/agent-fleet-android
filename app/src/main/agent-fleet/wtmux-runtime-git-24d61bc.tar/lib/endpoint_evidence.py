#!/usr/bin/env python3
"""Bind configured endpoint identity evidence to the live transport."""

from __future__ import annotations

import argparse
import base64
import binascii
import fcntl
import hashlib
import hmac
import ipaddress
import json
import os
import re
import select
import signal
import stat
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any


HOST_KEY_RE = re.compile(r"^SHA256:[A-Za-z0-9+/]{20,88}$")
HOST_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9.-]{0,252}$")
MAX_KNOWN_HOSTS_BYTES = 8 * 1024 * 1024
MAX_TAILSCALE_STATUS_BYTES = 4 * 1024 * 1024


class EvidenceError(ValueError):
    def __init__(self, message: str, code: str = "ENDPOINT_REVERIFY_REQUIRED"):
        super().__init__(message)
        self.code = code


def reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise EvidenceError(f"duplicate Tailscale status field: {key}")
        result[key] = value
    return result


def read_regular_file(path: Path, maximum: int) -> bytes:
    flags = os.O_RDONLY | os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = os.open(path, flags)
    except OSError as error:
        raise EvidenceError("the configured known-hosts file is unavailable or unsafe") from error
    try:
        metadata = os.fstat(descriptor)
        if not stat.S_ISREG(metadata.st_mode) or metadata.st_size > maximum:
            raise EvidenceError("the configured known-hosts file is unavailable or unsafe")
        chunks: list[bytes] = []
        remaining = maximum + 1
        while remaining:
            chunk = os.read(descriptor, min(64 * 1024, remaining))
            if not chunk:
                break
            chunks.append(chunk)
            remaining -= len(chunk)
        payload = b"".join(chunks)
        if len(payload) > maximum:
            raise EvidenceError("the configured known-hosts file exceeds its safety limit")
        return payload
    finally:
        os.close(descriptor)


def decode_base64(value: str) -> bytes:
    try:
        padding = "=" * (-len(value) % 4)
        return base64.b64decode(value + padding, validate=True)
    except (ValueError, binascii.Error) as error:
        raise EvidenceError("known-hosts contains invalid key material") from error


def host_pattern_matches(pattern: str, token: str) -> bool:
    if pattern.startswith("|1|"):
        fields = pattern.split("|")
        if len(fields) != 4:
            return False
        try:
            salt = decode_base64(fields[2])
            expected = decode_base64(fields[3])
        except EvidenceError:
            return False
        actual = hmac.new(salt, token.encode("utf-8"), hashlib.sha1).digest()
        return hmac.compare_digest(actual, expected)
    if any(character in pattern for character in "*?"):
        return False
    return pattern.casefold() == token.casefold()


def host_field_matches(hosts: str, token: str) -> bool:
    positive = False
    for pattern in hosts.split(","):
        negated = pattern.startswith("!")
        candidate = pattern[1:] if negated else pattern
        if host_pattern_matches(candidate, token):
            if negated:
                return False
            positive = True
    return positive


def key_fingerprint(blob: str) -> str:
    digest = hashlib.sha256(decode_base64(blob)).digest()
    return "SHA256:" + base64.b64encode(digest).decode("ascii").rstrip("=")


def matching_known_host_lines(payload: bytes, token: str, expected: str, *, required: bool = True) -> list[str]:
    try:
        text = payload.decode("utf-8")
    except UnicodeError as error:
        raise EvidenceError("known-hosts is not valid UTF-8") from error
    matches: list[str] = []
    revoked = False
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        fields = line.split()
        marker = ""
        if fields[0].startswith("@"):
            marker = fields.pop(0)
        if len(fields) < 3 or not host_field_matches(fields[0], token):
            continue
        key_type, blob = fields[1:3]
        if not re.fullmatch(r"[A-Za-z0-9@._+-]{1,128}", key_type):
            continue
        try:
            fingerprint = key_fingerprint(blob)
        except EvidenceError:
            continue
        if marker == "@revoked" and hmac.compare_digest(fingerprint, expected):
            revoked = True
        elif not marker and hmac.compare_digest(fingerprint, expected):
            matches.append(f"{token} {key_type} {blob}")
    if revoked:
        raise EvidenceError("the configured SSH host key is revoked")
    if not matches and required:
        raise EvidenceError("the configured SSH host-key fingerprint is not present for this endpoint")
    return sorted(set(matches))


def secure_directory(path: Path) -> Path:
    path = path.expanduser()
    if not path.is_absolute():
        raise EvidenceError("the endpoint trust directory must be absolute")
    try:
        path.mkdir(mode=0o700, parents=True, exist_ok=True)
        metadata = path.lstat()
        if not stat.S_ISDIR(metadata.st_mode) or stat.S_ISLNK(metadata.st_mode):
            raise EvidenceError("the endpoint trust directory is unsafe")
        if hasattr(os, "getuid") and metadata.st_uid != os.getuid():
            raise EvidenceError("the endpoint trust directory has the wrong owner")
        os.chmod(path, 0o700)
        metadata = path.stat()
        if stat.S_IMODE(metadata.st_mode) != 0o700:
            raise EvidenceError("the endpoint trust directory permissions are unsafe")
    except OSError as error:
        raise EvidenceError("the endpoint trust directory is unavailable or unsafe") from error
    return path


def fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_CLOEXEC)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def write_pinned_known_hosts(
    directory: Path,
    address: str,
    port: int,
    expected: str,
    lines: list[str],
) -> Path:
    identity = hashlib.sha256(
        b"\0".join((address.encode("utf-8"), str(port).encode("ascii"), expected.encode("ascii"))),
    ).hexdigest()
    destination = directory / f"{identity}.known_hosts"
    lock_path = directory / f"{identity}.lock"
    flags = os.O_RDWR | os.O_CREAT | os.O_CLOEXEC
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        lock_descriptor = os.open(lock_path, flags, 0o600)
    except OSError as error:
        raise EvidenceError("the endpoint trust lock is unavailable or unsafe") from error
    temporary = ""
    try:
        lock_metadata = os.fstat(lock_descriptor)
        if not stat.S_ISREG(lock_metadata.st_mode):
            raise EvidenceError("the endpoint trust lock is unsafe")
        os.fchmod(lock_descriptor, 0o600)
        fcntl.flock(lock_descriptor, fcntl.LOCK_EX)
        payload = ("# Generated from verified endpoint evidence.\n" + "\n".join(lines) + "\n").encode("ascii")
        descriptor, temporary = tempfile.mkstemp(prefix=f".{identity}.", dir=directory)
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.chmod(temporary, 0o600)
            os.replace(temporary, destination)
            temporary = ""
            fsync_directory(directory)
        finally:
            if temporary:
                try:
                    os.unlink(temporary)
                except FileNotFoundError:
                    pass
    except OSError as error:
        raise EvidenceError("the pinned known-hosts file could not be written safely") from error
    finally:
        fcntl.flock(lock_descriptor, fcntl.LOCK_UN)
        os.close(lock_descriptor)
    return destination


def pinned_known_hosts(address: str, port: int, expected: str) -> Path:
    if not HOST_KEY_RE.fullmatch(expected):
        raise EvidenceError("the configured SSH host-key fingerprint is invalid")
    token = address if port == 22 else f"[{address}]:{port}"
    source = Path(os.environ.get("WTMUX_KNOWN_HOSTS_FILE", "~/.ssh/known_hosts")).expanduser()
    try:
        payload = read_regular_file(source, MAX_KNOWN_HOSTS_BYTES)
    except EvidenceError as error:
        if not isinstance(error.__cause__, FileNotFoundError):
            raise
        payload = b""
    matches = matching_known_host_lines(payload, token, expected, required=False)
    default_state = Path(os.environ.get("WTMUX_STATE_DIR", "~/.local/state/wtmux")).expanduser()
    directory = secure_directory(Path(os.environ.get("WTMUX_ENDPOINT_TRUST_DIR", default_state / "endpoint-trust")))
    if not matches:
        identity = hashlib.sha256(b"\0".join((address.encode(), str(port).encode(), expected.encode()))).hexdigest()
        cached = directory / f"{identity}.known_hosts"
        if os.path.lexists(cached):
            matches = matching_known_host_lines(read_regular_file(cached, MAX_KNOWN_HOSTS_BYTES), token, expected)
    if not matches:
        # keyscan only obtains a candidate public key. The already approved
        # fingerprint is the authority; never accept a new key on first use.
        try:
            candidates = run_bounded(["ssh-keyscan", "-T", "5", "-p", str(port), address], 64 * 1024, 6)
        except EvidenceError as error:
            raise EvidenceError("SSH host-key retrieval is unavailable", "ENDPOINT_TRUST_UNAVAILABLE") from error
        matches = matching_known_host_lines(candidates, token, expected, required=False)
        if not matches:
            raise EvidenceError("the presented SSH key differs from the approved fingerprint", "HOST_KEY_CHANGED")
    return write_pinned_known_hosts(directory, address, port, expected, matches)


def run_bounded(command: list[str], maximum: int, timeout: float) -> bytes:
    try:
        process = subprocess.Popen(
            command,
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
    except OSError as error:
        raise EvidenceError("Tailscale status is unavailable") from error
    assert process.stdout is not None
    descriptor = process.stdout.fileno()
    chunks: list[bytes] = []
    size = 0
    deadline = time.monotonic() + timeout
    completed = False
    try:
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise EvidenceError("Tailscale status timed out")
            readable, _, _ = select.select([descriptor], [], [], remaining)
            if not readable:
                raise EvidenceError("Tailscale status timed out")
            chunk = os.read(descriptor, min(64 * 1024, maximum + 1 - size))
            if not chunk:
                break
            chunks.append(chunk)
            size += len(chunk)
            if size > maximum:
                raise EvidenceError("Tailscale status exceeds its safety limit")
        try:
            status = process.wait(timeout=max(0.1, deadline - time.monotonic()))
        except subprocess.TimeoutExpired as error:
            raise EvidenceError("Tailscale status timed out") from error
        if status != 0:
            raise EvidenceError("Tailscale is unavailable")
        completed = True
        return b"".join(chunks)
    finally:
        if not completed:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if process.poll() is None:
                try:
                    process.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass


def tailscale_nodes(value: dict[str, Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    self_value = value.get("Self")
    if isinstance(self_value, dict):
        result.append(self_value)
    peers = value.get("Peer")
    if isinstance(peers, dict):
        result.extend(peer for peer in peers.values() if isinstance(peer, dict))
    elif isinstance(peers, list):
        result.extend(peer for peer in peers if isinstance(peer, dict))
    return result


def normalized_identity(value: str) -> tuple[str, str]:
    candidate = value.strip().rstrip(".")
    try:
        return "ip", str(ipaddress.ip_address(candidate))
    except ValueError:
        return "name", candidate.casefold()


def node_matches(node: dict[str, Any], identities: set[tuple[str, str]]) -> bool:
    candidates: list[str] = []
    for field in ("DNSName", "HostName"):
        value = node.get(field)
        if isinstance(value, str) and value:
            candidates.append(value)
    ips = node.get("TailscaleIPs")
    if isinstance(ips, list):
        candidates.extend(value for value in ips if isinstance(value, str))
    return any(normalized_identity(candidate) in identities for candidate in candidates)


def verify_tailscale_node(address: str, tailscale_node: str, expected: str) -> None:
    if (
        not isinstance(expected, str)
        or not 1 <= len(expected) <= 128
        or any(ord(character) < 33 or ord(character) == 127 for character in expected)
    ):
        raise EvidenceError("the configured Tailscale node ID is invalid")
    payload = run_bounded(["tailscale", "status", "--json"], MAX_TAILSCALE_STATUS_BYTES, 5)
    try:
        status = json.loads(payload.decode("utf-8"), object_pairs_hook=reject_duplicate_keys)
    except (UnicodeError, json.JSONDecodeError) as error:
        raise EvidenceError("Tailscale status is invalid") from error
    if not isinstance(status, dict):
        raise EvidenceError("Tailscale status is invalid")
    nodes = tailscale_nodes(status)

    def matching_ids(identity: str) -> set[str]:
        identities = {normalized_identity(identity)}
        return {
            node["ID"]
            for node in nodes
            if node_matches(node, identities) and isinstance(node.get("ID"), str)
        }

    if matching_ids(address) != {expected}:
        raise EvidenceError("the configured Tailscale node ID does not match the selected endpoint")
    if tailscale_node and matching_ids(tailscale_node) != {expected}:
        raise EvidenceError("the configured Tailscale node ID does not match the selected Tailnet host")


def validate_address(address: str) -> str:
    if not isinstance(address, str) or not address or len(address) > 253:
        raise EvidenceError("the endpoint address is invalid")
    try:
        ipaddress.ip_address(address)
    except ValueError:
        if not HOST_RE.fullmatch(address):
            raise EvidenceError("the endpoint address is invalid")
    return address


def bind_endpoint_evidence(
    *,
    address: str,
    port: int,
    engine: str,
    network: str,
    ssh_host_key: str,
    tailscale_node_id: str,
    tailscale_node: str,
) -> Path | None:
    address = validate_address(address)
    if isinstance(port, bool) or not isinstance(port, int) or not 1 <= port <= 65535:
        raise EvidenceError("the endpoint port is invalid")
    if engine not in ("openssh", "tailscale-cli") or network not in ("local", "direct", "tailnet"):
        raise EvidenceError("the endpoint transport is invalid")
    if engine == "openssh":
        return pinned_known_hosts(address, port, ssh_host_key)
    if network != "tailnet":
        raise EvidenceError("Tailscale CLI requires a Tailnet endpoint")
    verify_tailscale_node(address, tailscale_node, tailscale_node_id)
    return None


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("--address", required=True)
    value.add_argument("--port", required=True, type=int)
    value.add_argument("--engine", required=True, choices=("openssh", "tailscale-cli"))
    value.add_argument("--network", required=True, choices=("local", "direct", "tailnet"))
    value.add_argument("--ssh-host-key", default="")
    value.add_argument("--tailscale-node-id", default="")
    value.add_argument("--tailscale-node", default="")
    return value


def main() -> int:
    args = parser().parse_args()
    try:
        pinned = bind_endpoint_evidence(
            address=args.address,
            port=args.port,
            engine=args.engine,
            network=args.network,
            ssh_host_key=args.ssh_host_key,
            tailscale_node_id=args.tailscale_node_id,
            tailscale_node=args.tailscale_node,
        )
    except EvidenceError as error:
        print(f"{error.code}: {error}", file=sys.stderr)
        return 1
    if pinned is not None:
        print(pinned)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
