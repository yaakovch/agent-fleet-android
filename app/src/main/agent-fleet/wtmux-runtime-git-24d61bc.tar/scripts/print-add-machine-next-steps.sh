#!/usr/bin/env bash
set -euo pipefail

SELF="${BASH_SOURCE[0]}"
while [[ -L "$SELF" ]]; do
  DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
  TARGET="$(readlink "$SELF")"
  if [[ "$TARGET" != /* ]]; then
    SELF="${DIR}/${TARGET}"
  else
    SELF="$TARGET"
  fi
done
SCRIPT_DIR="$(cd -P "$(dirname "$SELF")" >/dev/null 2>&1 && pwd)"
WTMUX_REPO_ROOT="$(cd -P "${SCRIPT_DIR}/.." >/dev/null 2>&1 && pwd)"

source "${WTMUX_REPO_ROOT}/lib/common.sh"
source "${WTMUX_REPO_ROOT}/lib/config.sh"

MACHINE_ID=""
SETUP_RAN=0

while (($# > 0)); do
  case "$1" in
    --machine)
      MACHINE_ID="$2"
      shift 2
      ;;
    --setup-ran)
      SETUP_RAN=1
      shift
      ;;
    *)
      wtmux_die "unknown flag: $1"
      ;;
  esac
done

[[ -n "$MACHINE_ID" ]] || wtmux_die "print-add-machine-next-steps.sh requires --machine"

wtmux_require_config "$(wtmux_config_path)"

printf 'Next steps for %s (%s)\n' "$(wtmux_machine_name "$MACHINE_ID")" "$MACHINE_ID"
printf '  1. Review %s and confirm the machine metadata is correct.\n' "$(wtmux_config_path)"
if [[ "$SETUP_RAN" == "1" ]]; then
  printf '  2. Setup already ran locally.\n'
else
  printf '  2. Run %s/setup.sh --machine %s on this machine.\n' "$WTMUX_REPO_ROOT" "$MACHINE_ID"
fi
if wtmux_machine_has_role "$MACHINE_ID" "host"; then
  printf '  3. Confirm %s exists and that tmux and git are installed on this host.\n' "$(wtmux_machine_field "$MACHINE_ID" "projects_root")"
  printf '  4. The local machine record is saved at %s; new endpoints still need identity verification.\n' "$(wtmux_shared_machine_record_path "$MACHINE_ID")"
  printf '  5. Verify an OpenSSH endpoint for Android, then distribute and activate the verified fleet configuration on each client.\n'
  printf '     A Git push/pull updates checkout clients only; app-owned registries need configuration activation.\n'
  printf '  6. Confirm this host and its session inventory appear on both Windows and Android.\n'
else
  printf '  3. This machine is client-only, so no inbound host address is required.\n'
  printf '  4. Commit and push %s so other machines can discover it after git pull.\n' "$(wtmux_shared_machine_record_path "$MACHINE_ID")"
fi
printf '  7. Run wtmux doctor after setup. It now opens a picker menu by default.\n'
